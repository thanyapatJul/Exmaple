import React, { useState, useMemo, useEffect,startTransition } from 'react';
import { useSetRecoilState, useRecoilValue, useRecoilState } from 'recoil';
import { Badge,Tag,Checkbox,Button,InputGroup,InputRightElement,Spacer,Circle,Switch, Flex, VStack, Input, Box, List, ListItem, ListIcon, Divider,useTheme,HStack,Center,Text } from '@chakra-ui/react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { BsCalendar3Event } from 'react-icons/bs';
import { FaCalendarAlt } from 'react-icons/fa';
import Select from 'react-select';
import { MapfilterState, SwitchedState  } from '../MapFillPlan/MapOverviewPage/Atoms';
import './style.css'
import { isWithinInterval, parseISO } from 'date-fns';
import { SingleDatepicker, RangeDatepicker } from "chakra-dayzed-datepicker";
import { Font } from '@react-pdf/renderer';


const datepickerConfigs = {
    dateFormat: 'yyyy/MM/dd',
    dayNames: ['อา', 'จ', 'อ', 'พ', 'พ', 'ศ', 'ส'],
    monthNames: [
      'มกราคม',
      'กุมภาพันธ์',
      'มีนาคม',
      'เมษายน',
      'พฤษภาคม',
      'มิถุนายน',
      'กรกฎาคม',
      'สิงหาคม',
      'กันยายน',
      'ตุลาคม',
      'พฤศจิกายน',
      'ธันวาคม',
    ],
  };
  

  const datepickerPropsConfigs = {
    dateNavBtnProps: {
      colorScheme: 'teal',
      variant: 'ghost',
    },
    dayOfMonthBtnProps: {
      defaultBtnProps: {
        fontWeight: 'light',
        borderColor: 'red.300',
        _hover: {
          color: 'white',
          background: 'teal.800',
        },
      },
      isInRangeBtnProps: {
        background: 'teal.500',
        color: 'white',
      },
      selectedBtnProps: {
        background: 'teal.800',
        color: 'white',
      },
      todayBtnProps: {
        background: 'teal.400',
      },
    },
    inputProps: {
      fontWeight: 'bold',
      color: 'blue.600',
      placeholder:'Start date - End date',
    },
    popoverCompProps: {
      popoverContentProps: {
        background: 'white',
        color: 'gray.700',
      },
    },
    calendarPanelProps: {
      contentProps: {
        borderWidth: 0,
      },
      headerProps: {
        padding: '5px',
      },
      dividerProps: {
        display: 'none',
      },
    },
    weekdayLabelProps: {
      fontWeight: 'semibold',
    },
    dateHeadingProps: {
      fontWeight: 'light',
    },
  };

  const receivePropsConfigs = {
    ...datepickerPropsConfigs, 
    inputProps: {              
      ...datepickerPropsConfigs.inputProps, 
      color: 'teal'            
    }
  };
  
function FilterMenu({ zones }) {

    const [filterMap , setFilterMap] = useRecoilState(MapfilterState)

    const [selectedProductLengths, setSelectedProductLengths] = useState([]);
    const [selectedZcaLengths, setSelectedZcaLengths] = useState([]);
    const [selectedNameTh, setSelectedNameTh] = useState([]);



    const [productDateRange, setProductDateRange] = useState([]);
    const [receiveDateRange, setReceiveDateRange] = useState([]);

    const resetProductRangeDates = () => {
        setProductDateRange([])
    };

    const resetReceiveRangeDates = () => {
        setReceiveDateRange([])
    };




    /////////////////////////////////// CheckBox ////////////////////////////////////

    const [labPassChecked, setLabPassChecked] = useState(1);    
    const [labWaitingChecked, setLabWaitingChecked] = useState(0);
    const [labNotPassChecked, setLabNotPassChecked] = useState(2);
    const [lockChecked, setLockChecked] = useState(false);
    const [allChecked, setAllChecked] = useState(false);
    const [isIndeterminate, setIsIndeterminate] = useState(false);

    useEffect(() => {
        // Check if any of the lab status checkboxes is not null
        const isAnyLabStatusChecked = [labPassChecked, labWaitingChecked, labNotPassChecked].some(status => status !== null);
    
        // Check if all lab status checkboxes are not null
        const areAllLabStatusesChecked = [labPassChecked, labWaitingChecked, labNotPassChecked].every(status => status !== null);
    
        // Set the states for the parent checkbox
        setAllChecked(areAllLabStatusesChecked);
        setIsIndeterminate(isAnyLabStatusChecked && !areAllLabStatusesChecked);
    }, [labPassChecked, labWaitingChecked, labNotPassChecked]);
    
      const handleLabPassChange = () => {
        setLabPassChecked(labPassChecked === null ? 1 : null);
      };
      const handleLabWaitingChange = () => {
        setLabWaitingChecked(labWaitingChecked === null ? 0 : null);
      };
      const handleLabNotPassChange = () => {
        setLabNotPassChecked(labNotPassChecked === null ? 2 : null);
      };
      const handleLockChange = () => {
        setLockChecked(lockChecked === null ? true : null);

      };
      useEffect(() => {
        console.log('lockChecked:',lockChecked)
      }, [lockChecked])
      
      
      // Update for Parent Checkbox Handler
      const handleParentChange = (e) => {
        const checked = e.target.checked;
        setLabPassChecked(checked ? 1 : null);
        setLabWaitingChecked(checked ? 0 : null);
        setLabNotPassChecked(checked ? 2 : null);

      };

    /////////////////////////////////////////////////////////////////////////////////



    const [isSwitchedOn, setIsSwitchedOn] = useRecoilState(SwitchedState);

    const [selectedSizes, setSelectedSizes] = useState([]);
    const [selectedProductShifts, setSelectedProductShifts] = useState([]);
    const [selectedReceiveShifts, setSelectedReceiveShifts] = useState([]);

    const fixedSizeOptions = [
        { value: "1.2", label: "1.2" },
        { value: "2.4", label: "2.4" },
        { value: "3", label: "3" },
        { value: "4", label: "4" },
      ];

    const shiftOptions = [
        { value: 'A', label: 'A' },
        { value: 'B', label: 'B' },
        { value: 'C', label: 'C' },
    ];

    const sizeOptions = [
        { value: '1.2', label: '1.2 m' },
        { value: '2.4', label: '2.4 m' },
        { value: '3', label: '3 m' },
        { value: '4', label: '4 m' },
    ];


    const safeZones = useMemo(() => {
        return zones || {};
    }, [zones]);
    
    
    const searchOptions = useMemo(() => {
        const uniqueZCAValues = new Set();
        const uniquenameTHValues = new Set();
        const nameTHCounts = {};
        const ReceiveShiftCounts = {};
        const ProductShiftCounts = {};
        const ZcaCounts = {};
        const sizeCounts = {};

        let labPassCount = 0;
        let labWaitingCount = 0;
        let labNotPassCount = 0;
        let lockCount = 0;
        
        let CountZ = 0;
        Object.values(safeZones).forEach(zone => {
            Object.values(zone.levels || {}).forEach(level => {
                Object.values(level.sub_column || {}).forEach(subCol => {
                    if (subCol.data) {
                        CountZ += 1

                        if (subCol.data.lab === 1) {
                            labPassCount++;
                        } else if (subCol.data.lab === 0) {
                            labWaitingCount++;
                        } else if (subCol.data.lab === 2) {
                            labNotPassCount++;
                        }
    
                        if (subCol.data.lock) {
                            lockCount++;
                        }


                        if (subCol.data.product_shift) {
                            const PShift = subCol.data.product_shift;
                            if (ProductShiftCounts[PShift]) {
                                ProductShiftCounts[PShift] += 1;
                            } else {
                                ProductShiftCounts[PShift] = 1;
                            }
                        }


                        if (subCol.data.receive_shift) {
                            const RShift = subCol.data.receive_shift;
                            if (ReceiveShiftCounts[RShift]) {
                                ReceiveShiftCounts[RShift] += 1;
                            } else {
                                ReceiveShiftCounts[RShift] = 1;
                            }
                        }


                        if (subCol.data.zca_on) {
                            const ZcaOn = subCol.data.zca_on;
                            uniqueZCAValues.add(subCol.data.zca_on);
                            if (ZcaCounts[ZcaOn]) {
                                ZcaCounts[ZcaOn] += 1;
                            } else {
                                ZcaCounts[ZcaOn] = 1;
                            }
                        }
                        if (subCol.data.name_th) {
                            const nameTH = subCol.data.name_th;
                            uniquenameTHValues.add(nameTH);
                            if (nameTHCounts[nameTH]) {
                                nameTHCounts[nameTH] += 1;
                            } else {
                                nameTHCounts[nameTH] = 1;
                            }
                        }
                        if (subCol.data.product_length) {
                            const product = subCol.data.product_length;
                            let size = product / 100;
                            
                            // if (product >= 0 && product <= 140) {
                            //     size = "1.2";
                            // } else if (product >= 141 && product <= 260) {
                            //     size = "2.4";
                            // } else if (product >= 261 && product <= 320) {
                            //     size = "3";
                            // } else {
                            //     size = "4";
                            // }

                            // if (product <= 120) {
                            //     size = "1.2";
                            // } else if (product <= 240) {
                            //     size = "2.4";
                            // } else if ( product <= 300) {
                            //     size = "3";
                            // } else {
                            //     size = "4";
                            // }
                            
                            if (sizeCounts[size]) {
                                sizeCounts[size] += 1;
                            } else {
                                sizeCounts[size] = 1;
                            }

                        }

                    }
                });
            });
        });
        const ZonesCount = CountZ
        
        const zcaOptions = Array.from(uniqueZCAValues).map(zca => ({
            value: zca,
            label: (
                <Flex flexDirection="row" alignItems="center" justifyContent="center">
                    {zca}
                    <Spacer />
                    <Badge 
                        ml='5px'
                        size="sm"
                        colorScheme="teal"
                        variant='solid'>
                        {ZcaCounts[zca]}
                    </Badge>
                </Flex>
            ),
        }));

        const productLengthOptions = Object.entries(sizeCounts).map(([value, count]) => ({
            value: value,
            label: (
              <Flex flexDirection="row" alignItems="center" justifyContent="center">
                {value}
                <Spacer />
                <Badge
                  ml='10px'
                  size="sm"
                  colorScheme={count ? "teal" : "red"}
                  variant="solid"
                >
                  {count || '0'}
                </Badge>
              </Flex>
            ),
          }));
          

        const productShiftOptions = shiftOptions.map(option => ({
            value: option.value,
            label: (
                <Flex flexDirection="row" alignItems="center" justifyContent="center">
                    {option.label}
                    <Spacer />
                    <Badge
                        ml='10px'
                        size="sm"
                        colorScheme={ProductShiftCounts[option.value] ? "teal" : "red"}
                        variant="solid"
                    >
                        {ProductShiftCounts[option.value] || '0'}
                    </Badge>
                </Flex>
            ),
        }));

        const receiveShiftOptions = shiftOptions.map(option => ({
            value: option.value,
            label: (
                <Flex flexDirection="row" alignItems="center" justifyContent="center">
                    {option.label}
                    <Spacer />
                    <Badge
                        ml='10px'
                        size="sm"
                        colorScheme={ReceiveShiftCounts[option.value] ? "teal" : "red"}
                        variant="solid"
                    >
                        {ReceiveShiftCounts[option.value] || '0'}
                    </Badge>
                </Flex>
            ),
        }));
        
        
    
        const nameTHOptions = Array.from(uniquenameTHValues).map(nameTH => ({
            value: nameTH,
            label: (
                <Flex flexDirection="row" alignItems="center" justifyContent="center">
                    {nameTH}
                    <Spacer />
                    <Badge 
                        ml='5px'
                        size="sm"
                        colorScheme="teal"
                        variant='solid'>
                        {nameTHCounts[nameTH]}
                    </Badge>
                </Flex>
            ),
        }));
    
        return { zcaOptions, nameTHOptions,productLengthOptions,receiveShiftOptions,productShiftOptions,ZonesCount, 
            labPassCount,  
            labWaitingCount, 
            labNotPassCount, 
            lockCount  };
    
    }, [safeZones]);


    
    const { zcaOptions, nameTHOptions,productLengthOptions,receiveShiftOptions,productShiftOptions,ZonesCount,labPassCount,  
        labWaitingCount, 
        labNotPassCount, 
        lockCount  } = searchOptions;

    const isDateInRange = (dateStr, range) => {
        if (!range[0] || !range[1]) return false; // ถ้าช่วงวันที่ไม่ได้กำหนด, ถือว่าผ่าน
        const date = parseISO(dateStr); // แปลงสตริงเป็นวันที่
        return isWithinInterval(date, { start: range[0], end: range[1] });
    };





    const updateFilterMap = useMemo(() => {


        let productLength = selectedProductLengths.map((selection) => selection.value * 100 );
        let zcaValues = selectedZcaLengths.map((selection) => selection.value )
        let namethValues = selectedNameTh.map((selection) => selection.value)
        let productShiftValues = selectedProductShifts.map((selection) => selection.value )
        let receiveShiftValues = selectedReceiveShifts.map((selection) => selection.value )
        let selectedLabStatuses = [labPassChecked, labWaitingChecked, labNotPassChecked].filter(status => status !== null);
        let lockSelect = lockChecked
        let matchingZones = [];
 
   
        if ( productLength && safeZones ) {
            let dataCount = 0; 
            let lappass = 0;
            let lapwait = 0;
            let lapnot = 0;
        Object.values(safeZones).forEach(zone => {
            Object.values(zone.levels || {}).forEach(level => {
                Object.values(level.sub_column || {}).forEach(subCol => {
                    if (subCol.data) {
                 
                        let product_length = subCol.data.product_length || null
                        let zca_on = subCol.data.zca_on || null
                        let name_th = subCol.data.name_th || null
                        let productDate = subCol.data.product_date || null
                        let receiveDate = subCol.data.receive_date || null
                        let productShift = subCol.data.product_shift || null
                        let receiveShift = subCol.data.receive_shift || null
                        let lab = subCol.data.lab !== undefined && subCol.data.lab !== null ? subCol.data.lab : null;
                        let lock = subCol.data.lock ;
             

                        let allConditionsMet = true
                            
                        if(productLength.length !== 0 && product_length && !productLength.includes(product_length)) {
                            allConditionsMet = false 
                        }
                        if(zcaValues.length !== 0 && zca_on && !zcaValues.includes(zca_on)) {
                            allConditionsMet = false 
                        }
                        if(namethValues.length !== 0 && name_th && !namethValues.includes(name_th)) {
                            allConditionsMet = false 
                        }
                        if ( productDateRange.length !== 0 && productDate && !isDateInRange(productDate, productDateRange)) {
                            allConditionsMet = false
                        }
                        if ( receiveDateRange.length !== 0 && receiveDate && !isDateInRange(receiveDate, receiveDateRange)) {
                            allConditionsMet = false
                        }
                        if(productShiftValues.length !== 0 && productShift && !productShiftValues.includes(productShift)) {
                            allConditionsMet = false 
                        }
                        if(receiveShiftValues.length !== 0 && receiveShift && !receiveShiftValues.includes(receiveShift)) {
                            allConditionsMet = false 
                        }
                        if (selectedLabStatuses.length == 0 || !selectedLabStatuses.includes(lab)) {
                            allConditionsMet = false;
                        }
                        if (lockSelect && lock !== true) {
                            allConditionsMet = false;
                        }
                        

                        if (allConditionsMet) {
                       
                            matchingZones.push(subCol.data.id); 
                        }

                        

                        
                    }
                });
            });
        });
        console.log('dataCount:',dataCount,lappass,lapnot,lapwait)
        return [...new Set(matchingZones)];
    }

    }, [selectedProductLengths,
        selectedProductShifts,
        selectedReceiveShifts,
        safeZones,
        selectedZcaLengths,
        selectedNameTh,
        productDateRange,
        receiveDateRange,
        labPassChecked,
        labWaitingChecked,
        labNotPassChecked,
        lockChecked,

    ]);

    useEffect(() => {
        startTransition(() => {
            setFilterMap(updateFilterMap);
        });
       
    }, [updateFilterMap]);
    
    const customOptionLabel = (option) => (
        <div>
          {option.label} ({option.count})
        </div>
      );

    const selectStyles = {
        control: (provided) => ({
          ...provided,
          width: '100%', 
        }),
        menuPortal: (base) => ({ ...base, zIndex: 9999 }),
      };

    const NotMatch = ZonesCount - filterMap.length >= 0 ? ZonesCount - filterMap.length : 'N/A';
    const Match = filterMap.length >= 0 ? filterMap.length : 'N/A';

    return (
        <>
          <Divider borderColor="blackAlpha.400" opacity='1' mb='4' />
            <Flex flex="1" direction="row" gap={4} pb='4' justifyContent='space-between' position='relative'>
               <Flex direction="row" gap={2}>
                <Flex direction='row' mx='10px' alignItems='center' gap='2'>
                <Circle size='20px' bg='rgba(135, 193, 128, 1)' />
                <Text> Matching </Text><Badge size='sm'>{Match}</Badge>
                </Flex>
                <Divider orientation="vertical" colorScheme='blackAplha.800' opacity='1' />
                <Flex direction='row' mx='10px' alignItems='center' gap='2'>
                <Circle size='20px' bg='rgba(213, 230, 212, 1)' />
                <Text> Not Matching </Text> <Badge>{NotMatch }</Badge>
                </Flex>
                </Flex>
                <Spacer />
         
                <Text>
                    Filter Map
                </Text>
                <Switch
                    size='md'
                    isChecked={isSwitchedOn}
                    onChange={(e) => setIsSwitchedOn(e.target.checked)}
                    colorScheme='teal'
                />

            </Flex>

            <Flex width="100%" gap={'4'} justifyContent={'center'} flexDirection={'row'} >

                <Flex flex="2" direction="column" gap={4}>
                    <Text fontWeight={'semibold'}> Production Time </Text>
                    <Flex flex="1" direction="row" gap={4} >

                        <Flex flexDirection={'column'} w='60%'  >


                            <RangeDatepicker
                                selectedDates={productDateRange}
                                onDateChange={setProductDateRange}
                                configs={datepickerConfigs}
                                propsConfigs={datepickerPropsConfigs}
                                placeholder='productDateRange'
                                zIndex='2'

                            />

                            <Flex flexDirection={'row'} justifyContent={'flex-end'} mt='-35px' mr='10px' >
                                <Button size="sm" onClick={resetProductRangeDates} mt='1'
                                    variant={'solid'} w='3rem' h='1.5rem'
                                    zIndex='3'

                                >
                                    reset
                                </Button>
                            </Flex>


                        </Flex>



                        <Box w='40%'>
                            <Select
                                isMulti
                                name="productShifts"
                                options={productShiftOptions}
                                className="basic-multi-select"
                                classNamePrefix="select"
                                placeholder="Product shifts"
                                value={selectedProductShifts}
                                onChange={setSelectedProductShifts}
                                menuPortalTarget={document.body}
                            />
                        </Box>
                    </Flex>

                    <Divider colorScheme='blackAplha.800' mb='2' />


                    <Text fontWeight={'semibold'}> Receive Time </Text>
                    <Flex flex="1" direction="row" gap={4} >
                        <Flex flexDirection={'column'} w='60%'  >
                            <RangeDatepicker
                                selectedDates={receiveDateRange}
                                onDateChange={setReceiveDateRange}
                                isClearable
                                configs={datepickerConfigs}
                                propsConfigs={receivePropsConfigs}

                            />
                            <Flex flexDirection={'row'} justifyContent={'flex-end'} mt='-35px' mr='10px' >
                                <Button size="sm" onClick={resetReceiveRangeDates} mt='1'
                                    variant={'solid'} w='3rem' h='1.5rem'
                                    fontWeight={'semibold'}
                                    zIndex='3'

                                >
                                    reset
                                </Button>
                            </Flex>

                        </Flex>

                        


                        <Box w='40%'>
                            <Select
                                isMulti
                                name="productShifts"
                                options={receiveShiftOptions}
                                className="basic-multi-select"
                                classNamePrefix="select"
                                placeholder="Receive shifts"
                                value={selectedReceiveShifts}
                                onChange={setSelectedReceiveShifts}
                                menuPortalTarget={document.body}

                            />
                        </Box>
                    </Flex>
                </Flex>
                <Center>

                    <Divider orientation="vertical" colorScheme='blackAplha.800' opacity='1' />

                </Center>


                <Flex flex="2" direction="column" gap={4}>

                    <Text fontWeight={'semibold'} > Search Product </Text>
                    <Select
                        isMulti
                        name="search"
                        options={nameTHOptions}
                        className="basic-multi-select"
                        classNamePrefix="select"
                        placeholder="name_th"
                        value={selectedNameTh}
                        onChange={setSelectedNameTh}
                        menuPortalTarget={document.body}
                        styles={selectStyles}
                    />

                    <Select
                        isMulti
                        name="search"
                        options={zcaOptions}
                        className="basic-multi-select"
                        classNamePrefix="select"
                        placeholder="zca"
                        value={selectedZcaLengths}
                        onChange={setSelectedZcaLengths}
                        menuPortalTarget={document.body}
                        styles={selectStyles}
                    />

                    <Select
                        isMulti
                        name="productLengths"
                        options={productLengthOptions}
                        className="basic-multi-select"
                        classNamePrefix="select"
                        placeholder="product width"
                        value={selectedProductLengths}
                        onChange={setSelectedProductLengths}
                        menuPortalTarget={document.body}
                    />

                    {/* <Select
                        isMulti
                        name="sizes"
                        options={sizeOptions}
                        className="basic-multi-select"
                        classNamePrefix="select"
                        placeholder="actual size"
                        value={selectedSizes}
                        onChange={setSelectedSizes}
                        menuPortalTarget={document.body}
                    /> */}

    
                </Flex>
                <Center>

<Divider orientation="vertical" colorScheme='blackAplha.800' opacity='1' />

</Center>

                <Flex flex='1' spacing={4} direction='column'>
                    <Text fontWeight={'semibold'} mb='4' > Lab Status </Text>

                    <Checkbox
                        colorScheme='teal'
                        isChecked={allChecked}
                        isIndeterminate={isIndeterminate}
                        onChange={handleParentChange}

                    >
                        Select All
                    </Checkbox>

                    <Flex spacing={6} direction='column' ml='4' >
                        <Flex direction={'row'}>

                            <Checkbox
                                colorScheme='teal'
                                isChecked={labPassChecked !== null}
                                onChange={handleLabPassChange}

                            >
                                Lab Pass

                            </Checkbox>
                            <Spacer />
                            <Badge minWidth='5' h='5' ml='5px' colorScheme={labPassCount > 0 ? "teal" : "red"} textAlign={'center'}>{labPassCount}</Badge>

                        </Flex>

                        <Flex direction={'row'}>

                            <Checkbox
                                colorScheme='teal'
                                isChecked={labWaitingChecked !== null}
                                onChange={handleLabWaitingChange}
                            >
                                Lab Waiting

                            </Checkbox>
                            <Spacer />
                            <Badge  minWidth='5' h='5' ml='5px' colorScheme={labWaitingCount > 0 ? "teal" : "red"} textAlign={'center'}>{labWaitingCount}</Badge>
                        </Flex>

                        <Flex direction={'row'}>

                            <Checkbox
                                colorScheme='teal'
                                isChecked={labNotPassChecked !== null}
                                onChange={handleLabNotPassChange}
                            >
                                Lab Not pass

                            </Checkbox>
                            <Spacer />
                            <Badge  minWidth='5' h='5' ml='5px' colorScheme={labNotPassCount > 0 ? "teal" : "red"} textAlign={'center'}>{labNotPassCount}</Badge>
                        </Flex>
                    </Flex>
                    <Flex direction={'row'}>

                        <Checkbox
                            colorScheme='teal'
                            isChecked={lockChecked !== null}
                            onChange={handleLockChange}
                        >
                            Lock
                        </Checkbox>
                        <Spacer />
                        <Badge minWidth='5' h='5'  ml='5px' colorScheme={lockCount > 0 ? "teal" : "red"} textAlign={'center'}>{lockCount}</Badge>
                    </Flex>


                </Flex>
            </Flex>
        </>
    );
}

export default FilterMenu;
