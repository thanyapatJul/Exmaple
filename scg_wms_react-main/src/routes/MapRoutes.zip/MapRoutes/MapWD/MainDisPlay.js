import React,{useState,lazy,} from "react";
import { Container, Flex, Button, useToast, Box, Spacer, VStack, HStack, Text, Tooltip } from "@chakra-ui/react";
import {useRecoilState} from 'recoil'
import MapDisplay from "./MapDisplayPage";
import { wdzonesAtom } from "../MapWithdrawPlan/WithdrawOverview/Atoms";
import Map_warehouse from './map_warehouse.svg';
import { useDisclosure } from '@chakra-ui/react';
import { Heading, Highlight, Circle, Collapse, Divider } from '@chakra-ui/react';
import { AiOutlineInfoCircle } from 'react-icons/ai';
import FilterMenu from './MapSearch.js';


// const MapDisplay = lazy(() => import('./MapDisplayPage.js'));


const WarehouseDisplay = React.memo(({ functionClick, reload }) => {
    const [zones, setZones] = useRecoilState(wdzonesAtom);
    const [zones_warehouse, setZones_warehouse] = useState([

        { id: 1, x: 570, y: 60,name: 'Warehouse_113', info: 'Information about Zone B',width: 75, height: 140,clippath: "polygon(0% 0%, 0% 0%, 100% 50%, 100% 100%, 0% 100%)", mapid:'1'   },
        { id: 2, x: 575, y: 270,name: 'Warehouse_W3', info: 'Information about Zone B',width: 112, height: 70, mapid:'2'   },
    
    ]);

    const { isOpen: openSearch, onToggle: toggleSearch } = useDisclosure();
    const [clickedZone, setClickedZone] = useState(null);
    const [hoveredZone, setHoveredZone] = useState(null);
    const toast = useToast();
    
    const handleZoneHover = (zoneId) => {
        const hoveredZone = zones_warehouse.find(item => item.mapid === zoneId);
        setHoveredZone(hoveredZone);
      };
    
    const handleZoneClick = (zoneId) => {

        setClickedZone(zoneId);

    };

    return (
        <>
                      <Container p='5' maxW='100%' bg='white' >
                        <Flex alignItems='flex-end' justifyContent='space-between' mb='4'>
                          <Heading>
                            {clickedZone ?
                              <Highlight
                                query={clickedZone}
                                styles={{ px: '2', py: '1', rounded: 'full', }}
                              >
                                {`Warehouse Layout : ${clickedZone}`}
                              </Highlight>
                              :
                              "Warehouse Layout"
                            }
                          </Heading>
                          
                          <Tooltip backgroundColor='white'
                            color='black'
                            placement='right-start'
                            label={
                              <VStack spacing={4} align="start" p='4' >
                                <HStack>
                                  <Circle size="24px" bg="rgba(234, 197, 197, 1)" />
                                  <Text fontSize="xs">สินค้าปกติ</Text>
                                </HStack>
                                <HStack>
                                  <Circle size="24px" bg="rgba(187, 143, 206, 1)" />
                                  <Text fontSize="xs">สินค้ารอ forklift ย้ายเข้า (ส่งยอด) </Text>
                                </HStack>
                                <HStack>
                                  <Circle size="24px" bg="rgba(245, 176, 65, 1)" />
                                  <Text fontSize="xs">สินค้ารอ forklift ย้ายออก (เบิกผลิต)</Text>
                                </HStack>
                                <HStack>
                                  <Circle size="24px" bg="rgba(174, 214, 241, 1)" />
                                  <Text fontSize="xs">สินค้ารอยืนยันข้อมูล</Text>
                                </HStack>
                                <HStack>
                                  <Circle size="24px" bg="rgba(211, 211, 211, 1)" />
                                  <Text fontSize="xs">พื้นที่ว่าง</Text>
                                </HStack>

                              </VStack>
                            }

                            hasArrow
                          >
                            <Button size='md' variant='ghost'>
                              <AiOutlineInfoCircle size={24} color='gray' /> 
                            </Button>
                          </Tooltip>
                          {clickedZone ?  <Button onClick={toggleSearch}>Filter </Button> : null }
                   

                          <Spacer />
                          <Button
                            size='sm'
                            colorScheme='gray'
                            mb='1.5'
                            onClick={() => {
                              setClickedZone(null);
                              setZones(null);
                            }}
                          >

                            ย้อนกลับ
                          </Button>
                        </Flex>
                        {clickedZone ?
                        <Collapse in={openSearch} animateOpacity>
                        <Box  p='4' > 
                      <FilterMenu zones={zones} />
     
                        </Box>
                        </Collapse>
                        : null }
                        <Divider m='1' />

                        <Box mt='4' bgColor='white'  h='80vh'  >

                          {clickedZone ? (
                            <Box  >
                         
                                <MapDisplay key={reload} 
                                Warehouse_id={clickedZone} 
                                handleZoneClick={functionClick}/>

                            </Box>
                          ) : (
                            <Box overflow='auto'>


                              <div
                                style={{
                                  width: '900px',
                                  height: '450px',
                                  position: 'relative',
                                  backgroundImage: `url(${Map_warehouse})`,
                                  backgroundSize: '100% 100%',
                                  backgroundPosition: 'center',
                                }}
                              >
                                {zones_warehouse.map((zone) => (
                                  <Tooltip
                                    hasArrow
                                    key={zone.id}
                                    label={` ${zone.name}`}
                                    aria-label='Zone tooltip'
                                  >
                                    <div
                                      style={{
                                        position: 'absolute',
                                        left: `${zone.x}px`,
                                        top: `${zone.y}px`,
                                        zIndex: 2,
                                      }}
                                      onMouseEnter={() => handleZoneHover(zone.mapid)}
                                      onMouseLeave={() => setHoveredZone(null)}
                                      onClick={() => handleZoneClick(zone.mapid, zone.name)}
                                    >
                                      <div
                                        style={{
                                          width: `${zone.width}px`,
                                          height: `${zone.height}px`,
                                          backgroundColor:
                                            hoveredZone === zone
                                              ? 'rgba(0, 0, 0, 0.5)'
                                              : 'transparent',
                                          clipPath: zone.clippath,
                                          border:
                                            hoveredZone === zone
                                              ? '1px solid black'
                                              : '2px solid black',
                                        }}
                                      ></div>
                                    </div>
                                  </Tooltip>
                                ))}
                              </div>


                            </Box>
                          )}
                        </Box>

                      </Container>
          </>


    );
});

export default WarehouseDisplay