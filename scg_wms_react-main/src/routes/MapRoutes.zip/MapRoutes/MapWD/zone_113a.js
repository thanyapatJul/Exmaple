import { atom } from 'recoil';





  export const colname_113a = [
    
    {  type_location:'VL' , x: 420, y: 100, column:'55' , mapid:'1',zone:'1',warehouse:'1',actual_size:'4' },
    {  type_location:'VL' , x: 420, y: 170, column:'56' , mapid:'2',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 240, column:'57' , mapid:'3',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 310, column:'58' , mapid:'4',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 380, column:'59' , mapid:'5',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 450, column:'60' , mapid:'6',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 520, column:'61' , mapid:'7',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 590, column:'62' , mapid:'8',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 660, column:'63' , mapid:'9',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 730,column:'64' , mapid:'10',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 800,column:'65' , mapid:'11',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 870,column:'66' , mapid:'12',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 940,column:'67' , mapid:'13',zone:'1',warehouse:'1',actual_size:'4'},
    {  type_location:'VL' , x: 420, y: 1010,column:'68' , mapid:'14',zone:'1',warehouse:'1',actual_size:'4'},
    {  x: 300, y: 1225,column:'69' , mapid:'15',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'4'},
    {  x: 220, y: 1225,column:'70' , mapid:'16',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'4'},
    {  x: 140, y: 1225,column:'71' , mapid:'17',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'4'},
    {  x: 60, y: 1225,column:'72' , mapid:'18',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'4'},



    // {  x: 480, y: 100, column:'54' , mapid:'15' },
    // {  x: 480, y: 170, column:'53' , mapid:'16'},
    // {  x: 480, y: 240, column:'52' , mapid:'17'},
    {  type_location:'VR' , x: 520, y: 310, column:'54' , mapid:'19',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VR' , x: 520, y: 380, column:'53' , mapid:'20',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VR' , x: 520, y: 450, column:'52' , mapid:'21',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 520, y: 520, column:'51' , mapid:'22',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 520, y: 590, column:'50' , mapid:'23',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VR' , x: 520, y: 660, column:'49' , mapid:'24',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 520, y: 730,column:'48' , mapid:'25',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 520, y: 800,column:'47' , mapid:'26',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 520, y: 870,column:'46' , mapid:'27',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 520, y: 940,column:'45' , mapid:'28',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 520, y: 1010,column:'44' , mapid:'29',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  x: 580, y: 1225,column:'43' , mapid:'30',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  x: 660, y: 1225,column:'42' , mapid:'31',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'3'},
    {  x: 740, y: 1225,column:'41' , mapid:'32',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'3'},
    {  x: 820, y: 1225,column:'40' , mapid:'33',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'3'},
    {  x: 900, y: 1225,column:'39' , mapid:'34',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'3'},




    {  type_location:'VL' , x: 1060, y: 800,column:'34' , mapid:'35',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 1060, y: 870,column:'35' , mapid:'36',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 1060, y: 940,column:'36' , mapid:'37',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 1060, y: 1010,column:'37' , mapid:'38',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VL' , x: 1060, y: 1080,column:'38' , mapid:'39',zone:'1',warehouse:'1',actual_size:'3'},

    {  type_location:'VR' , x: 1160, y: 870,column:'33' , mapid:'40',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 1160, y: 940,column:'32' , mapid:'41',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 1160, y: 1010,column:'31' , mapid:'42',zone:'1',warehouse:'1',actual_size:'2.4'},

    {  x: 1220, y: 1225,column:'30' , mapid:'43',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'3'},
    {  x: 1300, y: 1225,column:'29' , mapid:'44',width:'60px',height:'35px',type_location:'HT',zone:'1',warehouse:'1',actual_size:'3'},



    {  type_location:'VL' , x: 420, y: 1500, column:'1' , mapid:'45',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 420, y: 1570, column:'2' , mapid:'46',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 420, y: 1640, column:'3' , mapid:'47',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 420, y: 1710, column:'4' , mapid:'48',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VL' , x: 420, y: 1780, column:'5' , mapid:'49',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VL' , x: 420, y: 1850, column:'6' , mapid:'50',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 420, y: 1920, column:'7' , mapid:'51',zone:'1',warehouse:'1',actual_size:'3'},


    { type_location:'VR' , x: 520, y: 1500, column:'14' , mapid:'52',zone:'1',warehouse:'1',actual_size:'3'},
    { type_location:'VR' , x: 520, y: 1570, column:'13' , mapid:'53',zone:'1',warehouse:'1',actual_size:'3'},
    { type_location:'VR' , x: 520, y: 1640, column:'12' , mapid:'54',zone:'1',warehouse:'1',actual_size:'3'},
    { type_location:'VR' , x: 520, y: 1710, column:'11' , mapid:'55',zone:'1',warehouse:'1',actual_size:'2.4'},
    { type_location:'VR' , x: 520, y: 1780, column:'10' , mapid:'56',zone:'1',warehouse:'1',actual_size:'2.4'},
    { type_location:'VR' , x: 520, y: 1850, column:'9' , mapid:'57',zone:'1',warehouse:'1',actual_size:'3'},
    { type_location:'VR' , x: 520, y: 1920, column:'8' , mapid:'58',zone:'1',warehouse:'1',actual_size:'3'},

    {  type_location:'VL' , x: 900, y: 1500, column:'15' , mapid:'59',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 900, y: 1570, column:'16' , mapid:'60',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 900, y: 1640, column:'17' , mapid:'61',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 900, y: 1710, column:'18' , mapid:'62',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VL' , x: 900, y: 1780, column:'19' , mapid:'63',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VL' , x: 900, y: 1850, column:'20' , mapid:'64',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VL' , x: 900, y: 1920, column:'21' , mapid:'65',zone:'1',warehouse:'1',actual_size:'3'},

    {  type_location:'VR' , x: 1000, y: 1500, column:'28' , mapid:'66',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 1000, y: 1570, column:'27' , mapid:'67',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 1000, y: 1640, column:'26' , mapid:'68',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 1000, y: 1710, column:'25' , mapid:'69',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VR' , x: 1000, y: 1780, column:'24' , mapid:'70',zone:'1',warehouse:'1',actual_size:'2.4'},
    {  type_location:'VR' , x: 1000, y: 1850, column:'23' , mapid:'71',zone:'1',warehouse:'1',actual_size:'3'},
    {  type_location:'VR' , x: 1000, y: 1920, column:'22' , mapid:'72',zone:'1',warehouse:'1',actual_size:'3'},


  ];





  export const colname_w3 = [
    
    {  type_location:'VL' , x: 270, y: 100, column:'7' , mapid:'1',zone:'1',warehouse:'2',actual_size:'3' },
    {  type_location:'VL' , x: 270, y: 170, column:'6' , mapid:'2',zone:'1',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 270, y: 240, column:'5' , mapid:'3',zone:'1',warehouse:'2',actual_size:'4'},
    {  type_location:'VL' , x: 270, y: 310, column:'4' , mapid:'4',zone:'1',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 270, y: 380, column:'3' , mapid:'5',zone:'1',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 270, y: 450, column:'2' , mapid:'6',zone:'1',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 270, y: 520, column:'1' , mapid:'7',zone:'1',warehouse:'2',actual_size:'3'},


    {  type_location:'VR' , x: 340, y: 100, column:'8' , mapid:'8',zone:'1',warehouse:'2',actual_size:'3' },
    {  type_location:'VR' , x: 340, y: 170, column:'9' , mapid:'9',zone:'1',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 340, y: 240, column:'10' , mapid:'10',zone:'1',warehouse:'2',actual_size:'4'},
    {  type_location:'VR' , x: 340, y: 310, column:'11' , mapid:'11',zone:'1',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 340, y: 380, column:'12' , mapid:'12',zone:'1',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 340, y: 450, column:'13' , mapid:'13',zone:'1',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 340, y: 520, column:'14' , mapid:'14',zone:'1',warehouse:'2',actual_size:'3'},


    {  type_location:'VL' , x: 790, y: 100, column:'7' , mapid:'15',zone:'2',warehouse:'2',actual_size:'3' },
    {  type_location:'VL' , x: 790, y: 170, column:'6' , mapid:'16',zone:'2',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 790, y: 240, column:'5' , mapid:'17',zone:'2',warehouse:'2',actual_size:'4'},
    {  type_location:'VL' , x: 790, y: 310, column:'4' , mapid:'18',zone:'2',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 790, y: 380, column:'3' , mapid:'19',zone:'2',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 790, y: 450, column:'2' , mapid:'20',zone:'2',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 790, y: 520, column:'1' , mapid:'21',zone:'2',warehouse:'2',actual_size:'3'},


    {  type_location:'VR' , x: 860, y: 100, column:'8' , mapid:'22',zone:'2',warehouse:'2',actual_size:'3' },
    {  type_location:'VR' , x: 860, y: 170, column:'9' , mapid:'23',zone:'2',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 860, y: 240, column:'10' , mapid:'24',zone:'2',warehouse:'2',actual_size:'4'},
    {  type_location:'VR' , x: 860, y: 310, column:'11' , mapid:'25',zone:'2',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 860, y: 380, column:'12' , mapid:'26',zone:'2',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 860, y: 450, column:'13' , mapid:'27',zone:'2',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 860, y: 520, column:'14' , mapid:'28',zone:'2',warehouse:'2',actual_size:'3'},


    {  type_location:'VL' , x: 1470, y: 100, column:'7' , mapid:'29',zone:'3',warehouse:'2',actual_size:'3' },
    {  type_location:'VL' , x: 1470, y: 170, column:'6' , mapid:'30',zone:'3',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 1470, y: 240, column:'5' , mapid:'31',zone:'3',warehouse:'2',actual_size:'4'},
    {  type_location:'VL' , x: 1470, y: 310, column:'4' , mapid:'32',zone:'3',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 1470, y: 380, column:'3' , mapid:'33',zone:'3',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 1470, y: 450, column:'2' , mapid:'34',zone:'3',warehouse:'2',actual_size:'3'},
    {  type_location:'VL' , x: 1470, y: 520, column:'1' , mapid:'35',zone:'3',warehouse:'2',actual_size:'3'},


    {  type_location:'VR' , x: 1540, y: 100, column:'8' , mapid:'36',zone:'3',warehouse:'2',actual_size:'3' },
    {  type_location:'VR' , x: 1540, y: 170, column:'9' , mapid:'37',zone:'3',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 1540, y: 240, column:'10' , mapid:'38',zone:'3',warehouse:'2',actual_size:'4'},
    {  type_location:'VR' , x: 1540, y: 310, column:'11' , mapid:'39',zone:'3',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 1540, y: 380, column:'12' , mapid:'40',zone:'3',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 1540, y: 450, column:'13' , mapid:'41',zone:'3',warehouse:'2',actual_size:'3'},
    {  type_location:'VR' , x: 1540, y: 520, column:'14' , mapid:'42',zone:'3',warehouse:'2',actual_size:'3'},




    {  type_location:'HT' , x: 1770, y: 320, column:'14' , mapid:'43',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 1840, y: 320, column:'15' , mapid:'44',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 1910, y: 320, column:'16' , mapid:'45',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 1980, y: 320, column:'17' , mapid:'46',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2050, y: 320, column:'18' , mapid:'47',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2120, y: 320, column:'19' , mapid:'48',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2190, y: 320, column:'20' , mapid:'49',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2260, y: 320, column:'21' , mapid:'50',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2330, y: 320, column:'22' , mapid:'51',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2400, y: 320, column:'23' , mapid:'52',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2470, y: 320, column:'24' , mapid:'53',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2540, y: 320, column:'25' , mapid:'54',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2610, y: 320, column:'26' , mapid:'55',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HT' , x: 2680, y: 320, column:'27' , mapid:'56',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},





    {  type_location:'HB' , x: 1770, y: 355, column:'13' , mapid:'57',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 1840, y: 355, column:'12' , mapid:'58',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 1910, y: 355, column:'11' , mapid:'59',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 1980, y: 355, column:'10' , mapid:'60',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 2050, y: 355, column:'9' , mapid:'61',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 2120, y: 355, column:'8' , mapid:'62',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 2190, y: 355, column:'7' , mapid:'63',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 2260, y: 355, column:'6' , mapid:'64',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 2330, y: 355, column:'5' , mapid:'65',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 2400, y: 355, column:'4' , mapid:'66',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 2470, y: 355, column:'3' , mapid:'67',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 2540, y: 355, column:'2' , mapid:'68',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},
    {  type_location:'HB' , x: 2610, y: 355, column:'1' , mapid:'69',zone:'4',warehouse:'2',actual_size:'3' ,width:'60px',height:'35px'},





  ];



  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (1770, 345, 5, 3.0, 4, 6, 13, '02-4-1306', 3.0, 1, 2, null, 'HB'),
  // (1770, 380, 5, 3.0, 4, 5, 13, '02-4-1305', 3.0, 1, 2, null, 'HB'),
  // (1770, 415, 5, 3.0, 4, 4, 13, '02-4-1304', 3.0, 1, 2, null, 'HB'),
  // (1770, 450, 5, 3.0, 4, 3, 13, '02-4-1303', 3.0, 1, 2, null, 'HB'),
  // (1770, 485, 5, 3.0, 4, 2, 13, '02-4-1302', 3.0, 1, 2, null, 'HB'),
  // (1770, 520, 5, 3.0, 4, 1, 13, '02-4-1301', 3.0, 1, 2, null, 'HB');



  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (1840, 580, 5, 3.0, 4, 1, 12, '02-4-1201', 3.0, 1, 2, null, 'HB'),
  // (1840, 545, 5, 3.0, 4, 2, 12, '02-4-1202', 3.0, 1, 2, null, 'HB'),
  // (1840, 510, 5, 3.0, 4, 3, 12, '02-4-1203', 3.0, 1, 2, null, 'HB'),
  // (1840, 475, 5, 3.0, 4, 4, 12, '02-4-1204', 3.0, 1, 2, null, 'HB'),
  // (1840, 440, 5, 3.0, 4, 5, 12, '02-4-1205', 3.0, 1, 2, null, 'HB'),
  // (1840, 405, 5, 3.0, 4, 6, 12, '02-4-1206', 3.0, 1, 2, null, 'HB');


  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (1910, 580, 5, 3.0, 4, 1, 11, '02-4-1101', 3.0, 1, 2, null, 'HB'),
  // (1910, 545, 5, 3.0, 4, 2, 11, '02-4-1102', 3.0, 1, 2, null, 'HB'),
  // (1910, 510, 5, 3.0, 4, 3, 11, '02-4-1103', 3.0, 1, 2, null, 'HB'),
  // (1910, 475, 5, 3.0, 4, 4, 11, '02-4-1104', 3.0, 1, 2, null, 'HB'),
  // (1910, 440, 5, 3.0, 4, 5, 11, '02-4-1105', 3.0, 1, 2, null, 'HB'),
  // (1910, 405, 5, 3.0, 4, 6, 11, '02-4-1106', 3.0, 1, 2, null, 'HB');
  

  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (1980, 580, 5, 3.0, 4, 1, 10, '02-4-1001', 3.0, 1, 2, null, 'HB'),
  // (1980, 545, 5, 3.0, 4, 2, 10, '02-4-1002', 3.0, 1, 2, null, 'HB'),
  // (1980, 510, 5, 3.0, 4, 3, 10, '02-4-1003', 3.0, 1, 2, null, 'HB'),
  // (1980, 475, 5, 3.0, 4, 4, 10, '02-4-1004', 3.0, 1, 2, null, 'HB'),
  // (1980, 440, 5, 3.0, 4, 5, 10, '02-4-1005', 3.0, 1, 2, null, 'HB'),
  // (1980, 405, 5, 3.0, 4, 6, 10, '02-4-1006', 3.0, 1, 2, null, 'HB');


  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (2050, 580, 5, 3.0, 4, 1, 9, '02-4-901', 3.0, 1, 2, null, 'HB'),
  // (2050, 545, 5, 3.0, 4, 2, 9, '02-4-902', 3.0, 1, 2, null, 'HB'),
  // (2050, 510, 5, 3.0, 4, 3, 9, '02-4-903', 3.0, 1, 2, null, 'HB'),
  // (2050, 475, 5, 3.0, 4, 4, 9, '02-4-904', 3.0, 1, 2, null, 'HB'),
  // (2050, 440, 5, 3.0, 4, 5, 9, '02-4-905', 3.0, 1, 2, null, 'HB'),
  // (2050, 405, 5, 3.0, 4, 6, 9, '02-4-906', 3.0, 1, 2, null, 'HB');


  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (2120, 580, 5, 3.0, 4, 1, 8, '02-4-801', 3.0, 1, 2, null, 'HB'),
  // (2120, 545, 5, 3.0, 4, 2, 8, '02-4-802', 3.0, 1, 2, null, 'HB'),
  // (2120, 510, 5, 3.0, 4, 3, 8, '02-4-803', 3.0, 1, 2, null, 'HB'),
  // (2120, 475, 5, 3.0, 4, 4, 8, '02-4-804', 3.0, 1, 2, null, 'HB'),
  // (2120, 440, 5, 3.0, 4, 5, 8, '02-4-805', 3.0, 1, 2, null, 'HB'),
  // (2120, 405, 5, 3.0, 4, 6, 8, '02-4-806', 3.0, 1, 2, null, 'HB');


  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (2190, 580, 5, 3.0, 4, 1, 7, '02-4-701', 3.0, 1, 2, null, 'HB'),
  // (2190, 545, 5, 3.0, 4, 2, 7, '02-4-702', 3.0, 1, 2, null, 'HB'),
  // (2190, 510, 5, 3.0, 4, 3, 7, '02-4-703', 3.0, 1, 2, null, 'HB'),
  // (2190, 475, 5, 3.0, 4, 4, 7, '02-4-704', 3.0, 1, 2, null, 'HB'),
  // (2190, 440, 5, 3.0, 4, 5, 7, '02-4-705', 3.0, 1, 2, null, 'HB'),
  // (2190, 405, 5, 3.0, 4, 6, 7, '02-4-706', 3.0, 1, 2, null, 'HB');

  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (2260, 580, 5, 3.0, 4, 1, 6, '02-4-601', 3.0, 1, 2, null, 'HB'),
  // (2260, 545, 5, 3.0, 4, 2, 6, '02-4-602', 3.0, 1, 2, null, 'HB'),
  // (2260, 510, 5, 3.0, 4, 3, 6, '02-4-603', 3.0, 1, 2, null, 'HB'),
  // (2260, 475, 5, 3.0, 4, 4, 6, '02-4-604', 3.0, 1, 2, null, 'HB'),
  // (2260, 440, 5, 3.0, 4, 5, 6, '02-4-605', 3.0, 1, 2, null, 'HB'),
  // (2260, 405, 5, 3.0, 4, 6, 6, '02-4-606', 3.0, 1, 2, null, 'HB');


  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (2330, 580, 5, 3.0, 4, 1, 5, '02-4-501', 3.0, 1, 2, null, 'HB'),
  // (2330, 545, 5, 3.0, 4, 2, 5, '02-4-502', 3.0, 1, 2, null, 'HB'),
  // (2330, 510, 5, 3.0, 4, 3, 5, '02-4-503', 3.0, 1, 2, null, 'HB'),
  // (2330, 475, 5, 3.0, 4, 4, 5, '02-4-504', 3.0, 1, 2, null, 'HB'),
  // (2330, 440, 5, 3.0, 4, 5, 5, '02-4-505', 3.0, 1, 2, null, 'HB'),
  // (2330, 405, 5, 3.0, 4, 6, 5, '02-4-506', 3.0, 1, 2, null, 'HB');


  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (2400, 580, 5, 3.0, 4, 1, 4, '02-4-401', 3.0, 1, 2, null, 'HB'),
  // (2400, 545, 5, 3.0, 4, 2, 4, '02-4-402', 3.0, 1, 2, null, 'HB'),
  // (2400, 475, 5, 3.0, 4, 3, 4, '02-4-403', 3.0, 1, 2, null, 'HB'),
  // (2400, 510, 5, 3.0, 4, 4, 4, '02-4-404', 3.0, 1, 2, null, 'HB'),
  // (2400, 545, 5, 3.0, 4, 5, 4, '02-4-405', 3.0, 1, 2, null, 'HB'),
  // (2400, 580, 5, 3.0, 4, 6, 4, '02-4-406', 3.0, 1, 2, null, 'HB');


  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (2470, 580, 5, 3.0, 4, 1, 3, '02-4-301', 3.0, 1, 2, null, 'HB'),
  // (2470, 545, 5, 3.0, 4, 2, 3, '02-4-302', 3.0, 1, 2, null, 'HB'),
  // (2470, 475, 5, 3.0, 4, 3, 3, '02-4-303', 3.0, 1, 2, null, 'HB'),
  // (2470, 510, 5, 3.0, 4, 4, 3, '02-4-304', 3.0, 1, 2, null, 'HB'),
  // (2470, 545, 5, 3.0, 4, 5, 3, '02-4-305', 3.0, 1, 2, null, 'HB'),
  // (2470, 580, 5, 3.0, 4, 6, 3, '02-4-306', 3.0, 1, 2, null, 'HB');


  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (2540, 580, 5, 3.0, 4, 1, 2, '02-4-201', 3.0, 1, 2, null, 'HB'),
  // (2540, 545, 5, 3.0, 4, 2, 2, '02-4-202', 3.0, 1, 2, null, 'HB'),
  // (2540, 475, 5, 3.0, 4, 3, 2, '02-4-203', 3.0, 1, 2, null, 'HB'),
  // (2540, 510, 5, 3.0, 4, 4, 2, '02-4-204', 3.0, 1, 2, null, 'HB'),
  // (2540, 545, 5, 3.0, 4, 5, 2, '02-4-205', 3.0, 1, 2, null, 'HB'),
  // (2540, 580, 5, 3.0, 4, 6, 2, '02-4-206', 3.0, 1, 2, null, 'HB');


  // INSERT INTO wms_map_location_info
  // (x_position, y_position, max_level, size, zone, row, column, mapid, actual_size, sub_column, warehouse_id, id, type_location)
  // VALUES
  // (2610, 580, 5, 3.0, 4, 1, 1, '02-4-101', 3.0, 1, 2, null, 'HB'),
  // (2610, 545, 5, 3.0, 4, 2, 1, '02-4-102', 3.0, 1, 2, null, 'HB'),
  // (2610, 475, 5, 3.0, 4, 3, 1, '02-4-103', 3.0, 1, 2, null, 'HB'),
  // (2610, 510, 5, 3.0, 4, 4, 1, '02-4-104', 3.0, 1, 2, null, 'HB'),
  // (2610, 545, 5, 3.0, 4, 5, 1, '02-4-105', 3.0, 1, 2, null, 'HB'),
  // (2610, 580, 5, 3.0, 4, 6, 1, '02-4-106', 3.0, 1, 2, null, 'HB');

