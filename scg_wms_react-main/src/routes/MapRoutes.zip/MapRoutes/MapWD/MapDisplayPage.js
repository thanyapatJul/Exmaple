import React, { useState, useEffect, useRef, useCallback, } from 'react';
import { useSetRecoilState, useRecoilValue, useRecoilState } from 'recoil';
import { wdproductSelectedState,WDreloadState,wdtagClickedState, wdMapfilterState,wdSwitchedState,wdmulticlickedZone_Info as multiclickedZoneInfoAtom, wdzonesAtom, zonestempWdState } from '../MapWithdrawPlan/WithdrawOverview/Atoms';
import { colname_113a,colname_w3 } from './zone_113a';
import _ from 'lodash';
import Tippy from '@tippyjs/react';
import 'tippy.js/dist/tippy.css';
import BiLoader from '../ETC/BiLoader';
import {  useMemo } from 'react';

import { IoMdClose } from "react-icons/io";
import './style.css'
import 'tippy.js/themes/light.css';
import Swal from 'sweetalert2';
import {
  useToast,
  Box,
  Text,
  Stack,
  Select,
  ButtonGroup,
  Button,
  Popover,
  PopoverTrigger,
  Tag,
  PopoverContent,
  FocusLock,
  PopoverArrow,
  PopoverCloseButton,
  Divider,
  FormControl,
  FormLabel,
  List,
  Tooltip,
  ListItem,
  HStack,
  VStack,
  StackDivider,
  Radio,
  RadioGroup,
  CloseIcon,
  useRadioGroup,
  useRadio,
  Circle,

} from "@chakra-ui/react";
import { useDisclosure } from "@chakra-ui/react";
import Map_a from './map_w113.png';
import Map_b from './map_w3.png';
import { ReactZoomPanPinch, TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";
import Axios from 'axios';
Axios.defaults.xsrfCookieName = 'csrftoken';
Axios.defaults.xsrfHeaderName = 'X-CSRFToken';
Axios.defaults.withCredentials = true;

const client = Axios.create({
  baseURL: `${process.env.REACT_APP_API_URL}`
});


const ZoneDataHandler = ({  setZones, setIsLoading, warehouse_id, setZones_V }) => {
  const column_113 = useMemo(() => colname_113a, []);
  const column_w3 = useMemo(() => colname_w3, []);
  const zones_temp = useRecoilValue(zonestempWdState)


  /////////////////////////////////////  First Mount   /////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////

  useEffect(() => {

    if (warehouse_id === '1') {
      setZones_V(column_113)
    }
    if (warehouse_id === '2'){
      setZones_V(column_w3)
    }

    
    async function fetchDataAndUpdateZones() {
      setIsLoading(true);
      
      try {
        const [mapResponse, infoResponse] = await Promise.all([
          client.get(`/wms/api/get_map_location_info/?warehouse_id=${warehouse_id}`),
          client.get('/wms/api/map_management/'),
        ]);

        const mapData = await mapResponse.data;
        const infoData = await infoResponse.data;

        const createLookup = (data) => {
          const lookup = new Map();
          data.forEach(item => {
            const key = `${item.mapid}-${item.level}-${item.sub_column}`;
            lookup.set(key, item);
          });
          return lookup;
        };
        
        const zonesTempLookup = createLookup(zones_temp);
        const infoDataLookup = createLookup(infoData);



        let newZones = mapData.map((zone) => {
          let levels = {};
        
          for (let i = 1; i <= zone.max_level; i++) {
            levels[i] = { sub_column: {} };
        
            for (let j = 1; j <= zone.sub_column; j++) { 
              const key = `${zone.mapid}-${i}-${j}`;
              let matchingTempZone = zonesTempLookup.get(key) || infoDataLookup.get(key);
              // กรอง map_approve ที่เป็น 0 ใน tooltip
              if (matchingTempZone?.map_approve === 0){
                matchingTempZone = null;
              }

              levels[i].sub_column[j] = {
                data: matchingTempZone || null
              };
            }
          }
        
          return {
            ...zone,
            levels,
          };
        });
        
        
      
        setZones(newZones);
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setIsLoading(false);  // Set loading to false even on failure
      }

    }


    fetchDataAndUpdateZones();
    
  }, [warehouse_id, column_113, column_w3, zones_temp, setZones, setIsLoading, setZones_V]);



  return null; 

};





const BackGroundDisplay = (Warehouse_id) => {

  const defaultStyle = {
    position: 'relative',
    backgroundColor: 'white',
    borderRadius: '10px',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
  };


  const warehouseStyles = {
    1: {
      width: '2080px',
      height: '2080px',
      backgroundImage: `url(${Map_a})`
    },
    2: {
      width: '3000px',
      height: '1080px',

    },

  };




  return {
    ...defaultStyle,
    ...warehouseStyles[Warehouse_id]
  };
}

const Form = ({ zone, handleClose }) => {
  const [reload, setReload] = useRecoilState(WDreloadState);
  const [oldData, setOldData] = useState(null);
  const zones = useRecoilValue(wdzonesAtom);
  const zone_no = parseFloat(zone.column); 
  const maxLevelOptions = ['1', '2', '3', '4', '5', '6', '7'];
  const sizeOptions = [1.2, 2.4, 3, 4];
  const [maxLevel, setMaxLevel] = useState(zone.max_level);
  const [size, setSize] = useState(zone.size);
  const zone_warehouse = parseFloat(zone.zone)
  const warehouse = parseFloat(zone.warehouse)
  console.log('zone_warehouse:',zone_warehouse)




  useEffect(() => {
    const matchingColumns = zones?.filter(item => item.column === zone_no);
    if (matchingColumns && matchingColumns.length > 0) {
      const newOldData = matchingColumns[0];
      if (!_.isEqual(oldData, newOldData)) {
        let str_maxLevel = (newOldData.max_level).toString()
        let str_size = (newOldData.size).toString()
        setOldData(newOldData);
        setMaxLevel(str_maxLevel); 
        setSize(str_size); 
      }
    }
  }, [zones, zone_no, oldData]);


  const computeSubColumn = (selectedSize, actualSize) => {
    const quotient = actualSize / selectedSize;
    const result = Math.floor(quotient);
    return result >= 1 ? result : 0;
  };

  const handleSave = () => {
    const sub_col = computeSubColumn(size, zone.actual_size);
    
    // Check if selected size is larger than actual size
    if (size > zone.actual_size) {
      Swal.fire({
        icon: 'error',
        title: 'เลือก Size ไม่ถูกต้อง!',
        text: 'ห้ามเลือก ​Size ขนาดมากกว่า Actual Size',
      });
      return;
    }

    // Check if there are existing levels with data
    const hasExistingLevels = zones.some(z =>
      z.column === zone_no &&
      Object.values(z.levels || {}).some(level =>
        Object.values(level.sub_column || {}).some(sub =>
          sub.data != null
        )
      )
    );

    if (hasExistingLevels) {
      Swal.fire({
        icon: 'error',
        title: 'ไม่สามารถอัพเดทข้อมูลได้!',
        text: 'ยังมีข้อมูลอยู่ใน column หลงเหลืออยู่ กรุณาย้ายข้อมูลทั้งหมดออกจาก column',
      });
      return;
    }

    // Construct data object for API call
    const data = {
      column: zone_no,
      max_level: maxLevel,
      size: size,
      sub_column: sub_col,
      zone: zone_warehouse,
      warehouse: warehouse,
    };

    // API call to update data
    client.post('/wms/api/update_map_location_info/', data)
      .then(response => {
        handleClose();
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Your Size is now updated',
        }).then(() => {
          setReload(prev => !prev); 
        }); 
      })
      .catch(error => {
        console.error("There was an error saving the data", error);
      });

  };



const RadioCard = (props) => {
  const { getInputProps, getRadioProps } = useRadio(props);

  const input = getInputProps();
  const checkbox = getRadioProps();

  return (
    <Box as="label">
      <input {...input} />
      <Box
        {...checkbox}
        cursor="pointer"
        borderWidth="1px"
        borderRadius="md"
        boxShadow="md"
        _checked={{
          bg: "yellow.600",
          color: "white",
          borderColor: "yellow.600",
        }}
        _focus={{
          boxShadow: "outline",
        }}
        px={2}
        py={1}
      >
        {props.children}
      </Box>
    </Box>
  );
};

const { getRootProps, getRadioProps } = useRadioGroup({
  name: 'maxLevel',
  value: maxLevel,
  onChange: setMaxLevel,
});

const sizeGroup = useRadioGroup({
  name: 'size',
  value: size,
  onChange: setSize,
});

const sizeGroupProps = sizeGroup.getRootProps();
const group = getRootProps();

   return (
    <Stack spacing={4}>
      {/* Max-level Select */}
      {maxLevel && (
      <FormControl as="fieldset">
        <FormLabel as="legend" htmlFor='max_level'>Max-level</FormLabel>
        <HStack {...group} spacing={4}>
          {maxLevelOptions.map((value) => {
            const radio = getRadioProps({ value: value.toString() });
            return (
              <RadioCard key={value} {...radio}>
                {value}
              </RadioCard>
            );
          })}
        </HStack>
      </FormControl>
    )}
      {/* Size Select */}
      <FormControl as="fieldset">
        <FormLabel as="legend" htmlFor='size'>Product Width (M)</FormLabel>
        <HStack {...sizeGroupProps} spacing={4}>
          {sizeOptions.map(optionSize => {
            const radio = sizeGroup.getRadioProps({ value: optionSize.toString() });
            return (
              <RadioCard key={optionSize} {...radio}>
                {optionSize}
              </RadioCard>
            );
          })}
        </HStack>
      </FormControl>

      {/* Save Button */}
      <Button colorScheme='teal' onClick={handleSave}>
        Save
      </Button>
    </Stack>
  );
};



const renderIcons = (count, isHorizontal,size) => {
  const StackCustom = isHorizontal ? HStack : VStack;  
  const mainWidth = isHorizontal ? '60px' : '10px';  
  const mainHeight = isHorizontal ? '10px' : '60px';  

  const getColor = (size) => {
    switch (size) {
      case 1.2: return '#EEE9DA';  
      case 2.4: return '#BDCDD6'; 
      case 3: return '#93BFCF';  
      case 4: return '#6096B4';  
      default: return 'rgba(44, 62, 80, 1)';  
    }
  };

  return (
    <StackCustom height={mainHeight} width={mainWidth} spacing="4px" align="center" justify="center" py='2px'>
      {Array.from({ length: count }).map((_, idx) => {
        const divSize = 60 / count;
        const backgroundColor = getColor(size);
        return (
          <div 
            key={idx} 
            style={{ 
              backgroundColor: backgroundColor,
              width: isHorizontal ? `${divSize}px` : '10px',
              height: isHorizontal ? '10px' : `${divSize}px`  
            }}
          />
        );
      })}
    </StackCustom>
  );
};


const renderIconByName = (name, isHorizontal,size) => {
  switch (name) {
    case '1':
      return renderIcons(1, isHorizontal,size);
    case '2':
      return renderIcons(2, isHorizontal,size);
    case '3':
      return renderIcons(3, isHorizontal,size);
    // Additional cases as needed
    default:
      return 'N/A';
  }
};



const getSubColumnName = (zone, zones) => {
  let column = parseInt(zone.column)
  let zone_warehouse = parseInt(zone.zone)
  const matchingZones = zones.filter(z => z.column === column && z.zone === zone_warehouse);
  const isHorizontal = zone.type_location === 'HT' || zone.type_location === 'HB';
  let size = matchingZones?.[0].size 

  const groupBySubColumn = matchingZones.reduce((acc, currentZone) => {
    if (!acc[currentZone.sub_column]) {
      acc[currentZone.sub_column] = 0;
    }
    acc[currentZone.sub_column]++;
    return acc;
  }, {});

  // รายชื่อ sub_column ที่ถูก group by
  const subColumnNames = Object.keys(groupBySubColumn);

  // ถ้ามีมากกว่า 1 sub_column รีเทิร์น icon สำหรับ 'N/A'
  if (subColumnNames.length > 1) {
    return renderIconByName('N/A'); // ที่นี้ควรมี icon สำหรับ 'N/A' ถ้าไม่มีจะ return null
  }

  // มิฉะนั้นรีเทิร์น icon ตามชื่อ sub_column
  return renderIconByName(subColumnNames[0], isHorizontal,size);
}


const ZoneTagWithPopover = ({ zone, handleOpen, handleClose }) => {
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);
  const [zones, setZones] = useRecoilState(wdzonesAtom)

  const renderedIcon = React.useMemo(() => getSubColumnName(zone, zones), [zone, zones]);
  let iconLeft;
  switch (zone.type_location) {
    case 'VL':
      iconLeft = `calc(${zone.x}px - 15px)`;
      break;
    case 'VR':
      iconLeft = `calc(${zone.x}px + 40px)`;
      break;
    case 'HT':
    case 'HB':
      iconLeft = `${zone.x}px`;
      break;
    default:
      // Handle other cases or default positioning
      iconLeft = `calc(${zone.x}px - 15px)`;
      break;
  }

  let iconTop = zone.type_location === 'HT' 
  ? `calc(${zone.y}px - 10px)`
  : zone.type_location === 'HB' 
    ? `calc(${zone.y}px + 40px)`
    : `${zone.y}px`;

  const togglePopover = () => {
    setIsPopoverOpen(!isPopoverOpen);
  };

  return (
    <>
      <div
        style={{
          position: 'absolute',
          left: iconLeft,
          top: iconTop,
        }}
      >
        {renderedIcon}
      </div>

      <Tippy
      theme= 'light'
      width='300px'
        content={(
          <div style={{ position: 'relative', padding: '15px', backgroundColor: 'white' }}>
          <IoMdClose
            style={{ position: 'absolute', top: '5px', right: '5px', cursor: 'pointer', fontSize: '20px' }}
            onClick={() => setIsPopoverOpen(false)}
          />
            <Text>Column: {zone.column}</Text>
            <Text>Actual_size: {zone.actual_size} M.</Text>
            
            <Divider m='1' />
            <Form
              zonecol={zone.column}
              zone={zone}
              handleClose={() => setIsPopoverOpen(false)}
            />
          </div>
        )}
        interactive
        visible={isPopoverOpen}
        onClickOutside={() => setIsPopoverOpen(false)}
      >

      
        <div
          style={{
            position: 'absolute',
            left: `${zone.x}px`,
            top: `${zone.y}px`,
            width: zone.width || '35px',
            height: zone.height || '60px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Tag
            variant="solid"
            colorScheme="teal"
            cursor='pointer'
            onClick={togglePopover}
          >
            {zone.column}
          </Tag>
        </div>
      </Tippy>
    </>
  );
}

const generateInitialData = (levels) => {
  const zcaData = {};

  Object.values(levels).forEach(levelData => {
    Object.values(levelData.sub_column).forEach(subCol => {
      if (subCol.data?.name_th) {
        if (!zcaData[subCol.data.name_th]) {
          // สร้างสีสุ่ม
          const randomColor = `#${Math.floor(Math.random() * 16777215).toString(16)}`;
          zcaData[subCol.data.name_th] = randomColor;
        }
      }
    });
  });

  return zcaData;
};

const renderGroupedLevels = (levels, initialData) => {
  const colors = ["#F99417", "#4D4C7D", "#125B50", "#DD4A48", "#79B4B7"];
  const zcaColors = {};

  // Assign colors sequentially to ZCAs
  Object.keys(initialData).forEach((zca, index) => {
    zcaColors[zca] = colors[index % colors.length];
  });

  // Create a display for each color
  const zcaDisplays = colors.map((color, index) => {
    const zca = Object.keys(initialData).find(zca => zcaColors[zca] === color);
    const displayText = zca || '-';
    const circleOpacity = displayText === '-' ? 0.5 : 1; // Adjust opacity based on displayText

    return (
      <Box key={index} display="flex" justifyContent="space-between" alignItems="center" mb="2">
        <Circle bgColor={color} width="20px" height="20px" opacity={circleOpacity}></Circle>
        <Box fontSize={'15px'} fontWeight={'500'} flex="1" ml='1'>
          : {displayText}
        </Box>
      </Box>
    );
  });






  const levelDisplays = Object.values(levels).map((levelData, index) => (
    <ListItem key={index} whiteSpace='nowrap'>

      <HStack spacing={2}>
        <Box minW='60px'>
          <Text as="span" color="white.500">Level {index + 1}:</Text>
        </Box>
        <Box w='150px' display="flex">
          {Object.values(levelData.sub_column).map((subCol, subIndex) => (
            <Box
              flex='1'
              mx='1'
              key={subIndex}
              // width="40px"
              height="25px"
              position="relative"
              background={subCol.data
                ? zcaColors[subCol.data.name_th]
                : 'grey'}
              display="flex"
              alignItems="center"
              justifyContent="center"
              fontSize="10px"
              color={'white'} // กำหนดสีตัวอักษรเป็นขาวหากเป็นกล่องสีเทา
            >
              {
                subCol.data
                  ? subCol.data.pcsperpallet % subCol.data.qty !== 0
                    ? subCol.data.qty
                    : ""
                  : "-"
              }
              {/* <Box bgColor='teal' position={'absolute'} right="0" px='2'> Lab </Box> */}
            </Box>
          ))}
        </Box>

      </HStack>
    </ListItem>
  ));

  // รวมการแสดงผลทั้งสองส่วนเข้าด้วยกัน
  return (
    <Box p='4' >
      <HStack divider={<StackDivider borderColor='gray.800' orientation='vertical' />}>
        <List>
          <VStack divider={<StackDivider borderColor='gray.200' />} flexDirection="column-reverse">

            {levelDisplays}


          </VStack>
        </List>

        <Box p='4' >
          {zcaDisplays}
        </Box>
      </HStack>

    </Box>
  );
};


const MemoizedComponent = React.memo(function RenderLevels({levels}) {
  const initialData = generateInitialData(levels);
  return renderGroupedLevels( levels, initialData);
}, (prevProps, nextProps) => {
  return _.isEqual(prevProps.zone, nextProps.zone) && _.isEqual(prevProps.levels, nextProps.levels);
});



const RenderZone = React.memo(({ zone,handleZoneClick }) => {



  

  const productSelected= useRecoilValue(wdproductSelectedState);
  const multiclickedZone_Info = useRecoilValue(multiclickedZoneInfoAtom)
  const [tagClicked,setTagClicked] = useRecoilState(wdtagClickedState);
  const mapFilter = useRecoilValue(wdMapfilterState);
  const filterAction = useRecoilValue(wdSwitchedState);
  const getZoneColor = (zone, levelIndex, subColIndex) => {
    
    const levelData = zone.levels[levelIndex];
    const subColData = levelData && levelData.sub_column[subColIndex];

    if (filterAction) {

      if (mapFilter.includes(subColData.data?.id)) {

        return 'rgba(135, 193, 128, 1)';
      }
      if (subColData && subColData.data != null) {
        return 'rgba(213, 230, 212, 1)';
      }

    }

    if (subColData && subColData.data && subColData.data.success === false)  {
        return 'rgba(124, 196, 244, 1)'
    } else {

        //hasMapApproveFalse
      if (subColData && subColData.data && subColData.data.map_approve === 5) {
        return 'rgba(187, 143, 206, 1)'
      } 
        //hasWithdraw
      if (subColData && subColData.data && subColData.data.map_approve === 4) {
        return 'rgba(245, 176, 65, 1)'
      } 

      if (subColData && subColData.data && subColData.data.map_approve === 1) {

          return 'rgba(234, 197, 197, 1)'

      }



    }
    


    return 'rgba(211, 211, 211, 1)';
  };

  function getBorderStyle(zone, multiclickedZone_Info, tagClicked) {
    // Check if tagClicked is defined and its mapid matches zone.mapid
    if (tagClicked && tagClicked.mapid === zone.mapid) {
        return '4px solid rgba(23, 165, 137 )'; // Return green border for matching tagClicked.mapid
    }

    // Check if multiclickedZone_Info is an object and contains zone.mapid
    if (multiclickedZone_Info && Object.keys(multiclickedZone_Info).includes(zone.mapid)) {
        return '3px solid rgb(99, 99, 99  )'; // Return default solid border
    }

    return 'none'; // Return no border if neither condition is met
}



  return (
    <React.Fragment>
    <Tippy
      theme= 'light'
      maxWidth="none"
      content={    
        <>
        {zone.column}
        { zone.row }
        <MemoizedComponent levels={zone.levels}  />
        
        </>
     
  }
      placement="right"
    >

        <div
          className='Zonestooltips'
          key={zone.mapid}
          style={{
              position: 'absolute',
              left: `${zone.x_position}px`,
              top: `${zone.y_position}px`,
              width: zone.type_location === 'VL' || zone.type_location === 'VR' ? '35px' : '60px',
              height: zone.type_location === 'VL' || zone.type_location === 'VR' ? '60px' : '35px',
              overflow:'hidden',
              display: 'flex',
              cursor: 'pointer',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'space-evenly',
              border: getBorderStyle(zone, multiclickedZone_Info,tagClicked)
          }}
          onClick={() => handleZoneClick(zone,productSelected,multiclickedZone_Info,tagClicked,setTagClicked)}
        >



        <div
          className='ZoneGrid'
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${zone.sub_column || 1}, 1fr)`, // Create columns for sub_column
            gridTemplateRows: `repeat(${zone.max_level || 1}, 1fr)`,
            gap: '1px',
          }}
        >
          {Object.keys(zone.levels).reverse().map((levelKey) => {
            const level = zone.levels[levelKey];

            const coloredCells = Object.keys(level.sub_column || {}).map((subColKey) => {
              const subColIndex = parseInt(subColKey, 10); 
              const colKey = `${levelKey}-${subColKey}+${zone.mapid}`;

              const baseWidth = zone.type_location === 'VL' || zone.type_location === 'VR' ? 35 : 60;
              const baseHeight = zone.type_location === 'VL' || zone.type_location === 'VR' ? 60 : 35;
              
              const newWidth = baseWidth / parseInt(zone.sub_column) - 2;
              const newHeight = baseHeight / parseInt(zone.max_level) - 2;
              
       
              return (
                <div
                  key={colKey}
                  style={{
                    background: getZoneColor(zone, levelKey, subColIndex),
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: `${newHeight}px`,
                    width: `${newWidth}px`,
                  }}
                >
                </div>
              );
            });

            return coloredCells;
          })}

        </div>
        {/* {Object.keys(multiclickedZone_Info).includes(zone.mapid) && (<IoMdCheckmark />)} */}
      </div>


    </Tippy>
    </React.Fragment>
  );
}, (prevProps, nextProps) => {

  return _.isEqual(prevProps.zone, nextProps.zone);
})


const MapDisplay = React.memo(({ Warehouse_id,handleZoneClick }) => {
  const [openedPopoverId, setOpenedPopoverId] = useState(null);
  const handleOpen = (id) => setOpenedPopoverId(id);
  const handleClose = () => setOpenedPopoverId(null);
  const { onOpen, onClose, isOpen } = useDisclosure()
  const [zone_v, setZone_v] = useState(null);
  const [zones, setZones] = useRecoilState(wdzonesAtom)


  // recoilState //

  // // // // // //
  const warehouse_id = Warehouse_id
  const [highestLevels, setHighestLevels] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const zones_temp = useRecoilValue(zonestempWdState)
 

  
  
  /////////////////////////////////// Zones Stylist ////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////



  //////////////////////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////



  

  

  


  return (

    <>
      {/* FIRST MOUNT AND FIND LEVELS */}
      <ZoneDataHandler  setZones={setZones} setZones_V={setZone_v} setHighestLevels={setHighestLevels} setIsLoading={setIsLoading} warehouse_id={warehouse_id} />
      {/* FIRST MOUNT AND FIND LEVELS */}
      <TransformWrapper
        centerOnInit={true}
        initialScale={0.4}
        minScale={0.2}
        // disablePadding={true}
        smooth={true}
        panning={
          { velocityDisabled: true }
        }
        doubleClick={
          { disabled: true }
        }
      >
      <Box bg='white' h={{ sm: '500px', md: '600px', lg: '700px', xl: '800px' }} overflow='auto' >
        {isLoading ? (
          <>
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
              <BiLoader />
            </div>
            <TransformComponent/>
          </>
        ) : (
          <TransformComponent wrapperStyle={{ maxWidth: "100%", maxHeight: "100%" }}>
          <div
            style={BackGroundDisplay(warehouse_id)}
          >

            <div style={{ whiteSpace: 'pre-line' }}>
              {zones && zones.length && zones.map((zone) => (
                <RenderZone
                  zone={zone}
                  handleZoneClick={handleZoneClick}

            
               
                />
              ))}


            </div>



            {zone_v && zone_v.map(zone =>
              <ZoneTagWithPopover
                zone={zone}

                openedPopoverId={openedPopoverId}
                handleOpen={handleOpen}
                handleClose={handleClose}
              />
            )}



          </div>
          </TransformComponent>
        )}
      </Box>
      </TransformWrapper>
    </>
  )}, (prevProps, nextProps) => {
    // กำหนดเงื่อนไขการเปรียบเทียบ props ที่ทำให้ component นี้ re-render
    return prevProps.Warehouse_id === nextProps.Warehouse_id;
  });

export default MapDisplay;


