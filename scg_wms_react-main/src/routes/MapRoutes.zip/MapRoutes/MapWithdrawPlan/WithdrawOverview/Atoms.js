// atoms.js
import { atom } from 'recoil';



export const WDreloadState = atom({
  key: 'WDreloadState', // unique ID (with respect to other atoms/selectors)
  default: false,     // default value
});

export const withdrawSelectedState = atom({
  key: 'withdrawSelectedState',
  default: ''
});


export const wdproductSelectedState = atom({
  key: 'wdproductSelectedState',
  default: null
});

export const wdSwitchedState = atom({
  key: 'wdSwitchedState',
  default: false, // This will be an array of map_ids
});

/////////////////// DATA FROM MABEAM ///////////////////
export const get_withdrawplanState = atom({
  key: 'get_withdrawplanState',
  default: ''
})
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////


export const payloadWithDrawPlan = atom({
  key: 'payloadWithDrawPlan',
  default: ''
})


export const dataforPlanState = atom({
  key: 'dataforPlanState',
  default: ''
})


export const default_payloadWithDrawPlan = atom({
  key: 'default_payloadWithDrawPlan',
  default: ''
})

export const dataToUpdateWithdraw = atom({
  key: 'dataToUpdateWithdraw',
  default: ''
})

export const wdmulticlickedZone_Info = atom({
  key: 'wdmulticlickedZone_Info',
  default: []
})


export const zonestempWdState = atom({
  key: 'zonestempWdState',
  default: []
  })

  export const wdtagClickedState = atom({
    key: 'wdtagClickedState',
    default: []
  })



  export const wdzonesAtom = atom({
    key: 'wdzonesAtom',
    default: []
  })
  

  export const wdMapfilterState = atom({
    key: 'wdMapfilterState',
    default: [], // This will be an array of map_ids
  });
  