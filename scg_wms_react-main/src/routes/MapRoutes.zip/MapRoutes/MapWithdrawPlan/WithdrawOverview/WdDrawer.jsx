import React, { useState,useEffect,startTransition, useTransition, useRef } from 'react';
import {
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  HStack,
  Divider,
  Input,
  Select,
  Table,
  Thead,
  Tr,
  Th,
  Tbody,
  Td,
  Progress,
  Center,
  Spacer,
  Stack,
  Flex,
  Circle,
  VStack,
  TableContainer,
  Text,
  Heading,
  Spinner,
  StackDivider,
  Box,
  Button,
  ButtonGroup,
} from '@chakra-ui/react';
import { Card, CardHeader, CardBody, CardFooter } from '@chakra-ui/react'
import { useRecoilValue,useRecoilState,useRecoilRefresher_UNSTABLE,useRecoilCallback } from 'recoil';
import { BiCheck,BiError } from "react-icons/bi";
import {IoAlertCircleSharp} from "react-icons/io5"
import {wdproductSelectedState,dataToUpdateWithdraw,WDreloadState,zonestempWdState,payloadWithDrawPlan } from './Atoms'
import { MdKeyboardArrowDown } from "react-icons/md";
import Swal from 'sweetalert2';

import { Badge } from '@chakra-ui/react'
import { RiDeleteBin6Fill } from 'react-icons/ri'
import { useToast } from '@chakra-ui/react';
import Axios from 'axios';
Axios.defaults.xsrfCookieName = 'csrftoken';
Axios.defaults.xsrfHeaderName = 'X-CSRFToken';
Axios.defaults.withCredentials = true;

const client = Axios.create({
  baseURL: `${process.env.REACT_APP_API_URL}`
});

const InputSelector = ({ handleDateChange, handleShiftChange, handleMachineChange, selectedStatus, selectedDate, selectedShift, selectedMachine }) => {
  return (
    <HStack spacing={4}>
      <Input
        placeholder="Select Date"
        size="md"
        type="date"
        onChange={handleDateChange}
        isDisabled={selectedStatus}
        value={selectedDate|| ''}
      />
      <Select
        placeholder="Shift"
        onChange={handleShiftChange}
        value={selectedShift}
        isDisabled={selectedStatus}
      >
        <option value="A">A</option>
        <option value="B">B</option>
        <option value="C">C</option>
      </Select>

      <Select
        placeholder="Machine"
        onChange={handleMachineChange}
        value={selectedMachine}
      >
        <option value="CT1">CT1</option>
        <option value="CT2">CT2</option>
        <option value="CT3">CT3</option>
        <option value="CT4">CT4</option>
      </Select>
    </HStack>
  );
}

const DataDisplay = ({ page,displayedData, dataforupdatefillplan, CheckIdStatus, handleUnProductSelect, handleProductSelect, productSelected,handleEditAndClearLocation,setCurrentPage }) => {

  return (
  <>
             <Box overflowX="hidden">
                   {Object.entries(displayedData).length > 0 ? (
                     <VStack spacing={"4"} mt="4" py='4'>
                       {Object.entries(displayedData).map(([receive_date, shifts]) => (
                         <React.Fragment key={receive_date}>
                           {Object.entries(shifts).map(([receive_shift, machines]) => (
                             <Card w="90%">
                               <CardHeader>
                                 <Heading size="md" pb='0'>
                                   {" "}
                                   {receive_date} [{receive_shift}]
                                 </Heading>
                               </CardHeader>
   
                               <CardBody>
                                 {Object.entries(machines).map(([machine, zca_ons]) => (
                                   <Stack divider={<StackDivider />} spacing="4" p="2" py='4'>
                                     <Box>
                                       <Heading size="xs" textTransform="uppercase" pb='4'>
                                         Machine: {machine}
                                       </Heading>
                                       <TableContainer pl='8'>
                                         <Table variant="simple">
                                           {Object.entries(zca_ons).map(
                                             ([zca_on, items]) => (
                                               <Tr key={zca_on} width="80rem" >
                                                 <Td px="2" pr='0' w="10rem">
                                                 
                                                       <>
                                                      
                                                      {CheckIdStatus(items[0].id) ? (
                                  <Badge fontSize='0.7em' colorScheme='green'>
                                  Success
                                </Badge>
                        
                          ) : (
                    
                             <Badge fontSize='0.7em' colorScheme='yellow'>
                             in progress
                           </Badge>
                        ) } 
                                                     </>
                                                     
                                                     
                                              
                                                 </Td>
                                                 <Td px="2" whiteSpace="normal" w="80rem">
                                                   <Text ml={12}>
                                                     <Text as="span" fontWeight="bold">
                                                       {items[0].name_th}
                                                     </Text>
                                                     <Spacer py="1" />
                                                     {zca_on} : 
                                                     <>
                                                     {page === 'page1' ? (<Text as="span" color="darkred" fontWeight='bold'>
                                                       ({items[0].qty_total_pallet} Pallet)
                                                       ({items[0].qty } pcs)</Text>

                                                     ) : (<Text as="span" color="darkred" fontWeight='bold'>
                                                           ({items[0].total_pallet_req} Pallet)
                                                       ({items[0].total_pcs_req } pcs)
                                                       </Text>)}
                                                     
                                                     </>
                                                   </Text>
                                                 </Td>
                                                 <Td px="2" w="10rem">
                                                   {page === 'page1' ? (
                                                     productSelected?.[0] && (
                                                         productSelected?.[0]?.zca_on === zca_on &&
                                                         productSelected?.[0]?.send_date === receive_date &&
                                                         productSelected?.[0]?.send_shift === receive_shift &&
                                                         productSelected?.[0]?.machine === machine
                                                     ) ? (
                                                       <Button colorScheme='teal' variant='outline' onClick={() => handleUnProductSelect()}>
                                                         Unselect
                                                       </Button>
                                                     ) : (
                                                      
                                                       <Button onClick={() => handleProductSelect(items)}>
                                                         Select Product
                                                       </Button>
                                                       
                                                     )
                                                   ) : (
                                                     <Button
                                                       leftIcon={<RiDeleteBin6Fill />}
                                                       colorScheme='red'
                                                       variant='solid'
                                                       onClick={() => {
                                                         handleEditAndClearLocation( receive_date,receive_shift,machine, zca_on, 'clear');

                                                       }}
                                                     >
                                                       Clear
                                                     </Button>
                                                   )}



                                                 </Td>
                                               </Tr>
                                             )
                                           )}
                                         </Table>
                                       </TableContainer>
                                     </Box>
                                   </Stack>
                                 ))}
                               </CardBody>
                             </Card>
                           ))}
                         </React.Fragment>
                       ))}
                     </VStack>
                   ) : (
                     <Text color="red" fontSize={'xl'} mt={4} fontWeight="bold" textAlign="center">
                       No matching recive date and shift
                     </Text>
                   )}
             </Box>
           </>
  );
}

const StepProgressBar = (props) => {
  const productSelected = props.productSelected
  const currentpage = props.currentpage
  const dataforupdatefillplan = props.dataforupdatefillplan

  const zones_temp = useRecoilValue(zonestempWdState)

  const determineCurrentStep = (productSelected, zones_temp) => {

    if (currentpage === 'page2' && Array.isArray(zones_temp) && zones_temp.length > 0) {
      return 'เลือกสินค้าต่อหรือข้าม'
    }
    if (Array.isArray(zones_temp) && zones_temp.length > 0) {
      return 'เลือกlocation'; // ค่าสำหรับ step 2
    }
    if (productSelected) {
      return 'เลือกสินค้า'; // ค่าสำหรับ step 1
    }

    return null;
  }
  const notificationCount = Object.keys(dataforupdatefillplan).length


  const steps = ['เลือกสินค้า', 'เลือกlocation', 'เลือกสินค้าต่อหรือข้าม', 'ยืนยันการเลือก']
  const currentStep = determineCurrentStep(productSelected, zones_temp)
  const currentIndex = steps.indexOf(currentStep) + 1;
  const progressPercentage = (currentIndex / steps.length) * 100;

  return (
    <Flex alignItems="center" flexDirection='column' px='5' py='5'>

      <Flex justifyContent="space-between" alignItems="center" width="100%">
        {steps.map((step, index) => (

          <Box key={index} flex="1" px='2'>
            <Progress

              key={index}
              value={index < currentIndex ? 100 : (index === currentIndex ? 100 : 0)}
              size='lg'
              colorScheme="green"
              width="100%"
              mb="2"
              hasStripe={index === currentIndex}
              opacity={index === currentIndex && progressPercentage < (100 / steps.length * (index + 1)) ? 0.7 : 1}
            />
            <Flex
              direction="column"
              align="center"
              justify="center"

            >
              <Circle
                size="40px"
                bg={index < currentIndex ? "green.500" : "gray.200"}
                color={index < currentIndex ? "white" : "gray.400"}
                zIndex="1"
                borderWidth={index === currentIndex ? "2px" : "0"} // ใช้ขอบ 2px สำหรับ step ปัจจุบัน
                borderColor="green.500" // สีขอบสีเขียว
                position="relative"
              >
                {index + 1}

                {index === steps.length - 1 && notificationCount > 0 && (
                  <Box
                    bg="red.500"
                    borderRadius="full"
                    color="white"
                    position="absolute"
                    top="-5px"
                    right="-5px"
                    px="2"
                    py="0"
                    fontSize="12"
                  >
                    {notificationCount}
                  </Box>
                )}
              </Circle>


              <Text mt="2" color={index < currentIndex ? "green.500" : "gray.400"}>
                {step}
              </Text>
            </Flex>
          </Box>
        ))}
      </Flex>
    </Flex>
  );
}




const SuccessPage = React.memo(({expanded, handleExpandClick,successFillplan,isPendingSuccessPage}) => {
  const [showLoading, setShowLoading] = useState(false);

  

  useEffect(() => {
    let timer;
    if (isPendingSuccessPage || !successFillplan) {
      // ตั้งเวลาสักครู่ก่อนแสดง loading
      timer = setTimeout(() => setShowLoading(true), 200); // ตัวอย่างเช่น 500 ms
    } else {
      setShowLoading(false);
    }

    return () => clearTimeout(timer); // ทำความสะอาดเมื่อ component unmount หรือ state มีการเปลี่ยนแปลง
  }, [isPendingSuccessPage, successFillplan]);

  if (showLoading) {
    return <div>Loading...</div>;
  }


    
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0'); // เดือนใน JavaScript เริ่มที่ 0
    const year = date.getFullYear().toString().substr(2, 2);
    return `${day}/${month}/${year}`;
  };

  return(

    successFillplan && (
      <>
    <Box h='100%' overflowY='auto'>
        {Object.entries(successFillplan).length > 0 ? (
          <VStack spacing={"4"} mt="4" py='4'>
             {[...Object.entries(successFillplan)].reverse().map(([receive_date, shifts]) => (
              <React.Fragment key={receive_date}>
                {Object.entries(shifts).map(([receive_shift, machines]) => (
                  <Card w="90%">
                    <CardHeader>
                      <Heading size="md" pb='0'>
                        {" "}
                        {receive_date} [{receive_shift}]
                      </Heading>


                    </CardHeader>

                    <CardBody>
                      {Object.entries(machines).map(([machine, zca_ons]) => (
                        <Stack divider={<StackDivider size='4' />} spacing="4" p="2" py='4' >
                          <Box >
                            <Heading size="xs" textTransform="uppercase" pb='4'>
                              Machine: {machine}
                            </Heading>
                            <TableContainer pl='8'>
                              <Table variant="simple">
                                {Object.entries(zca_ons).map(([zca_on, items], index) => {
                                  const uniqueKey = `${machine}-${zca_on}-${index}`;
                                  return (
                                    <React.Fragment key={uniqueKey}>
                                      <Tr width="80rem">
                                        <Td px="2" pr='0' w="10rem">
                                          <Badge colorScheme='green'>Success</Badge>
                                        </Td>
                                        <Td px="2" whiteSpace="normal" w="80rem">
                                          <Text ml={12}>
                                            <Text as="span" fontWeight="bold">
                                              {items[0].name_th}
                                            </Text>
                                            <Spacer py="1" />
                                            {zca_on} :
                                            <Text as="span" color="darkred" fontWeight='bold'>
                                              ({items.length} Pallet)
                                            </Text>
                                          </Text>
                                        </Td>
                                        <Td>
                                          Updated at : {formatDate(items[0].updated_at)}
                                        </Td>
                                        <Td px="2" w="10rem">
                                          <MdKeyboardArrowDown onClick={() => handleExpandClick(uniqueKey)} style={{cursor: 'pointer'}} />
                                        </Td>
                                      </Tr>
                                      {expanded[uniqueKey] && (
                                  
                                        <Tr>
                                          <Td colSpan="4">
                                          <Box ml={'-2rem'}>
                                          <TableContainer width="100%" >
                                            <Table variant="simple" size='sm'>
                                              <Thead>
                                                <Tr>
                                                  <Th>Pallet No</Th>
                                                  <Th>Warehouse</Th>
                                                  <Th>Zone</Th>
                                                  <Th>Column</Th>
                                                  <Th>Row</Th>
                                                  <Th>Level</Th>
                                                  <Th>Sub Col</Th>
                                                  <Th>Map ID</Th>
                                                </Tr>
                                              </Thead>
                                              <Tbody>
                                                {items.map(item => (
                                                  <Tr key={item.pallet_no}>
                                                    <Td>{item.pallet_no}</Td>
                                                    <Td>{item.warehouse}</Td>
                                                    <Td>{item.zone}</Td>
                                                    <Td>{item.column}</Td>
                                                    <Td>{item.row}</Td>
                                                    <Td>{item.level}</Td>
                                                    <Td>{item.sub_column}</Td>
                                                    <Td>{item.mapid}</Td>
                                                  </Tr>
                                                ))}
                                              </Tbody>
                                            </Table>
                                            </TableContainer>
                                            </Box>
                                          </Td>
                                      
                                        </Tr>
                                    
                                      )}
                                    </React.Fragment>
                                  );
                                })}
                              </Table>
                            </TableContainer>
                          </Box>
                        </Stack>
                      ))}

                    </CardBody>
                  </Card>
                ))}
              </React.Fragment>
            ))}
          </VStack>
        ) : (
          <Text color="red" fontSize={'xl'} mt={4} fontWeight="bold" textAlign="center">
            No matching recive date and shift
          </Text>
        )}
           </Box>
    </>
    )
  )
    



})







function DrawerExample({ isOpen, onClose, btnRef, handleProductSelect,handleUnProductSelect,CheckIdStatus,handleEditAndClearLocation,get_fillplanlist,fillplan,setFillPlan,resetToDefaultState }) {
  const [payload,setPayload] = useRecoilState(payloadWithDrawPlan);
  const [productSelected, setProductSelected] = useRecoilState(wdproductSelectedState);
  const [zones_temp, setZones_temp ] = useRecoilState(zonestempWdState)

  const [selectedStatus, setselectedStatus] = useState(false)
  const [reload, setReload] = useRecoilState(WDreloadState);

  
  const isMounted = useRef(true);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedShift, setSelectedShift] = useState(null);
  const [selectedMachine, setSelectedMachine] = useState(null);
  const [successFillplan,setSuccessFillPlan] = useState(null)

  const [dataforupdatefillplan,setdataforupdatefillplan] = useRecoilState(dataToUpdateWithdraw);
  console.log('dataforupdatefillplan:',)

  const [isPending, startTransition] = useTransition();
  const [isPendingSuccessPage, startTransitionSuccessPage] = useTransition();
  const [mainPage, setMainPage] = useState('page1');
  
  const get_successwithdraw = async () => {


    try {
        const { data } = await client.get(`/wms/api/get_withdrawpallet/`);
        return data;
    } catch (error) {
        console.error('Error fetching data: ', error);
    }
  };

  useEffect(() => {

        const fetchWithDraw = async () => {
          try {
            const successPallet = await get_successwithdraw();
            setSuccessFillPlan(successPallet);

          } catch (error) {
            console.error('Error fetching fill plan:', error);
          }

        };
        fetchWithDraw();



  }, []);


  


  




  const handleDateChange = (e) => {
    startTransition(() => {
    setSelectedDate(e.target.value);
    });
  };

  const handleShiftChange = (e) => {
    startTransition(() => {
    setSelectedShift(e.target.value);
    });
  };

  const handleMachineChange = (event) => {
    startTransition(() => {
      setSelectedMachine(event.target.value);
    });
  };
  

  const [saveMode, setsaveMode] = useState(false);



  const filterData = (filteredData) => {

    // If neither date, nor shift, nor machine is selected, show all data.
    if (!selectedDate && !selectedShift && !selectedMachine) return filteredData;

    // Filter only by date:
    if (selectedDate && !selectedShift && !selectedMachine) {
        return filteredData[selectedDate] ? {[selectedDate]: filteredData[selectedDate]} : {};
    }

    // Filter only by shift:
    if (!selectedDate && selectedShift && !selectedMachine) {
        let result = {};
        for (let date in filteredData) {
            if (filteredData[date][selectedShift]) {
                result[date] = {[selectedShift]: filteredData[date][selectedShift]};
            }
        }
        return Object.keys(result).length > 0 ? result : {};
    }

    // Filter only by machine:
    if (!selectedDate && !selectedShift && selectedMachine) {
        let result = {};
        for (let date in filteredData) {
            for (let shift in filteredData[date]) {
                if (filteredData[date][shift][selectedMachine]) {
                    if (!result[date]) result[date] = {};
                    result[date][shift] = {[selectedMachine]: filteredData[date][shift][selectedMachine]};
                }
            }
        }
        return Object.keys(result).length > 0 ? result : {};
    }

    // If both date and shift are selected:
    if (selectedDate && selectedShift && !selectedMachine) {
        const filteredByDate = filteredData[selectedDate] || {};
        const filteredByShift = filteredByDate[selectedShift];
        return filteredByShift ? {[selectedDate]: {[selectedShift]: filteredByShift}} : {};
    }

    // If date and machine are selected:
    if (selectedDate && !selectedShift && selectedMachine) {
        const filteredByDate = filteredData[selectedDate] || {};
        let result = {};
        for (let shift in filteredByDate) {
            if (filteredData[selectedDate][shift] && filteredData[selectedDate][shift][selectedMachine]) {
                if (!result[selectedDate]) result[selectedDate] = {};
                result[selectedDate][shift] = {[selectedMachine]: filteredData[selectedDate][shift][selectedMachine]};
            }
        }
        return Object.keys(result).length > 0 ? result : {};

    }

    // If shift and machine are selected:
    if (!selectedDate && selectedShift && selectedMachine) {
        let result = {};
        for (let date in filteredData) {
            if (filteredData[date][selectedShift] && filteredData[date][selectedShift][selectedMachine]) {
                if (!result[date]) result[date] = {};
                result[date][selectedShift] = {[selectedMachine]: filteredData[date][selectedShift][selectedMachine]};
            }
        }
        return Object.keys(result).length > 0 ? result : {};
    }

    // If date, shift, and machine are selected:
    if (selectedDate && selectedShift && selectedMachine) {
        const filteredByDate = filteredData[selectedDate] || {};
        const filteredByShift = filteredByDate[selectedShift] || {};
        const filteredByMachine = filteredByShift[selectedMachine];
        return filteredByMachine ? {[selectedDate]: {[selectedShift]: {[selectedMachine]: filteredByMachine}}} : {};
    }
};
  

const filterWithdrawSuccess = (data) => {
  const updatedData = {};

  for (const [dateKey, dateValue] of Object.entries(data)) {
    updatedData[dateKey] = {};

    for (const [shiftKey, shiftValue] of Object.entries(dateValue)) {
      updatedData[dateKey][shiftKey] = {};

      for (const [machineKey, machineValue] of Object.entries(shiftValue)) {
        updatedData[dateKey][shiftKey][machineKey] = {};

        for (const [zcaOnKey, zcaOnValue] of Object.entries(machineValue)) {
          const filteredItems = zcaOnValue.filter(item => item.withdraw_success === 1);
          if (filteredItems.length > 0) {
            updatedData[dateKey][shiftKey][machineKey][zcaOnKey] = filteredItems;
          }
        }

        if (Object.keys(updatedData[dateKey][shiftKey][machineKey]).length === 0) {
          delete updatedData[dateKey][shiftKey][machineKey];
        }
      }

      if (Object.keys(updatedData[dateKey][shiftKey]).length === 0) {
        delete updatedData[dateKey][shiftKey];
      }
    }

    if (Object.keys(updatedData[dateKey]).length === 0) {
      delete updatedData[dateKey];
    }
  }

  return updatedData;
};




  const page1Data = fillplan || {}
  const page2Data = filterWithdrawSuccess(payload);

  console.log(page2Data,'page2Data')





  const displayedDataPage1 = filterData(page1Data);
  const displayedDataPage2 = filterData(page2Data)


  
  // const handleSave = () => {
  //   setdataforupdatefillplan(filteredData)
  //   setdefault_dataforupdatefillplan(filteredData)
  //   setselectedStatus(true);
  //   setsaveMode(true)
  // }

  
  const handleCancel = () => {
    Swal.fire({
      title: 'Are you sure you want to cancel?',
      icon: 'warning',
      text: 'หากยกเลิกข้อมูล map ที่เลือกไว้จะถูกยกเลิกด้วย',
      showCancelButton: true,
      cancelButtonText: 'No, keep it',
      confirmButtonText: 'Yes, cancel it!',
      confirmButtonColor: '#E51212',

    }).then((result) => {
      if (result.isConfirmed) {
        setselectedStatus(false)
        setProductSelected(null)
        setdataforupdatefillplan(null)
        setsaveMode(false)

        setZones_temp(null)
        setReload(!reload);

      }
    });
  };




  
  const toast = useToast();


  
  

  

  const checkMapIdStatusForAllData = (dataforupdatefillplan) => {
    if (!dataforupdatefillplan || Object.keys(dataforupdatefillplan).length === 0) {
        return null;
    }    
      return true;
};

  

  const handleEmergency = async () => {
    const isAllCompleted = checkMapIdStatusForAllData(dataforupdatefillplan);
    if (isAllCompleted === null) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: `ไม่มีข้อมูลที่จะบันทึก !`,
        
      });
      return;
  } else if (!isAllCompleted) {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: `กรุณาเลือกพื้นที่ให้ครบทุก ZCA !`,

    });
      return;
  } else {
    try {
      const postResponse = await client.post('/wms/api/updateWithdraw/', dataforupdatefillplan);
      const patchResponse = await client.patch('/wms/api/updateWithdraw/', payload);
      if (isMounted.current && postResponse.status === 200 && patchResponse.status === 200) {

// แสดง Swal แบบโหลด
Swal.fire({
  title: 'Saving your work...',
  text: 'Please wait.',
  icon: 'info',
  allowOutsideClick: false,
  allowEscapeKey: false,
  allowEnterKey: false,
  onBeforeOpen: () => {
    Swal.showLoading();
  }
});

// ดำเนินการกระบวนการต่างๆ
try {
  onClose();
  let fillplan = await get_fillplanlist(false);
  setFillPlan(fillplan);
  resetToDefaultState();
  setReload(prevReload => !prevReload);
  setCurrentPage('page1');

  Swal.fire({
    icon: 'success',
    title: 'Your work has been saved',
    showConfirmButton: false,
    timer: 1500
  });
} catch (error) {
  console.error('An error occurred:', error);
  // แสดงข้อความข้อผิดพลาดหากจำเป็น
  Swal.fire({
    icon: 'error',
    title: 'Error',
    text: 'An error occurred. Please try again.'
  });
}

        
        
      }
     
    } catch (error) {
      if (isMounted.current) {
        console.error('An error occurred:', error);
        toast({
          title: "Error",
          description: `An error occurred: ${error.message}`,
          status: "error",
          duration: 3000,
          isClosable: true,
        });
      }
    }
  }
  };
  


  useEffect(() => {
    isMounted.current = true; 

    return () => {
      isMounted.current = false; 
    };
  }, []);
  

 
  const [currentPage, setCurrentPage] = useState('page1');
  const buttonText = mainPage === 'page1' ? 'History' : 'Back';
  const changePage = () => {
    if (mainPage === 'page1') {
      setMainPage('page2');
    } else {
      setMainPage('page1');
    }
  };

  const [expanded, setExpanded] = useState({});


  const handleExpandClick = (index) => {
    setExpanded((prevExpanded) => ({
      ...prevExpanded,
      [index]: !prevExpanded[index],
    }));
  };

  

  return (
    <Drawer
      size={"xl"}
      isOpen={isOpen}
      placement="right"
      onClose={onClose}
      finalFocusRef={btnRef}
    >
      <DrawerOverlay />
      <DrawerContent>
        <DrawerHeader>
          <HStack>
                  <Text>
          {mainPage === "page2" ? "History" : "Job List"}
          </Text>

          <Spacer />
          <Button size='sm' colorScheme='teal' variant='ghost' onClick={changePage}>
        {buttonText}
      </Button>
          </HStack>
        </DrawerHeader>
        <DrawerBody overflow="hidden">
          {mainPage === "page1" && (
            <>

              <InputSelector
                handleDateChange={handleDateChange}
                handleShiftChange={handleShiftChange}
                handleMachineChange={handleMachineChange}
                selectedStatus={selectedStatus}
                selectedDate={selectedDate}
                selectedShift={selectedShift}
                selectedMachine={selectedMachine}
              />
              <Box pt="2">

                <StepProgressBar
                  productSelected={productSelected}
                  currentpage={currentPage}
                  dataforupdatefillplan={dataforupdatefillplan}
                />
              </Box>
              <Divider p="4" pt="0" />
              
              {currentPage === "page1" && (
                <>
                  <Box h="75%" overflowX="hidden" overflowY="auto">
                    {isPending ? (
                      <Center p="10rem">
                        {" "}
                        <Spinner size="xl" />{" "}
                      </Center>
                    ) : (
                      <DataDisplay
                        page='page1'
                        displayedData={displayedDataPage1}
                        dataforupdatefillplan={dataforupdatefillplan}
                        CheckIdStatus={
                          CheckIdStatus
                        }
                        handleEditAndClearLocation={handleEditAndClearLocation}
                        handleUnProductSelect={handleUnProductSelect}
                        handleProductSelect={handleProductSelect}
                        productSelected={productSelected}
                        setCurrentPage={setCurrentPage}
                      />
                    )}
                  </Box>
                </>
              )}
              {currentPage === "page2" && (
                <>
                  <Box h="75%" overflowX="hidden" overflowY="auto">
                    {isPending ? (
                      <Center p="10rem">
                        {" "}
                        <Spinner size="xl" />{" "}
                      </Center>
                    ) : (
                      <DataDisplay
                        page='page2'
                        displayedData={displayedDataPage2}
                        dataforupdatefillplan={dataforupdatefillplan}
                        CheckIdStatus={
                          CheckIdStatus
                        }
                        handleEditAndClearLocation={handleEditAndClearLocation}
                        handleUnProductSelect={handleUnProductSelect}
                        handleProductSelect={handleProductSelect}
                        productSelected={productSelected}
                        setCurrentPage={setCurrentPage}
                      />
                    )}
                  </Box>
                </>
              )}

            </>
          )}

          {mainPage === "page2" &&  (

            <SuccessPage
            isPendingSuccessPage={isPendingSuccessPage}
            expanded={expanded} 
            handleExpandClick={handleExpandClick}
            successFillplan={successFillplan}
            />
          
)}

        </DrawerBody>
        <DrawerFooter>
          {mainPage === 'page1' && (

                   <ButtonGroup >
                   {currentPage === "page1" && (
                     <Button
                       colorScheme='teal'
                       onClick={() => setCurrentPage("page2")}
                       isDisabled={
                         !dataforupdatefillplan 
                       }
                     >
                       Next Step
                     </Button>
                   )}
         
                   {currentPage === "page2" && (
                     <>
                       <Button onClick={() => setCurrentPage("page1")}>Back</Button>
                       <Button onClick={handleEmergency} colorScheme="green">
                         Submit
                       </Button>
         
         
                     
         
         
                     </>
                   )}
                   
                   {/* This button should always be aligned to the right, so it's placed outside the conditional rendering */}
                   <Button variant="outline" onClick={onClose}>
                     Close
                   </Button>
         
           
                 </ButtonGroup>
            
            )}
 
      </DrawerFooter>

      </DrawerContent>
    </Drawer>
  );
}

export default DrawerExample;