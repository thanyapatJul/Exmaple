import React, { useState, useTransition, useEffect, lazy, Suspense,useCallback } from 'react';
import { useRecoilState } from 'recoil';
import WarehouseDisplay from '../../MapWD/MainDisPlay.js';
import { Skeleton } from '@chakra-ui/react';
import {
  Tabs, TabList, TabPanels, Tab, TabPanel, Text, Box, Grid, GridItem, Container, Heading, Highlight, Spacer, Button, Flex, Divider, Stack, StackDivider,
  ButtonGroup, VStack, Card, CardHeader, CardBody, CardFooter, SimpleGrid, useDisclosure, HStack, Badge, Tooltip,useToast
} from '@chakra-ui/react'
import { MdForklift } from "react-icons/md";
import {AiOutlineInfoCircle,AiFillEdit} from 'react-icons/ai'
import Swal from 'sweetalert2'
import  ZoneTags  from '../MapSelectPage/MapEditorPage'
import { useZoneComparison,countAllMembers } from '../../Hooks/CustomHooks.js';

import { payloadWithDrawPlan,zonestempWdState,wdmulticlickedZone_Info,wdproductSelectedState,  WDreloadState,  dataToUpdateWithdraw } from './Atoms'
import Axios from 'axios';
Axios.defaults.xsrfCookieName = 'csrftoken';
Axios.defaults.xsrfHeaderName = 'X-CSRFToken';
Axios.defaults.withCredentials = true;

const client = Axios.create({
  baseURL: `${process.env.REACT_APP_API_URL}`
});

const DrawerExample = lazy(() => import('./WdDrawer.jsx'));

const WdOverview = () => {
  const { compareZoneLevels } = useZoneComparison();
  const [zones_temp, setZones_temp] = useRecoilState(zonestempWdState)
  const [isPending, startTransition] = useTransition();
  const [productSelected, setProductSelected] = useRecoilState(wdproductSelectedState);
  const [multiclickedZone_Info , setmultiClickedZone_Info] = useRecoilState(wdmulticlickedZone_Info)
  const [updateWithdrawplan, setupdateWithdrawplan] = useRecoilState(dataToUpdateWithdraw)

  const [payloadWithdraw,setpayloadWithdraw] = useRecoilState(payloadWithDrawPlan);

  const handleProductSelect = (product) => {
    console.log('product',product)
    setProductSelected(product);
    setmultiClickedZone_Info({})

    onClose();  
  };
  
  const handleUnProductSelect = (product) => {
    setProductSelected(null);
    setmultiClickedZone_Info({})
  };

  const btnRef = React.useRef()
  const toast = useToast();


  const { isOpen, onOpen, onClose } = useDisclosure()

  const [reload, setReload] = useRecoilState(WDreloadState);
  const [isFilterActive, setFilterActive] = useState(false);


  
  const resetToDefaultState = () => {
    setProductSelected(null)
    setZones_temp([])
    setmultiClickedZone_Info([])
    setupdateWithdrawplan('')

  }

  const get_withdrawplanlist = async (action) => {
    let queryString = '';
    if (action === true) {
        queryString = 'success=true';
    } else {
      queryString = 'success=false'
    }

    try {
        const { data } = await client.get(`/wms/api/get_withdrawplan/?${queryString}`);
        
        return data;
    } catch (error) {
        console.error('Error fetching data: ', error);
    }
};



useEffect(() => {
  const fetchWithDraw = async () => {
    try {
      const payloadWithdraw = await get_withdrawplanlist(false);
      setpayloadWithdraw(payloadWithdraw);

    } catch (error) {
      console.error('Error fetching fill plan:', error);
    }

  };

  fetchWithDraw();
}, []);


  const WARNING_TITLE = "Warning";
  const WARNING_DURATION = 5000;
  const WARNING_STATUS = "warning";
  const ERROR_STATUS = "error";

  const updateExistingMClickedZone = (
    updateWithdrawplan,
    job_id,

  ) => {

    const machineData = updateWithdrawplan?.[job_id];

    if (!machineData) {
      console.error(`The job_id '${job_id}' does not exist in the provided data.`);
      return {};
    }

    const newMulticlickedZoneInfo = {};

    Object.values(machineData).forEach(data => {
      const { column, row, mapid, level, warehouse, zone, sub_column,fraction } = data;

      if (!newMulticlickedZoneInfo[mapid]) {
        newMulticlickedZoneInfo[mapid] = {};
      }

      if (!newMulticlickedZoneInfo[mapid][level]) {
        newMulticlickedZoneInfo[mapid][level] = {};
      }

      // กำหนดข้อมูลให้กับ sub_column
      newMulticlickedZoneInfo[mapid][level][sub_column] = {
        ...data,
        is_used: true, // ตามที่คุณระบุไว้
        ...(fraction !== undefined && { fraction })
      };
    });
    
  
    return newMulticlickedZoneInfo;
  };

  const ClickWithDraw = useCallback((zone, productSelected, multiclickedZone_Info, tagClicked, setTagClicked) => {
   


    if (!zone) {
      console.warn('Zone is null or undefined');
      return;
    }

    if (!multiclickedZone_Info) {
      console.warn('multiclickedZone_Info is null or undefined');
      return;
    }

    handleZoneOperations(zone, productSelected, multiclickedZone_Info, tagClicked, setTagClicked);
  }, [productSelected, multiclickedZone_Info]);

  
  function handleZoneOperations(zone, productSelected, multiclickedZone_Info, tagClicked, setTagClicked) {
    const zone_mapid = zone.mapid;
    const isAlreadyClicked = Object.keys(multiclickedZone_Info).includes(zone_mapid);
   
    if (isAlreadyClicked) {
        if(tagClicked?.mapid === zone_mapid) {
            setTagClicked(null)
        }

      setmultiClickedZone_Info(prevClickedZones => {
        if (!prevClickedZones) return {}; // add this line
        const newZones = { ...prevClickedZones };
        delete newZones[zone_mapid];

        return newZones;
      });
    } else {
      if (!zone.levels) {
        console.warn('zone.levels is null or undefined');
        return;
      }


      if (!productSelected || productSelected[0].qty_total_pallet === 0 || productSelected === null) {
        toast({
            title: "Warning",
            description: "Pick Product first!!!",
            status: "error",
            duration: 5000,
            isClosable: true,
        });
        return;
    }

    const status = CheckIdStatus(productSelected[0]?.id)
    if (status) { 
      Swal.fire({ title: 'คุณเลือกครบแล้ว', text: 'ไม่สามารถดำเนินการต่อได้', icon: WARNING_STATUS });
      return;
    }


      const transformData = (zone) => {
        const newRow = {};
        console.log('zca_on',productSelected[0].zca_on);
        if (!zone.levels || !zone.sub_column) {
          return newRow;
        }

        Object.keys(zone.levels).forEach(level => {
          
          if (!zone.levels[level].sub_column) {
            return; // continue to the next iteration
          }


         
          for (let i = 1; i <= zone.sub_column; i++) {
            if (
              zone.levels[level].sub_column[i] &&
              zone.levels[level].sub_column[i].data &&
              zone.levels[level].sub_column[i].data.zca_on === productSelected[0].zca_on
            ) {

              console.log(zone.levels[level].sub_column[i].data.zca_on);
              // Initialize nested properties if they don't exist
              newRow[zone.mapid] = newRow[zone.mapid] || {};
              newRow[zone.mapid][level] = newRow[zone.mapid][level] || {};

              newRow[zone.mapid][level][i] = {
                ...zone.levels[level].sub_column[i].data,
                level,
                column: zone.column,
                row: zone.row,
                mapid: zone.mapid,
                warehouse: zone.warehouse_id,
                zone: zone.zone,
                sub_column: i,
                is_used: true,
              };
            }
          }
        });

        return newRow;
      };


      setmultiClickedZone_Info(prevClickedZones => {
        if (!prevClickedZones) return {}; // this line is correct

        return { ...prevClickedZones, ...transformData(zone) };
      });

    }
  }


  const updateDataAndZonesTemp = (job_id, zones_temp) => {
    const updatedData = JSON.parse(JSON.stringify(updateWithdrawplan));
    if (updatedData[job_id] )
    
      {
      const shouldDelete = updatedData[job_id]
      if (shouldDelete) {
        delete updatedData[job_id];
      }

    }
  
    const newData = Object.values(updatedData)
      .flatMap(job_id => Object.values(job_id).flat());
  
    const oldData = Object.values(updateWithdrawplan)
      .flatMap(job_id => Object.values(job_id).flat());
  
    const uniqueUpdatedData = oldData.filter(updated =>
      !newData.some(data =>
        data.id === updated.id && data.mapid === updated.mapid && data.receive_date === updated.receive_date && data.receive_shift === updated.receive_shift
      )
    );
  
    const updatedZonesTemp = zones_temp.filter(z => !uniqueUpdatedData.some(updated => z.id === updated.id));
    
  
    return { updatedData, updatedZonesTemp };
  };
  

  const CheckIdStatus = (job_id) => {
    const zcaOnData = updateWithdrawplan?.[job_id] || [];

    if (zcaOnData.length === 0) {
      return false;
    }
    return true
  };

  const total_req = (job_id) => {
    const zcaOnData = updateWithdrawplan?.[job_id] || [];
    
    if (zcaOnData.length > 0) {
      let length = zcaOnData.length
      return length;
    }
    return null
  };

  const handleEditAndClearLocation = (job_id,action) => {

    if (
        updateWithdrawplan &&
        updateWithdrawplan[job_id] 
       
    ) {
    
          if( action === 'clear' ){
            Swal.fire({
              title: 'ยืนยันการ Clear locations?',
              icon: 'warning',
              text: 'หาก clear loactions แมพที่เลือกไว้ของ product นี้จะถูกรีเซ็ต',
              showCancelButton: true,
              cancelButtonText: 'ยกเลิก',
              confirmButtonText: 'ตกลง',
              confirmButtonColor: '#E51212',
        
            }).then((result) => {
              if (result.isConfirmed) {


            const { updatedData, updatedZonesTemp } = updateDataAndZonesTemp(
                                                    job_id,
                                                    zones_temp,
                                                    );


            const problemDetails = compareZoneLevels(zones_temp, updatedZonesTemp);

            if (problemDetails.length > 0) {

            const formatProblemDetailsToString = (problemDetails) => {
              return problemDetails.map(detail => 
                `Column: ${detail.column}, Row: ${detail.row}, Level: ${detail.level}`
              ).join('\n');
            };
            
            const problemDetailsStr = formatProblemDetailsToString(problemDetails);
            
           
              Swal.fire({
                title: 'ไม่สามารถแก้ไขหรือลบโซนนี้ได้',
                icon: 'error',
                html: `เนื่องจาก level ที่สูงกว่ายังคงมีข้อมูลอยู่ กรุณายกเลิกการวางของ level นั้นก่อน!<br><br>ข้อผิดพลาดที่พบ:<br>${problemDetailsStr.replace(/\n/g, '<br>')}`,
                confirmButtonText: 'ปิด'
              });
              return;
            }

        
                setupdateWithdrawplan(updatedData);
                setZones_temp(updatedZonesTemp);
                setReload(!reload); 
  

            return toast({
              title: 'locations ถูกรีเซ็ตเรียบร้อย',
              description: `กรุณาเลือกพื้นที่ของ product ชนิดนี้ใหม่`,
              status: 'success',
              duration: 5000,
              isClosable: true,
              position: 'bottom-right'
            });
          }
          })  
          } else if (action === 'edit'){


            const { updatedData, updatedZonesTemp } = updateDataAndZonesTemp(
              job_id,
              zones_temp,
              );

            const problemDetails = compareZoneLevels(zones_temp, updatedZonesTemp);

            if (problemDetails.length > 0) {

            const formatProblemDetailsToString = (problemDetails) => {
              return problemDetails.map(detail => 
                `Column: ${detail.column}, Row: ${detail.row}, Level: ${detail.level}`
              ).join('\n');
            };
            
            const problemDetailsStr = formatProblemDetailsToString(problemDetails);
            
           
              Swal.fire({
                title: 'ไม่สามารถแก้ไขหรือลบโซนนี้ได้',
                icon: 'error',
                html: `เนื่องจาก level ที่สูงกว่ายังคงมีข้อมูลอยู่ กรุณายกเลิกการวางของ level นั้นก่อน!<br><br>ข้อผิดพลาดที่พบ:<br>${problemDetailsStr.replace(/\n/g, '<br>')}`,
                confirmButtonText: 'ปิด'
              });
              return;
            }
            const updatedPayloadWithdraw = Object.entries(payloadWithdraw).reduce((result, [dateKey, dateValue]) => {
              result[dateKey] = Object.entries(dateValue).reduce((dateResult, [shiftKey, shiftValue]) => {
                dateResult[shiftKey] = Object.entries(shiftValue).reduce((shiftResult, [machineKey, machineValue]) => {
                  shiftResult[machineKey] = Object.entries(machineValue).reduce((machineResult, [zcaOnKey, zcaOnValue]) => {
                    machineResult[zcaOnKey] = zcaOnValue.map(item => {
                      if (item.id === productSelected[0].id) {
                        return { ...item, withdraw_success: 0,
                      };
                      }
                      return item;
                    });
                    return machineResult;
                  }, {});
                  return shiftResult;
                }, {});
                return dateResult;
              }, {});
              return result;
            }, {});
            
            console.log('updatedPayloadWithdraw:',updatedPayloadWithdraw)
            setpayloadWithdraw(updatedPayloadWithdraw);
         
            let newMulticlickedZoneInfo = updateExistingMClickedZone(updateWithdrawplan,job_id)
            setmultiClickedZone_Info(newMulticlickedZoneInfo);
            setupdateWithdrawplan(updatedData);
            setZones_temp(updatedZonesTemp);
            setReload(!reload);
      

            return

          } else {

          toast({
            title: 'ERROR',
            description: `action ไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง`,
            status: 'error',
            duration: 5000,
            isClosable: true,
            position: 'bottom-right'
          });

          }

  
    } else {
        console.warn(`Data not available for job_id: ${job_id}`);
    }
};

const [countPallet , setCountPallet ] = useState(null);

useEffect(() => {
  const count = countAllMembers(multiclickedZone_Info)

  setCountPallet(count);
}, [multiclickedZone_Info]);

const isMapIdCompleted = (machine, zca_on, receive_date, receive_shift, updateWithdrawplan) => {
  const machineData = updateWithdrawplan?.[receive_date]?.[receive_shift]?.[machine]?.[zca_on];
  return machineData && machineData.some(item => item.receive_date === receive_date && item.receive_shift === receive_shift);
};

const isCompleted = CheckIdStatus(productSelected?.[0]?.id);

  console.log('isCompleted:',isCompleted)

  const isAllSelectedProductsUpdated = (productSelected, dataforupdatefillplan) => {
    if (!productSelected || !Array.isArray(dataforupdatefillplan)) {
      return false;
    }
  
    const productIdSet = new Set(dataforupdatefillplan.map(item => item.id));
    
    return productSelected.some(product => productIdSet.has(product.id));
  };
  

  
  
  
  return (
    <Box  >
      <Tabs>
        <TabList>
          <Tab>Manual</Tab>
          <Tab>Suggestion</Tab>

        </TabList>

        <TabPanels>
          <TabPanel>
            <div>
              <Grid
                bg='gray.100'
                templateRows='repeat(2, 1fr)'
                templateColumns='repeat(8, 1fr)'
                gap={4}
           

              >
                <GridItem rowSpan={2} colSpan={6}   >
                  <Flex >
                    {isPending ? (
                      <Skeleton />
                    ) : (

                   <WarehouseDisplay
                    functionClick={ClickWithDraw}
                   reload={reload}
                   />

                    )}
                  </Flex>
                </GridItem>



                <GridItem rowSpan={2} colSpan={2} bg='white' overflow='auto'>
                  <Flex flexDirection='column' p='4' gap='4'  >
                    <Box  bg='white' width='100%' flex='1'       
                        borderRadius='1px'
                        rounded='md'
                        boxShadow='base' 
                        p='5' 


                        >

                   
                        <Heading fontSize='xl'>Select Product</Heading>
                 
                        {productSelected && productSelected.length > 0 ? (CheckIdStatus(productSelected[0].id) ? (
                                  <Badge fontSize='0.7em' colorScheme='green'>
                                  Success
                                </Badge>
                        
                          ) : (
                    
                             <Badge fontSize='0.7em' colorScheme='yellow'>
                             in progress
                           </Badge>
                        ) ) : null }

              

                      <Divider m='1' />

                      <Box maxH='40' overflowY='auto' overflowX='hidden'>
                        {productSelected ? (
                          <VStack
                            spacing={1}>
                            <div className="product-card">
                              <Text fontWeight="bold" >ZCA: </Text> <Text>{productSelected?.[0]?.zca_on}</Text>
                              <Divider m='1' />
                              <Text fontWeight="bold" >Name: </Text> <Text>{productSelected?.[0]?.name_th}</Text>
                              <Divider m='1' />
                              <Text fontWeight="bold">Pallet: </Text>
                              <Text>
                                {
                                  productSelected && typeof productSelected[0].qty_total_pallet === 'number'
                                    ? (
                                      `total: ${productSelected[0].qty_total_pallet} | ` +
                                      (CheckIdStatus(productSelected[0].id)
                                        ? `selected: ${total_req(productSelected[0].id)}` 
                                        : productSelected[0].qty_total_pallet - countPallet === 0
                                          ? "ครบ"
                                          : productSelected[0].qty_total_pallet - countPallet < 0
                                            ? `เกินมา ${Math.abs(productSelected[0].qty_total_pallet - countPallet)}`
                                            : `ขาดอีก ${productSelected[0].qty_total_pallet - countPallet}`) 
                                    )
                                    : "N/A"
                                }
                              </Text>

                              <Divider m='1' />
                              <Text fontWeight="bold" >Send Date: </Text> <Text>{productSelected?.[0]?.send_date}</Text>
                              <Divider m='1' />
                              <Text fontWeight="bold" >Send Shift: </Text> <Text>{productSelected?.[0]?.send_shift}</Text>
                              <Divider m='1' />
                              <Text fontWeight="bold" >Machine: </Text> <Text>{productSelected?.[0]?.machine}</Text>
                              <Divider m='1' />

                            </div>

                          </VStack>

                        ) : (
                          <>
                            <Box p='4' boxShadow={'xs'} justifyContent='center'>
                              {/* <Text fontSize='xs'>-- PLEASE SELECT YOUR PRODUCT --</Text> */}
                              <Spacer />
                            </Box>
                          </>)
                        }

                      </Box>



                      <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center">
                        <ButtonGroup mt='5'>
                          <VStack>
                            <Button
                              ref={btnRef}
                              colorScheme='teal'
                              onClick={onOpen}
                              leftIcon={<MdForklift size='1.5em' />}
                              w='100%'>
                              Job List
                            </Button>

                            <Button
                              ref={btnRef}
                              colorScheme='teal'
                              variant='outline'
                              onClick={() => handleEditAndClearLocation(productSelected[0].id, 'edit')}
                              leftIcon={<AiFillEdit />}
                              w='100%'
                              isDisabled={!isCompleted}>
                              Edit Locations
                            </Button>
                          </VStack>
                        </ButtonGroup>
                      </Box>




                    </Box>


                    <Box  rounded='md'
                        boxShadow='base' 
                        p='5' 
                         bg='white' width='100%' flex='2' >

                  <Box> <ZoneTags  />  </Box> 



                    </Box>
                  </Flex>
                </GridItem>




              </Grid>
            </div>



          </TabPanel>
          <TabPanel>


          </TabPanel>

        </TabPanels>
      </Tabs>

        
      <DrawerExample isOpen={isOpen} onClose={onClose} btnRef={btnRef} handleProductSelect={handleProductSelect}
          handleUnProductSelect={handleUnProductSelect}
          CheckIdStatus={CheckIdStatus}
          handleEditAndClearLocation={handleEditAndClearLocation}
          get_fillplanlist={get_withdrawplanlist}
          fillplan={payloadWithdraw}
          setFillPlan={setpayloadWithdraw}
          resetToDefaultState={resetToDefaultState}
        />
   
    </Box>
  );
};


export default WdOverview
