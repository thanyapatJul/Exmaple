
import { useCallback } from 'react';

export const useZoneComparison = () => {
  const getUniqueMapIdInfo = useCallback((zones) => {
    const uniqueMapIdInfo = {};
    
    zones.forEach(zone => {
      const { mapid, level, sub_column, column, row } = zone;
      const key = `${mapid}-${sub_column}`;
      // ตรวจสอบว่า level ที่เก็บไว้สำหรับ mapid นี้คือ level ที่ต่ำที่สุดหรือไม่
      if (!uniqueMapIdInfo[key] || uniqueMapIdInfo[key].level > level) {
        uniqueMapIdInfo[key] = { level, column, row };
      }
    });
  
    return uniqueMapIdInfo;
  }, []);

  const compareZoneLevels = useCallback((oldZones, newZones) => {
    const oldInfo = getUniqueMapIdInfo(oldZones);
    const newInfo = getUniqueMapIdInfo(newZones);
  
    const problemDetails = [];
  
    for (const key in newInfo) {
      const { level: newLevel, column: newColumn, row: newRow } = newInfo[key];
      const oldLevelData = oldInfo[key];
  
      // ถ้า oldInfo มีข้อมูลและ level ใหม่ต่างจาก level เก่า
      if (oldLevelData && newLevel !== oldLevelData.level) {
        problemDetails.push({
          column: newColumn,
          row: newRow,
          level: newLevel,
        });
      }
    }
  
    return problemDetails.length > 0 ? problemDetails : false;
  }, [getUniqueMapIdInfo]);

  return { compareZoneLevels };
};


export const countAllMembers = (data) => {
  return Object.values(data).reduce((acc1, nextLevel1) => 
    acc1 + Object.values(nextLevel1).reduce((acc2, nextLevel2) => 
      acc2 + Object.values(nextLevel2).reduce((acc3, value) => 
        acc3 + (value.is_used === true ? 1 : 0)
      , 0)
    , 0)
  , 0);
};





