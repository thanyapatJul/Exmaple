import React, { useState ,useEffect, useRef } from 'react';
import { useSetRecoilState, useRecoilValue,useRecoilState } from 'recoil';
import { withdrawSelectedState,WDreloadState,wdmulticlickedZone_Info as multiclickedZoneInfoAtom, zonesAtom,zonestempState } from '../TransferOverview/Atoms';
import { colname_113a } from '../TransferOverview/zone_113a';
import { Spinner } from "@chakra-ui/react";


import { IoMdCheckmark } from "react-icons/io";
import Swal from 'sweetalert2';
import { Box,
    Text,
Stack,
ButtonGroup,
Button,
Popover,
PopoverTrigger,
Tag,
PopoverContent,
FocusLock,
PopoverArrow,
PopoverCloseButton,
Divider,
FormControl,
FormLabel,
List,
Tooltip,
ListItem,
HStack,
VStack,
StackDivider,
Input,

 } from "@chakra-ui/react";
 import { useDisclosure } from "@chakra-ui/react";
import Map_a from '../TransferOverview/map_w113.png';
import Map_b from '../TransferOverview/map_w3.png';
import Axios from 'axios';
Axios.defaults.xsrfCookieName = 'csrftoken';
Axios.defaults.xsrfHeaderName = 'X-CSRFToken';
Axios.defaults.withCredentials = true;

const client = Axios.create({
    baseURL: `${process.env.REACT_APP_API_URL}`
});

const TooltipforMap = () => {

}




const ZoneDataHandler = ({ zones,setZones, setHighestLevels,setIsLoading,warehouse_id,setZones_V }) => {
    const [column_113,setColumn_113] = useState(colname_113a)
    const zones_temp = useRecoilValue(zonestempState)

    /////////////////////////////////////  First Mount   /////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////
    if (warehouse_id === '1') {
        setZones_V(column_113)
    }
    useEffect(() => {
        async function fetchDataAndUpdateZones() {
            setIsLoading(true);
            try {
                const [mapResponse, infoResponse] = await Promise.all([
                    client.get(`/wms/api/get_map_location_info/?warehouse_id=${warehouse_id}`),
                    client.get('/wms/api/map_management/'),
                ]);

                const mapData = await mapResponse.data;
                const infoData = await infoResponse.data;

                console.log(mapData, 'mapData')
                console.log(infoData, 'infoData')
                console.log(zones_temp, 'zones_temp_first_month')

                let newZones = mapData.map((zone) => {
                    let levels = {};

                    for (let i = 1; i <= zone.max_level; i++) {
                        levels[i] = { sub_column: {} };

                        for (let j = 1; j <= zone.sub_column; j++) {
                            // ค้นหาใน zones_temp ก่อน
                            let matchingTempZone;
                            if (zones_temp) {
                                matchingTempZone = zones_temp.find(data => data.mapid === zone.mapid && data.level === i.toString() && data.sub_column === j);
                            }
                            
                            console.log(matchingTempZone,'matchingTempZone')
                        
                            // หากไม่พบใน zones_temp ให้ค้นหาใน infoData
                            if (!matchingTempZone) {
                                matchingTempZone = infoData.find(data =>
                                    data.mapid === zone.mapid && data.level === i && data.sub_column === j
                                );
                            }
                        
                            if (matchingTempZone) {
                                levels[i].sub_column[j] = {
                                    data: matchingTempZone
                                };
                            } else {
                                levels[i].sub_column[j] = {
                                    data: null
                                };
                            }
                        }
                        
                    }

                    return {
                        ...zone,
                        levels,
                    };
                });

                console.log(newZones,'first-mounth')
                setZones(newZones);
                setIsLoading(false);
            } catch (error) {
                console.error('Error fetching data:', error);
                setIsLoading(false);  // Set loading to false even on failure
            }

        }

        fetchDataAndUpdateZones();
    }, []);

    //////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////

    useEffect(() => {
        if (zones) {
            const highestLevelsPerMapId = {};

            zones.forEach(zone => {
                const { mapid, levels } = zone;

                // Initialize this to 0 for each new zone
                let highestLevelForThisMapId = 0;

                // If there is already a recorded highest level for this mapid, use that as a starting point
                if (highestLevelsPerMapId.hasOwnProperty(mapid)) {
                    highestLevelForThisMapId = highestLevelsPerMapId[mapid];
                }

                if (levels) {
                    Object.keys(levels).forEach(level => {
                        const subColumns = levels[level].sub_column;
                        const levelInt = parseInt(level, 10);

                        // Check for data in sub_columns
                        if (subColumns) {
                            Object.values(subColumns).forEach(subColumn => {
                                // If the data within a subColumn is not null and levelInt is higher than highestLevelForThisMapId
                                if (subColumn.data !== null && levelInt > highestLevelForThisMapId) {
                                    highestLevelForThisMapId = levelInt;
                                }
                            });
                        }
                    });
                }


                highestLevelsPerMapId[mapid] = highestLevelForThisMapId;
            });

            setHighestLevels(highestLevelsPerMapId);
        }
    }, [zones]);

    return null; // Component นี้ไม่ render อะไรเลย
};




const BackGroundDisplay = (Warehouse_id) => {

    const defaultStyle = {
        position: 'relative',
        backgroundColor: 'white',
        borderRadius: '10px',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      };


    const warehouseStyles = {
        1: {
          width: '2080px',
          height: '2080px',
          backgroundImage: `url(${Map_a})`
        },
        2: {
          width: '1500px',
          height: '1500px',
          backgroundImage: `url(${Map_b})`
        },

      };


    

      return {
        ...defaultStyle,
        ...warehouseStyles[Warehouse_id]
    };
}

const Form = ({  onCancel, zonecol,zone,handleClose }) => {
    const TextInput = React.forwardRef((props, ref) => {
        return (
          <FormControl>
            <FormLabel htmlFor={props.id}>{props.label}</FormLabel>
            <Input ref={ref} id={props.id} {...props} />
          </FormControl>
        )
      })
    const [reload, setReload] = useRecoilState(WDreloadState)
    const zones = useRecoilValue(zonesAtom)
    const firstFieldRef = React.useRef(null)
    const secondFieldRef = React.useRef(null)


    const zone_no = parseFloat(zonecol)
    const [oldData, setOldData] = useState(null);
  
  const matchingColumns = zones?.filter(item => item.column === zone_no);
  // console.log(matchingColumns,'matchingColumns')
  if (matchingColumns.length > 0) {
      const newOldData = matchingColumns[0];
      
      if (JSON.stringify(oldData) !== JSON.stringify(newOldData)) {
          setOldData(newOldData);
      }
  }


  
  
    const handleSave = () => {


        const computeValue = (size, actual_size) => {
        const quotient = actual_size / size;
        console.log(quotient,'quotient')
        const result = Math.floor(quotient)
        console.log(result,'result')
        if (result >= 1) {
            return result;
        } else {
      
            return 0;
        }
      }
      const actual_size = zone.actual_size
      const size = secondFieldRef.current.value
      
      const sub_col = computeValue(size,actual_size)
      
      console.log(actual_size,'actual_size')
      console.log(size,'size')
      console.log(sub_col,'sub_col')
      if (sub_col === 0) {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: `ห้ามเลือก ​Size ขนาดมากกว่า Actual Size`,
        });
      } else {

      console.log(firstFieldRef.current.value,'firstFieldRef.current.value')
      console.log(secondFieldRef.current.value,'secondFieldRef.current.value')
      
      const hasExistingLevels = zones.some(zone => 
        zone.column === zone_no && 
        Object.values(zone.levels || {}).some(level => 
            Object.values(level.sub_column || {}).some(sub_col =>
                sub_col.data != null
            )
        )
    );


    // If there's a zone that matches the condition, show an alert
    if (hasExistingLevels) {
        alert('This zone already has levels data!');
        return; // exit from the function
    }


      const data = {
        column: zonecol,
        max_level: firstFieldRef.current.value,
        size: secondFieldRef.current.value,
        sub_column: sub_col
        // หากต้องการส่งข้อมูลอื่น ๆ คุณสามารถเพิ่มได้ที่นี่
      };

      console.log(data,'data')

      Axios.post('http://localhost:8000/wms/api/update_map_location_info/', data)
        .then(response => {
          console.log("Data saved successfully", response.data);
          handleClose()
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: `Your Size is now update`,
          });
          setReload(!reload)
        })
        .catch(error => {
          console.error("There was an error saving the data", error);
        });
      }
    };
  
    return (
      <Stack spacing={4}>
        <TextInput
          label='Max-level'
          id='max_level'
          ref={firstFieldRef}
          defaultValue={oldData ? oldData.max_level : '-'}
        />
        <TextInput 
          label='Size' 
          id='size' 
          ref={secondFieldRef}
          defaultValue={oldData ? oldData.size : '-'} 
        />
        <ButtonGroup display='flex' justifyContent='flex-end'>
          <Button variant='outline' onClick={handleClose}>
            Cancel
          </Button>
          <Button onClick={handleSave} colorScheme='teal'>
            Save
          </Button>
        </ButtonGroup>
      </Stack>
    )
  }
    
const ZoneTagWithPopover = ({ zone,  openedPopoverId, handleOpen, handleClose }) => {

    return (
      <div
        key={zone.mapid}
        style={{
          position: 'absolute',
          left: `${zone.x}px`,
          top: `${zone.y}px`,
          width: zone.width || '35px',
          height: zone.height || '60px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
    
          <>

              <Popover
                isOpen={openedPopoverId === zone.mapid}
                onClose={handleClose}
                placement='right'
                closeOnBlur={false}
                
              >
                   <PopoverTrigger >
            <Tag 
              variant="solid" 
              colorScheme="teal" 
              cursor='pointer' 
              onClick={() => handleOpen(zone.mapid)}
            >
              {zone.column}
            </Tag>
            </PopoverTrigger>
                <PopoverContent p={5}>
                  <FocusLock returnFocus persistentFocus={false}>
                    <PopoverArrow />
                    <PopoverCloseButton />
                    <Text>Column:{zone.column}</Text>
                    <Text>Actual_size:{zone.actual_size}</Text>
                    <Divider m='1'/>
                    <Form 
               
                          zonecol={zone.column} 
                          zone = {zone}
                          handleClose= {handleClose}
                        />

                  </FocusLock>
                </PopoverContent>
              </Popover>
     
          </>
     
      </div>
    );
  }


const MapDisplay = ({ Warehouse_id,isFilterActive }) => {
    const [openedPopoverId, setOpenedPopoverId] = useState(null);
    const handleOpen = (id) => setOpenedPopoverId(id);
    const handleClose = () => setOpenedPopoverId(null);
    const { onOpen, onClose, isOpen } = useDisclosure()
    const [zone_v, setZone_v] = useState(null);
    const [zones, setZones ] = useRecoilState(zonesAtom)
    const [ productSelected, setProductSelected ] = useRecoilState(withdrawSelectedState)
    // recoilState //
    const [multiclickedZone_Info , setmultiClickedZone_Info] = useRecoilState(multiclickedZoneInfoAtom)

    useEffect(() => {
      console.log(multiclickedZone_Info,'multiclickedZone_Info')
    }, [multiclickedZone_Info])
    
    // // // // // //
    const warehouse_id = Warehouse_id
    const [highestLevels, setHighestLevels] = useState({});
    const [isLoading, setIsLoading] = useState(true);
    const [showTooltip, setShowTooltip] = useState('');
    const [hoveredZone, setHoveredZone] = useState(null);
    const [tagClicked,setTagClicked] = useState(null);

     /////////////////////////////////// Zones Stylist ////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////////////////////////////////

     const getBackgroundColor = (zone) => {

       const getNewColorWithOpacity = (originalColor, newOpacity) => {
         const matches = originalColor.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/);

         if (matches) {
           return `rgba(${matches[1]}, ${matches[2]}, ${matches[3]}, ${newOpacity})`;
         }
         return originalColor;
       };

       const getInitialColor = () => {

        if (isFilterActive) {
          let MatchingZca = Object.values(zone.levels).some(level =>
              Object.values(level.sub_column || {}).some(sub =>
                  sub.data && sub.data.zca_on === productSelected.zca_on
              )
          );
          let NotNullData = Object.values(zone.levels).some(level =>
              Object.values(level.sub_column || {}).some(sub =>
                  sub.data && sub.data !== null
              )
          );
  
          if (MatchingZca) {
              return 'rgba(214, 137, 16, 1)';
          }
  
          if (NotNullData) {
              return 'rgba(218, 203, 180, 1)';  // Corrected here by adding the return statement
          }
  
          return 'rgba(211, 211, 211, 1)';
      }
         //ตรวจสอบความสูงของ zone
         const highestLevelForZone = highestLevels[zone.mapid];

         // ตรวจสอบค่า success
         let hasSuccessFalse = Object.values(zone.levels).some(level =>
           Object.values(level.sub_column || {}).some(sub =>
             sub.data && sub.data.success === false
           )
         );

         if (hasSuccessFalse) {
           return 'rgba(174, 214, 241, 1)';
         }

         // ตรวจสอบค่า map_approve
         let hasMapApproveFalse = Object.values(zone.levels).some(level =>
           Object.values(level.sub_column || {}).some(sub =>
             sub.data && sub.data.map_approve === 1
           )
         );

         let hasWithdraw = Object.values(zone.levels).some(level =>
          Object.values(level.sub_column || {}).some(sub =>
            sub.data && sub.data.map_approve === 2
          )
        );



         if (hasMapApproveFalse) {
           if (highestLevelForZone === zone.max_level) {
             return 'rgba(187, 143, 206, 1)';
           } else if (highestLevelForZone <= zone.max_level && highestLevelForZone >= 1) {
             return 'rgba(212, 185, 223, 1)';
           }

           return 'rgba(187, 143, 206, 1)';
         }

         if (hasWithdraw) {
          if (highestLevelForZone === zone.max_level) {
            return 'rgba(245, 176, 65, 1)';
          } else if (highestLevelForZone <= zone.max_level && highestLevelForZone >= 1) {
            return 'rgba(248, 196, 113, 1)';
          }

          return 'rgba(245, 176, 65, 1)';
        }


         if (highestLevelForZone === zone.max_level) {
           return 'rgba(234, 197, 197, 1)';
         } else if (highestLevelForZone <= zone.max_level && highestLevelForZone >= 1) {
           return 'rgba(234, 228, 197, 1)';
         }

         return 'rgba(211, 211, 211, 1)';
       };

       const initialColor = getInitialColor();

       // ถ้า hoveredZone ตรงกับ zone ให้เปลี่ยน opacity ในทุกๆสถานการณ์
       if (hoveredZone === zone) {
           return getNewColorWithOpacity(initialColor, 0.7);
       }
   
       return initialColor;
   };
    

   const generateInitialData = (levels) => {
    const zcaData = {};
  
    Object.values(levels).forEach(levelData => {
      Object.values(levelData.sub_column).forEach(subCol => {
        if (subCol.data?.name_th) {
          if (!zcaData[subCol.data.name_th]) {
            zcaData[subCol.data.name_th] = subCol.data.zca_on;
          }
        }
      });
    });
  
    return zcaData;
};

  
  
      const renderGroupedLevels = (levels, initialData) => {
        const assignColorsSequentially = (initialData, zone) => {
          const colors = ["#F99417", "#4D4C7D", "#125B50", "#DD4A48", "#79B4B7"];
          const zcaColors = {};
        
          // ตรวจสอบการจับคู่ของ Zca เมื่อเปิดใช้งานการกรอง
          Object.keys(initialData).forEach((zca, index) => {
            if (isFilterActive) {
              if (initialData[zca] === productSelected.zca_on) {
                zcaColors[zca] = 'rgba(214, 137, 16, 1)';
              } else {
                zcaColors[zca] = 'rgba(218, 203, 180, 1)';
              }
            } else {
              zcaColors[zca] = colors[index % colors.length];
            }
          });
    
          return zcaColors;
        };
        
        
        const zcaColors = assignColorsSequentially(initialData);
        
        // สร้าง list items สำหรับ zca พร้อมสัญลักษณ์สี
        const zcaDisplays = Object.entries(initialData).map(([zca], index) => (
          <Box key={index} display="flex" justifyContent="space-between" alignItems="center" mb="2">
            <Box bgColor={zcaColors[zca]} width="20px" height="20px"></Box>
            <Box fontSize={'10px'} flex="1" ml='1'> 
               : {zca}
            </Box>
          </Box>
        ));
        
        
      
        // สร้าง list items สำหรับ levels ที่ใช้สัญลักษณ์สีตาม zca
        const levelDisplays = Object.values(levels).map((levelData, index) => (
          <ListItem key={index} whiteSpace='nowrap'>
            
            <HStack spacing={2}>
              <Box minW='60px'>
            <Text  as="span" color="blue.500">Level {index + 1}:</Text>
            </Box>
            <Box w='150px' display="flex">
            {Object.values(levelData.sub_column).map((subCol, subIndex) => (
    <Box
      flex='1'
      mx='1'
      key={subIndex}
      // width="40px"
      height="25px"
      position="relative"
      background={subCol.data 
        ? zcaColors[subCol.data.name_th] 
        : 'grey'}
      display="flex"
      alignItems="center"
      justifyContent="center"
      fontSize="10px"
      color={'white'} // กำหนดสีตัวอักษรเป็นขาวหากเป็นกล่องสีเทา
    >
      {
        subCol.data 
          ? subCol.data.pcsperpallet % subCol.data.qty !== 0 
            ? subCol.data.qty 
            : ""
          : "-"
      }
      {/* <Box bgColor='teal' position={'absolute'} right="0" px='2'> Lab </Box> */}
    </Box>
  ))}
  </Box>
  
            </HStack>
          </ListItem>
        ));
      
        // รวมการแสดงผลทั้งสองส่วนเข้าด้วยกัน
        return (
          <Box p='4' >
            <HStack  divider={<StackDivider borderColor='gray.800' orientation='vertical' />}>
          <List>
            <VStack divider={<StackDivider borderColor='gray.200' />} flexDirection="column-reverse">
    
              {levelDisplays}
   

            </VStack>
          </List>

            <Box p='4' > 
          {zcaDisplays}
          </Box>
          </HStack>
          
          </Box>
        );
      };


     //////////////////////////////////////////////////////////////////////////////////////////////////
     //////////////////////////////////////////////////////////////////////////////////////////////////

    
    // const memoizedRenderGroupedLevels = React.useMemo(
    //         () => renderGroupedLevels(zone.levels, generateInitialData(zone.levels)),[zone] );

    const handleZoneHover = (zoneId) => {
        const hoveredZone = zones.find(item => item.mapid === zoneId);
        console.log('!hover')
        setShowTooltip(zoneId);
        setHoveredZone(hoveredZone);
        
    };
    const handleZoneUnHover = (zoneId) => {
        setHoveredZone('') 
        setShowTooltip(null)

    }

    const handleZoneClick = (zone) => {
        if (!zone) {
          console.warn('Zone is null or undefined');
          return;
        }
        
        if (!multiclickedZone_Info) {
          console.warn('multiclickedZone_Info is null or undefined');
          return;
        }
        // if (productSelected.length === 0 || productSelected === null ) {
        //   alert('Hell ya, You need to pick Product First !!')
        //   return;
        // }
        // if (zone.size * 100 < productSelected?.[0]?.product_length) {
        //   alert('Agian!, You better not pick a Different Size Dumb ass')
        //   return;
          
        // }
        // let totalCount = 0;

        // Object.keys(multiclickedZone_Info).forEach(outerKey => {
        //     totalCount += Object.keys(multiclickedZone_Info[outerKey]).length;
        // });
        // if (Object.keys(productSelected).length < totalCount)
        // {
        //     alert('คุณหยิบเกินจำนวนแล้ว !')

        // }
        // console.log(Object.keys(productSelected).length,totalCount)
        
        const zone_mapid = zone.mapid;
        const isAlreadyClicked = Object.keys(multiclickedZone_Info).includes(zone_mapid);
      
        if (isAlreadyClicked) {
          setmultiClickedZone_Info(prevClickedZones => {
            if (!prevClickedZones) return {}; // add this line
            const newZones = { ...prevClickedZones };
            delete newZones[zone_mapid];
            setTagClicked(null) // Debugging line
            
            return newZones;
          });
        } else {      
          if (!zone.levels) {
            console.warn('zone.levels is null or undefined');
            return;
          }

          const transformData = (zone) => {
            const newRow = {};
        
            if (!zone.levels || !zone.sub_column) {
                return newRow;
            }
        
            Object.keys(zone.levels).forEach(level => {
                if (!zone.levels[level].sub_column) {
                    return; // continue to the next iteration
                }
        
                for (let i = 1; i <= zone.sub_column; i++) {
                    if (
                        zone.levels[level].sub_column[i] &&
                        zone.levels[level].sub_column[i].data &&
                        zone.levels[level].sub_column[i].data.zca_on === productSelected.zca_on
                    ) {
                        // Initialize nested properties if they don't exist
                        newRow[zone.mapid] = newRow[zone.mapid] || {};
                        newRow[zone.mapid][level] = newRow[zone.mapid][level] || {};
        
                        newRow[zone.mapid][level][i] = {
                            ...zone.levels[level].sub_column[i].data,
                            level,
                            column: zone.column,
                            row: zone.row,
                            mapid: zone.mapid,
                            warehouse: zone.warehouse_id,
                            zone: zone.zone,
                            sub_column: i,
                            is_used: true,
                        };
                    }
                }
            });
        
            return newRow;
        };
        
        
        setmultiClickedZone_Info(prevClickedZones => {
          if (!prevClickedZones) return {}; // this line is correct
      
          return { ...prevClickedZones, ...transformData(zone) };
      });
      
        }
      };
      const RenderZone = ({ zone, hoveredZone, handleZoneHover, setHoveredZone, handleZoneClick, highestLevels, multiclickedZone_Info }) => {

        const memoizedRenderGroupedLevels = React.useMemo(
            () => renderGroupedLevels(zone.levels, generateInitialData(zone.levels)),
            [zone]
        );
    
        return (
            <Tooltip border='1px solid black' hasArrow color='black' bg='white' isOpen={showTooltip === zone.mapid}
    closeDelay={100} label={
        <Box w="800px" >
            {memoizedRenderGroupedLevels}
        </Box>
    }  fontSize='md' placement='right' 
    >
                <div
                    key={zone.mapid}
                    style={{
                        position: 'absolute',
                        left: `${zone.x_position}px`,
                        top: `${zone.y_position}px`,
                        width: zone.width || '35px',
                        height: zone.height || '60px',
                        backgroundColor: getBackgroundColor(zone),
                        display: 'flex',
                        cursor: 'pointer',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'space-evenly',
                    }}
                    onMouseEnter={() => handleZoneHover(zone.mapid)}
                    onMouseLeave={() => handleZoneUnHover(zone.mapid) }
                    onClick={() => handleZoneClick(zone)}
                >
                    <Text fontSize='11px'>{zone.sub_column ? zone.sub_column : null}</Text>
                    <label>{highestLevels[zone.mapid]}</label>
                    {Object.keys(multiclickedZone_Info).includes(zone.mapid) && (<IoMdCheckmark />)}
                </div>
            </Tooltip>
        );
    }
    

    return (
        
        <>
            {/* FIRST MOUNT AND FIND LEVELS */}
            <ZoneDataHandler zones={zones} setZones={setZones} setZones_V={setZone_v} setHighestLevels={setHighestLevels} setIsLoading={setIsLoading} warehouse_id={warehouse_id} />
            {/* FIRST MOUNT AND FIND LEVELS */}

            <Box bg='white' h={{ sm: '500px', md: '600px', lg: '700px', xl: '700px' }} overflow='auto' >
                {isLoading ? (
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                        <Spinner size="xl" />
                    </div>
                ) : (
                    <div
                        style={BackGroundDisplay(warehouse_id)}
                    >

                        <div style={{ whiteSpace: 'pre-line' }}>
                                {zones && zones.length && zones.map((zone) => (
                                    <RenderZone
                                        zone={zone}
                                        hoveredZone={hoveredZone}
                                        handleZoneHover={handleZoneHover}
                                        setHoveredZone={setHoveredZone}
                                        handleZoneClick={handleZoneClick}
                                        highestLevels={highestLevels}
                                        multiclickedZone_Info={multiclickedZone_Info}
                                    />
                                ))}


                        </div>


                        
                        {zone_v && zone_v.map(zone =>
                            <ZoneTagWithPopover
                                zone={zone}

                                openedPopoverId={openedPopoverId}
                                handleOpen={handleOpen}
                                handleClose={handleClose}
                            />
                        )}



                    </div>
                )}
            </Box>
        </>
    );
    }

export default MapDisplay;


