// atoms.js
import { atom } from 'recoil';



export const WDreloadState = atom({
  key: 'WDreloadState', // unique ID (with respect to other atoms/selectors)
  default: false,     // default value
});

export const withdrawSelectedState = atom({
  key: 'withdrawSelectedState',
  default: ''
});



/////////////////// DATA FROM MABEAM ///////////////////
export const get_withdrawplanState = atom({
  key: 'get_withdrawplanState',
  default: ''
})
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////


export const payloadWithDrawPlan = atom({
  key: 'payloadWithDrawPlan',
  default: ''
})

export const default_payloadWithDrawPlan = atom({
  key: 'default_payloadWithDrawPlan',
  default: ''
})

export const dataToUpdateWithdraw = atom({
  key: 'dataToUpdateWithdraw',
  default: ''
})