import React, { useState, useEffect, startTransition, useTransition, useRef } from 'react';
import {
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  HStack,
  Input,
  Select,
  Table,
  Thead,
  Tr,
  Th,
  Tbody,
  Td,
  Text,
  Button,
} from '@chakra-ui/react';
import { useRecoilValue, useRecoilState } from 'recoil';
import { BiCheck, BiError } from "react-icons/bi";
import { IoAlertCircleSharp } from "react-icons/io5"
import { get_fillplanlist, get_withdrawplanlist } from './Selectors';
import { withdrawSelectedState, payloadWithDrawPlan, WDreloadState, default_payloadWithDrawPlan,dataToUpdateWithdraw,zonestempState } from './Atoms'
import { BsFillCheckCircleFill } from 'react-icons/bs'
import Swal from 'sweetalert2';
import { Badge } from '@chakra-ui/react'
import { useToast } from '@chakra-ui/react';
import Axios from 'axios';
Axios.defaults.xsrfCookieName = 'csrftoken';
Axios.defaults.xsrfHeaderName = 'X-CSRFToken';
Axios.defaults.withCredentials = true;

const client = Axios.create({
  baseURL: "http://localhost:8000"
});

function DrawerExample({ isOpen, onClose, btnRef, handleProductSelect }) {
  const [productSelected, setProductSelected] = useRecoilState(withdrawSelectedState);
  const [zones_temp, setZones_temp] = useRecoilState(zonestempState)
  const [rerender, setRerender] = useState(0);
  const [selectedStatus, setselectedStatus] = useState(false)
  const [reload, setReload] = useRecoilState(WDreloadState);
  const isMounted = useRef(true);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedShift, setSelectedShift] = useState(null);
  const [default_dataforupdatefillplan, setdefault_dataforupdatefillplan] = useRecoilState(default_payloadWithDrawPlan);
  const [isPending, startTransition] = useTransition();
  const fillplanlistState = useRecoilValue(get_fillplanlist);
  const withdrawplanlistState = useRecoilValue(get_withdrawplanlist)
  const [dataforupdatefillplan, setdataforupdatefillplan] = useRecoilState(payloadWithDrawPlan);
  const [updateplan, setUpdateplan] = useRecoilState(dataToUpdateWithdraw);

  useEffect(() => {
    console.log(updateplan,'updateplan')
  }, [updateplan])
  
  const handleDateChange = (e) => {
    startTransition(() => {
      setSelectedDate(e.target.value);
    });
  };

  const handleShiftChange = (e) => {
    startTransition(() => {
      setSelectedShift(e.target.value);
    });
  };


  const [saveMode, setsaveMode] = useState(false);

  const filteredData = selectedDate && selectedShift
  ? withdrawplanlistState.filter(item => item.receive_date === selectedDate && item.receive_shift === selectedShift)
  : withdrawplanlistState;

  const groupedData = filteredData.reduce((acc, item) => {
    if (!acc[item.machine]) {
      acc[item.machine] = []; // Initialize as an array, not an object
    }

    acc[item.machine].push(item); // Now you can push to it because it's an array
  
    return acc;
}, {});


  const handleSave = () => {
    setdataforupdatefillplan(filteredData)
    setdefault_dataforupdatefillplan(filteredData)
    setselectedStatus(true);
    setsaveMode(true)
  }

  useEffect(() => {
    console.log(selectedStatus, 'selectedStatus')
  }, [selectedStatus])

  const handleCancel = () => {
    Swal.fire({
      title: 'Are you sure you want to cancel?',
      icon: 'warning',
      text: 'หากยกเลิกข้อมูล map ที่เลือกไว้จะถูกยกเลิกด้วย',
      showCancelButton: true,
      cancelButtonText: 'No, keep it',
      confirmButtonText: 'Yes, cancel it!',
      confirmButtonColor: '#E51212',

    }).then((result) => {
      if (result.isConfirmed) {
        setselectedStatus(false)
        setProductSelected(null)
        setdefault_dataforupdatefillplan(null)
        setdataforupdatefillplan(null)
        setsaveMode(false)
        setZones_temp(null)
        setUpdateplan(null)
        setReload(!reload);

      }
    });
  };

  useEffect(() => {
    console.log(filteredData, 'filteredData')
  }, [filteredData])

  useEffect(() => {
    console.log(default_dataforupdatefillplan, 'default_dataforupdatefillplan')
  }, [filteredData])


  const toast = useToast();




  const checkMapIdStatusInDataForUpdateFillPlan = (dataForUpdateFillPlan) => {
    const machineData = dataForUpdateFillPlan;
    if (!machineData) return 'ยังไม่เสร็จ'; // or other default text


    return machineData.withdraw_success ? <Badge colorScheme='green'>Success</Badge> :  <Badge fontSize='0.9em' colorScheme='yellow'>in progress</Badge>  ;
  };

  const checkMapIdStatusForAllData = (dataforupdatefillplan) => {

    return true;
  };



  const handleEmergency = async () => {
    const isAllCompleted = checkMapIdStatusForAllData(dataforupdatefillplan);
    if (isAllCompleted === null) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: `ไม่มีข้อมูลที่จะบันทึก !`,
        
      });
      return;
  } else if (!isAllCompleted) {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: `กรุณาเลือกพื้นที่ให้ครบทุก ZCA !`,

    });
      return;
  } else {
    try {
      const postResponse = await Axios.post('http://127.0.0.1:8000/wms/api/updateWithdraw/', updateplan);
      const patchResponse = await Axios.patch('http://127.0.0.1:8000/wms/api/updateWithdraw/', dataforupdatefillplan);
      const postJob = await Axios.post('http://127.0.0.1:8000/wms/api/post_withdrawplanjoblist/', updateplan)
      if (isMounted.current && postResponse.status === 200 && patchResponse.status === 200 && postJob.status === 200) {
        console.log('POST response:', postResponse.data);
        Swal.fire({
          icon: 'success',
          title: 'Your work has been saved',
          text: 'Good joob my son',
          showConfirmButton: false,
          timer: 1500
        })
        setRerender(rerender + 1);
      }
    
      setZones_temp(null)
      setsaveMode(false);
      setReload(!reload);
      onClose()
    } catch (error) {
      if (isMounted.current) {
        console.error('An error occurred:', error);
        toast({
          title: "Error",
          description: `An error occurred: ${error.message}`,
          status: "error",
          duration: 3000,
          isClosable: true,
        });
      }
    }
  }
  };
  


  const getToday = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  useEffect(() => {
    isMounted.current = true; // Set to true when component mounts
    console.log(withdrawplanlistState, 'withdrawplanlistState')
    setSelectedDate(getToday());

    return () => {
      isMounted.current = false; // Set to false when component unmounts
    };
  }, []);


  return (
    <Drawer size={'lg'} isOpen={isOpen} placement="right" onClose={onClose} finalFocusRef={btnRef} key={rerender}>
      <DrawerOverlay />
      <DrawerContent>
        <DrawerHeader>Job List</DrawerHeader>
        <DrawerBody>
          {isPending ? "Loading..." : null}
          <HStack spacing={4}>
            <Input
              placeholder="Select Date"
              size="md"
              type="date"
              onChange={handleDateChange}
              isDisabled={selectedStatus}
              value={selectedDate}
            />
            <Select placeholder="Shift"
              onChange={handleShiftChange}
              value={selectedShift}
              isDisabled={selectedStatus}
            >
              <option value="A">A</option>
              <option value="B">B</option>
              <option value="C">C</option>
            </Select>
          </HStack>
          <Table variant="simple">
            <Thead>
              <Tr>
                <Th>Product info</Th>
                <Th></Th>
                <Th></Th>
              </Tr>
            </Thead>
            {selectedDate && selectedShift ? (
              
              <Tbody>
                {Object.entries(groupedData).map(([machine, zca_ons]) => (
                  
                  <React.Fragment key={machine}>
                    <Tr>
                      <Td colSpan={2}>
                        <Text fontWeight="bold">Machine: {machine}</Text>
                      </Td>
                      <Td></Td>
                    </Tr>
                    {zca_ons.map((item, index) => {
                      // Define the border style within this loop, so it has access to the current zca_on
                      const borderStyle = productSelected && productSelected.zca_on === item.zca_on
                        ? '2px solid gray'
                        : 'none';  // or whatever the default is

                      return (
                        <Tr key={item.zca_on} style={{ border: borderStyle }}>
                          {dataforupdatefillplan ?
                            <Td> 
                            {checkMapIdStatusInDataForUpdateFillPlan(dataforupdatefillplan.find(i =>i.machine === machine && i.zca_on === item.zca_on))} 
                        </Td>
                         : null}
                          <Td>
                            <Text ml={4}>
                              {item.zca_on} : ({item.qty ? item.qty : "N/A"})
                            </Text>
                          </Td>
                          <Td>
                            {(
                              productSelected && productSelected.zca_on === item.zca_on ?
                                <Button isDisabled={true}>Selected</Button> :
                                <Button onClick={() => handleProductSelect(item)}>
                                  Select Product
                                </Button>
                    
                            )}
                          </Td>
                        </Tr>
                      );
                    })}

                  </React.Fragment>
                ))}
              </Tbody>

            ) : (<Text mt={4} textAlign='center'> - Please select a date and shift to view data. - </Text>)}
          </Table>
        </DrawerBody>
        <DrawerFooter>
          <Button variant="outline" mr={3} onClick={onClose}>
            Close
          </Button>
          {dataforupdatefillplan ? (
            <Button onClick={() => handleCancel()} mr={3}>
              Unselected
            </Button>
          ) : (
            null
          )}
          <Button
            colorScheme={saveMode ? "green" : "blue"}
            onClick={saveMode ? handleEmergency : handleSave}
            isDisabled={!selectedDate || !selectedShift || Object.keys(filteredData).length < 1}
          >
            {saveMode ? 'Submit' : 'Select'}
          </Button>



          {/* <Button colorScheme="blue" onClick={handleSave} isDisabled={!selectedDate || !selectedShift|| Object.keys(filteredData).length < 1}>
            {filteredData ?  'Select'  : 'Submit'}
          </Button>
          <Button colorScheme="red" onClick={handleEmergency} >
            Emergency
          </Button> */}
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

export default DrawerExample;
