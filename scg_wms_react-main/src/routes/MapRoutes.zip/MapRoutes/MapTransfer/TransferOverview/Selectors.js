import { selector } from 'recoil';
import Axios from 'axios';
const client = Axios.create({
  baseURL: "http://localhost:8000"
});

export const fetchProductList = selector({
  key: 'fetchProductList',
  get: async () => {
    try {
      const { data } = await client.get('/wms/api/get_products/');
      return data;
    } catch (error) {
      console.error('Fetch failed:', error);
      throw error;
    }
  },
});

export const fetchZoneList = selector({
  key: 'fetchZoneList',
  get: async () => {
    try {
      const { data } = await client.get('/wms/api/get_map_location_info/');
      return data;
    } catch (error) {
      console.error('Fetch failed:', error);
      throw error;
    }
  },
});

export const get_fillplanlist = selector({
  key: 'get_fillplanlist',
  get: async () => {
    try {
      const { data } = await client.get('/wms/api/get_fillplan/');
      return data;
    } catch (error) {
      console.error('Fetch failed:', error);
      throw error;
    }
  },
});

export const get_withdrawplanlist = selector({
  key: 'get_withdrawplanlist',
  get: async () => {
    try {
      const { data } = await client.get('/wms/api/get_withdrawplan/');
      return data;
    } catch (error) {
      console.error('Fetch failed:', error);
      throw error;
    }
  },
});
