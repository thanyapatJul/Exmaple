import { atom } from 'recoil';
export const wdmulticlickedZone_Info = atom({
    key: 'wdmulticlickedZone_Info',
    default: []
  })

export const zonesAtom = atom({
    key: 'zonesAtom',
    default: []
  })

export const zonestempState = atom({
  key: 'zonestempState',
  default: []
})

