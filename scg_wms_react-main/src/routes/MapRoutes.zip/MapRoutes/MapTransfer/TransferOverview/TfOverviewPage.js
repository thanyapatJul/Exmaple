import React, { useState, useTransition, useEffect, lazy, Suspense } from 'react';
import { useRecoilState } from 'recoil';

import { MdFilterAlt,MdFilterAltOff } from 'react-icons/md'
import  ZoneTags  from '../MapSelectPage/MapEditorPage'
import {
  Tabs, TabList, TabPanels, Tab, TabPanel, Text, Box, Grid, GridItem, Container, Heading, Highlight, Spacer, Button, Flex, Divider, Stack, StackDivider,
  ButtonGroup, VStack, Card, CardHeader, CardBody, CardFooter, SimpleGrid, useDisclosure, HStack, Badge, Tooltip,useToast
} from '@chakra-ui/react'

import { withdrawSelectedState, payloadWithDrawPlan, WDreloadState, selectedlocationState, default_payloadWithDrawPlan,dataToUpdateWithdraw,zonesAtom,zonestempState } from './Atoms'
import MapDisplay from '../MapSelectPage/MapDisplayPage.js';
import Map_warehouse from './map_warehouse.svg';
import Swal from 'sweetalert2'
import { FaBoxArchive } from "react-icons/fa6"
import { BsFillTrash3Fill } from "react-icons/bs"
const DrawerEdit = lazy(() => import('./DrawerWithdraw.jsx'));
const TfOverview = () => {
  const btnRef = React.useRef()
  const toast = useToast();
  const [zones, setZones] = useRecoilState(zonesAtom);
  const [zones_temp, setZones_temp] = useRecoilState(zonestempState)
  const [productSelected, setProductSelected] = useRecoilState(withdrawSelectedState);
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [default_dataforupdatefillplan, setdefault_dataforupdatefillplan] = useRecoilState(default_payloadWithDrawPlan);
  const [payloadWithdraw, setpayloadWithdraw] = useRecoilState(payloadWithDrawPlan);
  const [reload, setReload] = useRecoilState(WDreloadState);
  const [isFilterActive, setFilterActive] = useState(false);
  const [updateplan, setUpdateplan] = useRecoilState(dataToUpdateWithdraw);
  const [clickedZone, setClickedZone] = useState(null);
  const [hoveredZone, setHoveredZone] = useState(null);
  const [zones_warehouse, setZones_warehouse] = useState([

    { id: 1, x: 570, y: 60, name: 'Warehouse_113', info: 'Information about Zone B', width: 75, height: 140, clippath: "polygon(0% 0%, 0% 0%, 100% 50%, 100% 100%, 0% 100%)", mapid: '1' },
    { id: 2, x: 575, y: 270, name: 'Warehouse_W3', info: 'Information about Zone B', width: 112, height: 70, mapid: '2' },

  ]);

  useEffect(() => {
    console.log(updateplan,'dataToUpdateWithdraw')
  }, [updateplan])
  
  const handleZoneHover = (zoneId) => {
    const hoveredZone = zones_warehouse.find(item => item.mapid === zoneId);

    setHoveredZone(hoveredZone);
  };

  const handleZoneClick = (zoneId) => {

    setClickedZone(zoneId);
  };

  const check_status = (dataForUpdateFillPlan) => {
    return dataForUpdateFillPlan.withdraw_success === null ? <Badge fontSize='0.7em' colorScheme='yellow'>in progress</Badge> : <Badge fontSize='0.7em' colorScheme='green'>Success</Badge>;
  };


  const handleProductSelect = (product) => {

    setProductSelected(product);



    onClose();  // Close the drawer
  };

  const isButtonDisabled =
  !payloadWithdraw ||
  !payloadWithdraw.length ||
  (productSelected && payloadWithdraw.some(item =>
    item && item.id === productSelected.id && item.withdraw_success === 'success'
  ));



  const handleclearlocation = () => {
    // Ensure data is available for given machine and zca before attempting replacement

      Swal.fire({
        title: 'ยืนยันการ Clear locations?',
        icon: 'warning',
        text: 'หาก clear loactions แมพที่เลือกไว้ของ product นี้จะถูกรีเซ็ต',
        showCancelButton: true,
        cancelButtonText: 'ยกเลิก',
        confirmButtonText: 'ตกลง',
        confirmButtonColor: '#E51212',
  
      }).then((result) => {
        if (result.isConfirmed) {
          const updatedPayloadWithdraw = payloadWithdraw.map(item => {
            if (item.id === productSelected.id) {
              return {
                ...item,
                withdraw_success: null
              };
            }
            return item;
          });

          // อัพเดท state ด้วยค่าใหม่
          setpayloadWithdraw(updatedPayloadWithdraw);


          // 1. สร้าง flattenedGroupedData และ uniqueUpdatedData
          const filterData = updateplan[productSelected.id] || [] 
          const updatedZonesTemp = [...zones_temp];  // 1. สร้างสำเนาของ zones_temp

          filterData.forEach(updated => {
            const index = updatedZonesTemp.findIndex(z => z.mapid === updated.mapid);
            if (index !== -1) {
              updatedZonesTemp.splice(index, 1);  // 2. ลบข้อมูลที่ตรงกับ uniqueUpdatedData
            }
          });
          
          setZones_temp(updatedZonesTemp);

          const Newplanupdate = { ...updateplan };
          delete Newplanupdate[productSelected.id];
          setUpdateplan(Newplanupdate);
          
          

          setReload(!reload)



        toast({
          title: 'locations ถูกรีเซ็ตเรียบร้อย',
          description: `กรุณาเลือกพื้นที่ของ product ชนิดนี้ใหม่`,
          status: 'success',
          duration: 5000,
          isClosable: true,
          position: 'bottom-right'
        });


  
        }
      });

};

  return (
    <>

      <Box >
        <Tabs>
          <TabList>
            <Tab>Manual</Tab>
            <Tab>Suggestion</Tab>

          </TabList>

          <TabPanels>
            <TabPanel>


              <Grid
                bg='gray.100'
                templateRows='repeat(2, 1fr)'
                templateColumns='repeat(8, 1fr)'
                gap={4}
                h='90vh'
                w='100%'
              >
                <GridItem rowSpan={2} colSpan={6} bg='white' >
                  <Box p='5'  >
                    <Flex alignItems='flex-end' mb='4'>
                      <Heading>

                        Warehouse Layout : 113

                      </Heading>
                      { 
                                // แสดงปุ่ม filter หาก MapDisplay แสดง
                                clickedZone && 
                                <Box px='4' >
                                <Button onClick={() => setFilterActive(!isFilterActive)}>
                                    {isFilterActive ?  <MdFilterAltOff/> : <MdFilterAlt/>}
                                </Button>
                                </Box>
                            }

                      <Spacer />
                      <Button
                            size='sm'
                            colorScheme='gray'
                            mb='1.5'
                            onClick={() => {
                              setClickedZone(null);
                              setZones(null);
                            }}
                          >

                            ย้อนกลับ
                          </Button>
                    </Flex>


                    <Divider m='1' />
                    <Box mt='4' bgColor='white'  >
               
                         { clickedZone ? (
                            <Box >
                       
                                <MapDisplay key={reload} Warehouse_id={clickedZone} isFilterActive={isFilterActive} />
                    
                            </Box>
                          ) : (
                            <div
                              style={{
                                width: '900px',
                                height: '450px',
                                position: 'relative',
                                backgroundImage: `url(${Map_warehouse})`,
                                backgroundSize: '100% 100%',
                                backgroundPosition: 'center',
                              }}
                            >
                              {zones_warehouse.map((zone) => (
                                <Tooltip
                                  hasArrow
                                  key={zone.id}
                                  label={` ${zone.name}`}
                                  aria-label='Zone tooltip'
                                >
                                  <div
                                    style={{
                                      position: 'absolute',
                                      left: `${zone.x}px`,
                                      top: `${zone.y}px`,
                                      zIndex: 2,
                                    }}
                                    onMouseEnter={() => handleZoneHover(zone.mapid)}
                                    onMouseLeave={() => setHoveredZone(null)}
                                    onClick={() => handleZoneClick(zone.mapid, zone.name)}
                                  >
                                    <div
                                      style={{
                                        width: `${zone.width}px`,
                                        height: `${zone.height}px`,
                                        backgroundColor:
                                          hoveredZone === zone
                                            ? 'rgba(0, 0, 0, 0.5)'
                                            : 'transparent',
                                        clipPath: zone.clippath,
                                        border:
                                          hoveredZone === zone
                                            ? '1px solid black'
                                            : '2px solid black',
                                      }}
                                    ></div>
                                  </div>
                                </Tooltip>
                              ))}
                            </div>
                          )}
                                        



                    </Box>

                  </Box>

                </GridItem>

                <GridItem rowSpan={2} colSpan={2} bg='white' >
                  <Flex direction="column" h="100%">
                    <Box p='5' pb='0'>
                      <Flex alignItems='flex-end' mb='4'>
                        <Heading>
                          Map-Editor
                        </Heading>
                      </Flex>
                      <Divider m='1' />
                    </Box>

                    {/* This Box will expand to fill the remaining space */}
                    <Box flex="1" p='5' >
                      <Flex direction="column" height="100%"  >
                        <Box
                          flex="1"
                          borderRadius="lg"
                          p={4}
                          mb={4}
                          shadow="xs"
                        >
                          <HStack width="100%" height="100%">
                            <VStack width="50%" height="100%">
                              <Heading size='md'>
                                From
                              </Heading>
                              <Box
                                flex="1"
                                borderRadius="lg"
                                p={4}
                                mb={4}
                                shadow="xs"
                                width="100%"
                                height="100%"
                              >
                                {/* Content here */}
                              </Box>
                            </VStack>
                            <VStack width="50%" height="100%">
                              <Heading size='md'>
                                To
                              </Heading>
                              <Box
                                flex="1"
                                borderRadius="lg"
                                p={4}
                                mb={4}
                                shadow="xs"
                                width="100%"
                                height="100%"
                              >
                                {/* Content here */}
                              </Box>
                            </VStack>
                          </HStack>
                        </Box>



                        <Box flex="3" borderRadius="lg" overflow="hidden" p={4} mb={2} shadow="xs">

                          <Box> <ZoneTags Warehouse_id={clickedZone} />  </Box>

                        </Box>
                      </Flex>
                    </Box>
                  </Flex>
                </GridItem>

              </Grid>

            </TabPanel>
            <TabPanel>

              <Text>World </Text>

            </TabPanel>

          </TabPanels>
        </Tabs>


      </Box>
   

        <DrawerEdit isOpen={isOpen} onClose={onClose} btnRef={btnRef} handleProductSelect={handleProductSelect} />

    </>
  )

}

export default TfOverview
