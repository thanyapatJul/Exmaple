import React, { useState ,useEffect, useRef } from 'react';
import cloneDeep from 'lodash/cloneDeep';
import { useSetRecoilState, useRecoilValue,useRecoilState } from 'recoil';
import { productSelectedState } from '../MapOverviewPage/Atoms';
import {RiCheckboxBlankFill} from 'react-icons/ri'
import { Spinner } from "@chakra-ui/react";
import Swal from 'sweetalert2';
import _ from 'lodash';
import { tagClickedState,dataforupdatefillplanState,reloadState,multiclickedZone_Info as multiclickedZoneInfoAtom, zonestempState,zonesAtom } from '../MapOverviewPage/Atoms';
import {
    Heading,
    Divider,
    VStack,
    SimpleGrid,
    Tag,
    TagLabel,
    TagCloseButton,
    ButtonGroup,
    Button,
    StackDivider,
    FormControl,
    HStack,
    RadioGroup,
    Input,
    Checkbox,
    useToast,
    Radio,
    Flex,
    Spacer
  } from "@chakra-ui/react";

import { Box,Text } from "@chakra-ui/react";

import Axios from 'axios';


const ZoneTags =( Warehouse_id ) => {
    const [zones , setZones] = useRecoilState(zonesAtom)
    const [multiclickedZone_Info , setmultiClickedZone_Info] = useRecoilState(multiclickedZoneInfoAtom)
    const [productSelected, setProductSelected] = useRecoilState(productSelectedState);
    const [checkedLevels, setCheckedLevels] = useState({}); 
    const [tagClicked,setTagClicked] = useRecoilState(tagClickedState);
    const toast = useToast();
    const [hoveredTag, setHoveredTag] = useState(null);
    const [selectedRadio, setSelectedRadio] = useState(null);
    const [dataforupdatefillplan,setdataforupdatefillplan] = useRecoilState(dataforupdatefillplanState);
    const [zonestemp,setZones_temp] = useRecoilState(zonestempState)
    const [reload, setReload ] = useRecoilState(reloadState)

    


    const updateFormData = async () => {
        console.log('Current zones_temp:', zonestemp);
        try {
      
          let combined_productmap = [];
          console.log('updateFormData:',multiclickedZone_Info)
          const combinedArray = Object.values(multiclickedZone_Info)  // Extracting mapData arrays
          .map(mapData => Object.values(mapData))   // Extracting levelData arrays
          .flat()                                  // Flatten levelData arrays
          .map(levelData => Object.values(levelData)) // Extracting sub_col arrays
          .flat()                                  // Flatten sub_col arrays
          .filter(element => element.is_used === true); // Filtering by is_used

      
          
          if (productSelected.length !== combinedArray.length) {
            const diff = Math.abs(productSelected.length - combinedArray.length);
            const message = productSelected.length > combinedArray.length 
              ? `ขาดอีก ${diff}`
              : `เกินมา ${diff}`;
        
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: `กรุณาเลือกพื้นที่ให้เท่ากับจำนวนpallet! (${message})`,
            });
            return;
          }
      
      
          const specialCombined = [];
          const specialProduct = [];
          const leftCombined = [];
          const leftProduct = [];
          const condition_loop = productSelected.some(product => product?.pcsperpallet !== product?.qty);
          
          if (condition_loop) {
      
            for (let i = 0; i < productSelected.length; i++) {
              if (combinedArray[i]?.fraction) {
                  if (productSelected[i]?.pcsperpallet !== productSelected[i]?.qty) {
                      combined_productmap.push(Object.assign({}, productSelected[i], combinedArray[i]));
                      console.log(i, 'first_condition');
                  } else {
                      specialCombined.push(combinedArray[i]);
                      leftProduct.push(productSelected[i]);
                      console.log(i, 'second_condition');
         
                  }
              } else if (productSelected[i]?.pcsperpallet !== productSelected[i]?.qty) {
                  if (specialCombined.length > 0) {
                      specialProduct.push(productSelected[i]);
                      leftCombined.push(combinedArray[i]);
                      console.log(i, specialCombined[0], specialProduct[0], leftCombined[0], leftProduct[0], 'third_condition');
                  } else {
                      combined_productmap.push(Object.assign({}, productSelected[i], combinedArray[i]));
                  }
              } else {
                  combined_productmap.push(Object.assign({}, productSelected[i], combinedArray[i]));
              }
          }
      
          } else {
      
            for (let i = 0; i < productSelected.length; i++) {
              combined_productmap.push(Object.assign({}, productSelected[i], combinedArray[i]));
          }
          }

          // จับคู่ข้อมูลเฉพาะข้อมูลที่ยังไม่ได้รวม
          while (specialCombined.length > 0 && specialProduct.length > 0) {
            combined_productmap.push(Object.assign({}, specialProduct.shift(),specialCombined.shift()));
            console.log(combined_productmap,'while_1')
          }
          
          while (leftCombined.length > 0 && leftProduct.length > 0) {
            combined_productmap.push(Object.assign({},  leftProduct.shift(),leftCombined.shift()));
                console.log(combined_productmap, 'while_2')
            }

            const groupedData = combined_productmap.reduce((result, item) => {
            const { machine, zca_on, receive_date, receive_shift } = item;

                if (!result[receive_date]) {
                    result[receive_date] = {};
                }
                if (!result[receive_date][receive_shift]) {
                    result[receive_date][receive_shift] = {};
                }
                if (!result[receive_date][receive_shift][machine]) {
                    result[receive_date][receive_shift][machine] = {};
                }
                if (!result[receive_date][receive_shift][machine][zca_on]) {
                    result[receive_date][receive_shift][machine][zca_on] = [];
                }

                result[receive_date][receive_shift][machine][zca_on].push(item);
                return result;
            }, {});

            const updatedDataForUpdateFillPlan = _.merge(groupedData, dataforupdatefillplan);


            setdataforupdatefillplan(updatedDataForUpdateFillPlan);


                
          toast({
            title: 'Update Successfully',
            description: `The area has been successfully reserved. Please wait for further confirmation to validate the information.`,
            status: 'success',
            duration: 5000,
            isClosable: true,
            position: 'bottom-right'
          });
      
          setmultiClickedZone_Info({})
          setTagClicked(null)

          setZones_temp((oldZones) => [...oldZones, ...combined_productmap]);
          setReload(!reload)


          return true;

      
        } catch (error) {
          console.error('An error occurred:', error);
        }
      
      
      };
    
  const maxLevel = tagClicked?.max_level || hoveredTag?.zone?.max_level || 5;
  const levelsArray = Array.from({ length: maxLevel }, (_, i) => maxLevel - i);
  const sub_col = tagClicked?.sub_column || hoveredTag?.zone?.sub_column || 1;

  const handleCancelClick = () => {

    setmultiClickedZone_Info([]);
    setTagClicked(null)

    
  };


  const handleTagClose = (event,zoneToRemove) => {
    event.stopPropagation();

    console.log(zoneToRemove,'zoneToRemove')
    setHoveredTag(null)
    setCheckedLevels(null)
    setmultiClickedZone_Info(prevClickedZones => {
      const newZones = { ...prevClickedZones };
      delete newZones[zoneToRemove];
      console.log("New multiclickedZone_Info:", newZones); // Debugging line
      return newZones;
    });




    if (tagClicked?.mapid === zoneToRemove) {
      setTagClicked(null)
    }
  };


  const handleRadioChange = (combinedValue) => {
    const [selectedLevel, selectedSubColumn] = combinedValue.split('-');

    // Update multiclickedZone_Info by removing old fraction and adding the new one
    setmultiClickedZone_Info(prevState => {
        // Create a shallow copy of the current state
        const updatedState = cloneDeep(prevState);

        // Remove fraction from every level and sub_column
        Object.keys(updatedState).forEach(mapid => {
            Object.keys(updatedState[mapid] || {}).forEach(level => {
                Object.keys(updatedState[mapid][level] || {}).forEach(sub_column => {
                    if (updatedState[mapid][level][sub_column]?.fraction) {
                        updatedState[mapid][level][sub_column] = Object.fromEntries(
                            Object.entries(updatedState[mapid][level][sub_column]).filter(([key]) => key !== 'fraction')
                        );
                    }
                });
            });
        });

        // Add the new fraction for the selected level and sub_column
        const mapid = tagClicked?.mapid;
        if (mapid && updatedState[mapid]) {
            const updatedMapId = {
                ...updatedState[mapid],
                [selectedLevel]: {
                    ...(updatedState[mapid][selectedLevel] || {}),
                    [selectedSubColumn]: {
                        ...(updatedState[mapid][selectedLevel]?.[selectedSubColumn] || {}),
                        fraction: true
                    }
                }
            };
            return { ...updatedState, [mapid]: updatedMapId };
        }
        return updatedState;
        
    });
};
    
    const handleHoverTag = (mapid) => {

        let matchingZone = zones.find((zone) => zone.mapid === mapid);

        if (matchingZone) {
            return setHoveredTag({ zone: matchingZone });
        }
        return
    };


  const handleEditLevels = () => {
    // Deep copy the object
    const newMulti_info = JSON.parse(JSON.stringify(multiclickedZone_Info));
  
    // Loop through each mapid in the object
    Object.keys(newMulti_info).forEach((mapid) => {
      const zone = newMulti_info[mapid];
  
      // Check if the mapid of the zone matches the one you want to update
      if (mapid === tagClicked?.mapid) {
        // Loop through each level in the zone
        Object.keys(zone).forEach((level) => {
          Object.keys(zone[level]).forEach((sub_col) => {

            const sub_colInfo = zone[level][sub_col]
            console.log(sub_colInfo,'sub_colInfo')
            // Only proceed if is_used is true
   
              // Check if the checkbox for this level is selected
              const isSelected = checkedLevels[level][sub_col];
    
              // Update the product information for this level
              if (isSelected === false) {
                // Set is_used to false instead of deleting
                sub_colInfo.is_used = false;
              }
              else {
                sub_colInfo.is_used = true;
              }
       

          })
      
        });
      }
  

      if (Object.keys(zone).length === 0 && zone.constructor === Object) {
        delete newMulti_info[mapid];
      }
    });
  
    setmultiClickedZone_Info(newMulti_info);
    setTagClicked(null)
    setCheckedLevels(null)

  };

  useEffect(() => {
    const isZoneExist = zones && zones.some(data => Object.keys(multiclickedZone_Info).includes(data.mapid));
    
    if (!isZoneExist) setTagClicked(null);
}, [multiclickedZone_Info, zones, setTagClicked]);


  
  const handleTagCancel = () => {
    setTagClicked(null)
    setCheckedLevels(null)
  }

    const findSize = ( targetMapid) => {
        const targetZone = zones.find(zone => zone.mapid === targetMapid);
        return targetZone ? targetZone.size : null;
    };
    const findMaxLevel = ( targetMapid) => {
        const targetZone = zones.find(zone => zone.mapid === targetMapid);
        return targetZone ? targetZone.max_level : null;
    };
    const findSubCol = ( targetMapid) => {
      const targetZone = zones.find(zone => zone.mapid === targetMapid);
      return targetZone ? targetZone.sub_column : null;
    };
    
    const handleTagClick = (zone, mapid) => {
        const max_level = findMaxLevel(mapid)
        const sub_column = findSubCol(mapid)

        // กรณีที่คลิกแท็กที่ถูกเลือกแล้ว
        if (tagClicked?.mapid === mapid) {
            setTagClicked(null);

            const updatedCheckedLevels = {};
            for (let level = 1; level <= max_level; level++) {
                updatedCheckedLevels[level] = {}; // ต้องเป็น object
                for (let sub_col = 1; sub_col <= sub_column; sub_col++) {
                    updatedCheckedLevels[level][sub_col] = false; // set ค่าเป็น false สำหรับทุก checkbox
                }
            }

            setCheckedLevels(updatedCheckedLevels);

            // กรณีคลิกแท็กใหม่
        } else {
            const find_zone = zones.find(zone => zone.mapid === mapid)
            const attr_zone = { column: find_zone?.column, row: find_zone?.row, size: find_zone?.size }
            const sub_column = find_zone.sub_column
            const updatedCheckedLevels = {};
            const zone_info = multiclickedZone_Info[mapid];

            if (!zone_info) {
                // Handle the case where the zone isn't found, if needed.
                console.error("Zone not found!");
                return;
            }

            setTagClicked({ zone:find_zone, mapid, attr_zone, max_level, sub_column });

            for (let level = 1; level <= max_level; level++) {
                updatedCheckedLevels[level] = {};
                for (let sub_col = 1; sub_col <= sub_column; sub_col++) {

                    if (zone_info && zone_info[level] && zone_info[level][sub_col]) {
                        updatedCheckedLevels[level][sub_col] = Boolean(zone_info[level][sub_col].is_used);
                    } else {
                        updatedCheckedLevels[level][sub_col] = false;
                    }
                }
            }


            setCheckedLevels(updatedCheckedLevels);
        }



    };

    function handleCheckboxChange(level, sub_col_number, e) {
        const isChecked = e.target.checked;
    
        const isCheckboxDisabled = (lvl, sub_col) => {
            return !tagClicked || multiclickedZone_Info?.[tagClicked?.mapid]?.[lvl]?.[sub_col] === undefined;
        }
    
        // ถ้า checkbox ถูกเลือก
        if (isChecked) {
            // ตั้งค่าให้ทุกชั้นที่อยู่ด้านล่างถูกเลือกด้วย
            for (let i = level; i >= 1 ; i--) {
                if (!isCheckboxDisabled(i, sub_col_number)) {
                    setCheckedLevels(prev => ({
                        ...prev,
                        [i]: {
                            ...prev[i],
                            [sub_col_number]: true
                        }
                    }));
                }
            }
        } else {
            // ถ้า checkbox ไม่ถูกเลือก
            // ตั้งค่าให้ทุกชั้นที่อยู่ด้านบนไม่ถูกเลือก
            for (let i = level; i <= maxLevel; i++) {
                if (!isCheckboxDisabled(i, sub_col_number)) {
                    setCheckedLevels(prev => ({
                        ...prev,
                        [i]: {
                            ...prev[i],
                            [sub_col_number]: false
                        }
                    }));
                }
            }
        }
    }
    
    
    

    //////////////////////////// Color Visualize ////////////////////////////////
    const [inputData, setInputData] = useState({});
    const zca_onColors = [ "#F99417", "#4D4C7D", "#125B50","#DD4A48", "#79B4B7"]; //"#F99417", "#4D4C7D", "#125B50",
    const [colorMapping, setColorMapping] = useState({});
    const [productSidview, setProductSideview] = useState ({});

    const colorIcons = Object.keys(colorMapping).map((key) => 
    key !== '-' ? (
        <>
        <HStack p='0.5'>
        <svg key={key} width="24" height="24" style={{ marginRight: '10px', fill: colorMapping[key].color || 'transparent' }}>
            <rect width="24" height="24" />
        </svg>
        <Text fontSize="14" >{colorMapping[key].name_th}</Text>
        </HStack>
        </>

    ) : null
);

    
    
    useEffect(() => {
        let uniqueZca_onData = {};

        levelsArray.forEach((level) => {
            Array.from({ length: sub_col }).forEach((_, idx) => {
                const sub_col_number = idx + 1;
                const zca_onValue = 
                    (tagClicked?.zone?.levels?.[level]?.sub_column?.[sub_col_number]?.data?.zca_on) ||
                    (hoveredTag?.zone?.levels?.[level]?.sub_column?.[sub_col_number]?.data?.zca_on) ||
                    '-';
                const name_thValue = 
                    (tagClicked?.zone?.levels?.[level]?.sub_column?.[sub_col_number]?.data?.name_th) ||
                    (hoveredTag?.zone?.levels?.[level]?.sub_column?.[sub_col_number]?.data?.name_th) ||
                    '-';

                if (zca_onValue !== '-') {
                    uniqueZca_onData[zca_onValue] = name_thValue;
                }
                else if (zca_onValue == '-') {
                    uniqueZca_onData[zca_onValue] = '-';
                }
            });
        });
        
        let colorIndex = 0;
        const newColorMapping = Object.keys(uniqueZca_onData).reduce((acc, zca_on) => {
            if (zca_on !== '-') {
                acc[zca_on] = {
                    color: zca_onColors[colorIndex % zca_onColors.length],
                    name_th: uniqueZca_onData[zca_on]
                };
                colorIndex++;
            } else {
                acc[zca_on] = {
                    color: 'transparent',
                    name_th: '-'
                };
            }
            return acc;
        }, {});
        
        
    
        setColorMapping(newColorMapping);
    

    }, [tagClicked, hoveredTag]);

    
    
  
    
    return (
            <>


                <Box  flex="1" >
                    <form >

                        <Heading size='md' > Selected Zone </Heading>
                        <Divider color={'gray'} m='1' />



                        <VStack

                            spacing={2}
                            align='stretch'
                        >



                            <Box >
                                <Text fontSize='md' > Bin-locations</Text>
                                <Box p='4' w='100%' minH='10vh' border='1px solid lightgray' borderRadius={5}>
                                    <SimpleGrid columns={{ base: "1", md: "2", lg: '2', xl: '3', '2xl': '3' }} spacing={1}>
                                    
                                        
                                        { multiclickedZone_Info ?  Object.keys(multiclickedZone_Info).map((mapid) => {
                                            const zone = multiclickedZone_Info[mapid];
                                            const isZoneExist = zones && zones.some(data => data.mapid === mapid);
                                            return (
                                                <Box key={mapid}>
                                                    <Tag
                                                        size='sm'
                                                        borderRadius='full'
                                                        variant={tagClicked?.mapid === mapid ? 'outline' : (hoveredTag?.zone.mapid === mapid ? 'ghost' : 'solid')}
                                                        colorScheme={isZoneExist ? 'green' : 'gray'}
                                                        onClick={() => isZoneExist && handleTagClick(zone, mapid)}
                                                        onMouseEnter={() => isZoneExist && handleHoverTag( mapid)}
                                                        onMouseLeave={() => setHoveredTag(null)}
                                                        cursor={isZoneExist ? 'pointer' : 'not-allowed'}
                                                        isDisabled={!isZoneExist}
                                                    >
                                                        <TagLabel>{zone.name || mapid}</TagLabel>
                                                        {isZoneExist && <TagCloseButton onClick={(event) => handleTagClose(event, mapid)} />}
                                                    </Tag>
                                                </Box>
                                            );
                                        }) : null }

                                    </SimpleGrid>
                                </Box>
                            </Box>



                        </VStack>





                        <Divider />


                        {productSelected ? (
                            <Box justifyContent='center' p='2'>
                                <ButtonGroup spacing='2'>
                                    <Button variant='solid' colorScheme='blue' onClick={updateFormData} isDisabled={!multiclickedZone_Info || Object.keys(multiclickedZone_Info).length === 0}  >
                                        Save
                                    </Button>
                                    <Button variant='ghost' colorScheme='blue' onClick={handleCancelClick} isDisabled={!multiclickedZone_Info || Object.keys(multiclickedZone_Info).length === 0}>
                                        Cancel
                                    </Button>
                                </ButtonGroup>
                            </Box>) : (

                            <ButtonGroup spacing='2'>

                            </ButtonGroup>

                        )}




                    </form>
                </Box>



                {/* <Box bg='white' boxShadow='base' p='6' rounded='md' flex="1" overflowY='auto' > */}
            <Box bg='white' flex="1" overflowY='auto' minH='45vh' overflowX='hidden' pt='4' >
          
                <Divider color={'gray'} m='1' />
                <VStack
                    divider={<StackDivider borderColor='gray.200' />}
                    spacing={1}
                    align='stretch'
                >
                    <FormControl>
                        <HStack justify="center" align="center" w="full">

                            <HStack justify="center" align="center" spacing={5} w="full">
                                <Text> Column </Text>
                                <Text color='red'>
                                    {

                                        (tagClicked?.attr_zone?.column) ||
                                        (hoveredTag?.zone?.column) ||
                                        '-'
                                    }
                                </Text>
                            </HStack>


                            <HStack justify="center" align="center" spacing={5} w="full">
                                <Text> Row </Text>
                                <Text color='red'>
                                    {

                                        (tagClicked?.attr_zone?.row) ||
                                        (hoveredTag?.zone?.row) ||
                                        '-'
                                    }
                                </Text>
                            </HStack>

                            <HStack justify="center" align="center" spacing={5} w="full">
                                <Text> Size </Text>
                                <Text color='red'>
                                    {

                                        (tagClicked?.attr_zone?.size) ||
                                        (hoveredTag?.zone?.size) ||
                                        '-'
                                    }
                                </Text>
                            </HStack>

                        </HStack>


                    </FormControl>
                    <Box w='100%'>
                        <RadioGroup onChange={handleRadioChange} value={selectedRadio}> {/* ใช้ handleRadioChange เพื่อรับค่าเมื่อ radio เปลี่ยน */}
                            {levelsArray.map((level) => (
                                <HStack key={level} textAlign="center">
                                    <Box flex="1" minW='45px'> 
                                        <Text fontSize="md" whiteSpace="nowrap" color="blue.500">{`Level ${level}`}</Text>
                                    </Box>
                                    <Box display="flex" flexDirection="row" flexWrap="wrap" flex="4">
                                        {Array.from({ length: sub_col }).map((_, idx) => {
                                            const sub_col_number = idx + 1;
                                            const zca_onValue = 
                                            (tagClicked?.zone?.levels?.[level]?.sub_column?.[sub_col_number]?.data?.zca_on) ||
                                            (hoveredTag?.zone?.levels?.[level]?.sub_column?.[sub_col_number]?.data?.zca_on) ||
                                            '-';



                                             // this will give 1 for the first sub-column, 2 for the second, etc.
                                            return (
                                                <React.Fragment key={idx}>
                                                    <Box flex="8">
                                                    {
                                                        colorMapping[zca_onValue] ? (
                                                        <Input
                                                            size="sm"
                                                            name={level}
                                                            backgroundColor={
                                                                zca_onValue === '-'
                                                                    ? "gray.300"
                                                                    : colorMapping[zca_onValue].color || "gray.300"
                                                            }
                                                            color="white"
                                                            value={
                                                                (tagClicked?.zone?.levels?.[level]?.sub_column?.[sub_col_number]?.data?.zca_on) ||
                                                                (hoveredTag?.zone?.levels?.[level]?.sub_column?.[sub_col_number]?.data?.zca_on) ||
                                                                '-'
                                                            }
                                                            readOnly
                                                        />
                                                        ) : (
                                                            <Spinner /> // แสดง Spinner เมื่อรอข้อมูล
                                                        )
                                                    }
                                                    </Box>
                                                    <Box display="flex"
                                                        alignItems="center"
                                                        justifyContent="center"
                                                        flex="1"
                                                        p='1'  >
                                                        <Checkbox
                                                            name={`${level}-${sub_col_number}`}
                                                            isChecked={multiclickedZone_Info?.[hoveredTag?.zone?.mapid]?.[level]?.[sub_col_number]?.is_used === true||checkedLevels?.[level]?.[sub_col_number] || false}
                                                            isDisabled={!tagClicked || multiclickedZone_Info?.[tagClicked?.mapid]?.[level]?.[sub_col_number] === undefined}
                                                            onChange={(e) => handleCheckboxChange(level, sub_col_number, e)}
                                                        />
                                                    </Box>
                                                    <Box display="flex"
                                                        alignItems="center"
                                                        justifyContent="center"
                                                        flex="1"
                                                        p='1'
                                                        mr='1'  >
                                                        <Radio
                                                            isDisabled={!tagClicked || !checkedLevels?.[level]?.[sub_col_number]}
                                                            value={`${level}-${sub_col_number}`}
                                                            isChecked={
                                                                multiclickedZone_Info?.[tagClicked?.mapid]?.[level]?.[sub_col_number]?.fraction === true ||
                                                                multiclickedZone_Info?.[hoveredTag?.zone?.mapid]?.[level]?.[sub_col_number]?.fraction === true
                                                            }
                                                        />
                                                    </Box>
                                                </React.Fragment>
                                            );
                                        })}
                                    </Box>
                                </HStack>
                            ))}

                        </RadioGroup>
                    </Box>
                    <Box minH={20}>
                        {
                            Object.keys(colorMapping).some(key =>  colorMapping[key].color) ? (
                                <Box p='1' pl='3'>
                                    {colorIcons}
                                </Box>
                            ) : (<Spinner />)
                        }

                    </Box>

                    {tagClicked && (
                        
                    <ButtonGroup spacing='2' mt ='2'>

    <Button variant='solid' colorScheme='blue' onClick={handleEditLevels}>
      Save Change
    </Button>


    <Button variant='ghost' colorScheme='blue' onClick={handleTagCancel}>
      Cancel
    </Button>

</ButtonGroup>

)}
                   

                </VStack>

            </Box>



            </>

    );
  }

  export default React.memo(ZoneTags);
  