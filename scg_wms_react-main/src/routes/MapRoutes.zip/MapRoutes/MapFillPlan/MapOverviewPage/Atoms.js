// atoms.js
import { atom } from 'recoil';

export const counterState = atom({
  key: 'counterState', // unique ID
  default: 0, // default value
});


export const hoveredZoneState = atom({
  key: 'hoveredZoneState',
  default: ''
});

export const clickedZoneState = atom({
  key: 'clickedZoneState',
  default: ''
});

export const payloadState = atom ({
  key: 'payloadState',
  default: ''
})

export const reloadState = atom({
  key: 'reloadState', // unique ID (with respect to other atoms/selectors)
  default: false,     // default value
});

export const rerenderState = atom({
  key: 'reloadState', // unique ID (with respect to other atoms/selectors)
  default: false,     // default value
});

export const zonesState = atom({
  key: 'zonesState',
  default: ''
});

export const selectedlocationState = atom({
  key:'selectedlocationState',
  default:''
})

export const productListState = atom({
  key: 'productListState',
  default: []
});

export const zoneSelectedState = atom({
  key: 'zoneSelectedState',
  default: []
})




/////////////////// DATA FROM MABEAM ///////////////////

export const get_fillplanState = atom({
  key: 'get_fillplanState',
  default: ''
});

////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////



export const default_dataforupdatefillplanState = atom({
  key: 'default_dataforupdatefillplanState',
  default: ''
})


export const MapfilterState = atom({
  key: 'MapfilterState',
  default: [], // This will be an array of map_ids
});

export const SwitchedState = atom({
  key: 'SwitchedState',
  default: false, // This will be an array of map_ids
});

export const zonesAtom = atom({
  key: 'zonesAtom',
  default: []
})



export const productSelectedState = atom({
  key: 'productSelectedState',
  default: null
});


export const dataforupdatefillplanState = atom({
  key: 'dataforupdatefillplanState',
  default: ''
})


export const multiclickedZone_Info = atom({
  key: 'multiclickedZone_Info',
  default: []
})

export const tagClickedState = atom({
  key: 'tagClickedState',
  default: []
})

export const zonestempState = atom({
key: 'zonestempState',
default: []
})


