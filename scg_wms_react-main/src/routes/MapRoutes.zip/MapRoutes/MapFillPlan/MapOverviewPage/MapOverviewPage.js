import React, { useState,useTransition,useEffect,lazy, Suspense,useCallback } from 'react';
import { Tooltip, 
  useToast, 
  Box,
  Collapse,
  Highlight,
  Badge,
  HStack, 
  Text, 
  Flex,
  Spacer,
  Container, 
  VStack, 

  useDisclosure } from "@chakra-ui/react";
import { Tabs, TabList, TabPanels, Tab, TabPanel } from '@chakra-ui/react'
import { Grid, Button, Input,ButtonGroup, GridItem,Heading,Divider,CardFooter } from '@chakra-ui/react'

import { useRecoilState } from 'recoil';
import { useRecoilValue } from 'recoil';
import {AiOutlineInfoCircle,AiFillEdit} from 'react-icons/ai'


import ZoneTags from '../MapSelectPage/MapEditorPage.js';
import {useZoneComparison, countAllMembers} from '../../Hooks/CustomHooks.js'
import FilterMenu from '../../MapWarehouse/MapSearch.js';
import {productSelectedState,dataforupdatefillplanState,reloadState,rerenderState,
  multiclickedZone_Info as multiclickedZoneInfoAtom, zonestempState,
  zonesAtom,tagClickedState

} from './Atoms.js';


import WarehouseDisplay from '../../MapWarehouse/MainDisPlay.js';

import { Circle  } from '@chakra-ui/react';
import { MdForklift } from "react-icons/md";

import { Skeleton } from '@chakra-ui/react';
import Swal from 'sweetalert2'

import Axios from 'axios';
Axios.defaults.xsrfCookieName = 'csrftoken';
Axios.defaults.xsrfHeaderName = 'X-CSRFToken';
Axios.defaults.withCredentials = true;

const client = Axios.create({
    baseURL: `${process.env.REACT_APP_API_URL}`
});


const DrawerExample = lazy(() => import('./Drawer.jsx'));




const MapComponent = ( ) => {

  const [zones_temp,setZones_temp] = useRecoilState(zonestempState)

  const [productSelected, setProductSelected] = useRecoilState(productSelectedState);
  const [multiclickedZone_Info , setmultiClickedZone_Info] = useRecoilState(multiclickedZoneInfoAtom)
  const [dataforupdatefillplan,setdataforupdatefillplan] = useRecoilState(dataforupdatefillplanState);
  const [hoveredZone, setHoveredZone] = useState(null);
  const { compareZoneLevels } = useZoneComparison();
  const toast = useToast();
  const [isPending, startTransition] = useTransition();
  const [clickedZone, setClickedZone] = useState(null);
  const { isOpen, onOpen, onClose } = useDisclosure()
  const btnRef = React.useRef()
  const [fillplan,setFillPlan] = useState(null)

  const resetToDefaultState = () => {
    setProductSelected(null)
    setZones_temp([])
    setmultiClickedZone_Info([])
    setdataforupdatefillplan('')

  }

  const get_fillplanlist = async (action) => {
    let queryString = '';
    if (action === true) {
        queryString = 'success=true';
    } else {
      queryString = 'success=false'
    }

    try {
        const { data } = await client.get(`/wms/api/get_fillplan/?${queryString}`);
        
        return data;
    } catch (error) {
        console.error('Error fetching data: ', error);
    }
};

useEffect(() => {
  const fetchFillPlan = async () => {
    try {
      const fillplan = await get_fillplanlist(false);
      setFillPlan(fillplan);
    } catch (error) {
      console.error('Error fetching fill plan:', error);
    }
  };

  fetchFillPlan();
}, []);

  



  const isMapIdCompleted = (machine, zca_on, receive_date, receive_shift, dataForUpdateFillPlan) => {
    const machineData = dataForUpdateFillPlan?.[receive_date]?.[receive_shift]?.[machine]?.[zca_on];
    return machineData && machineData.some(item => item.receive_date === receive_date && item.receive_shift === receive_shift);
  };

  const checkMapIdStatusInDataForUpdateFillPlan = (receive_date, receive_shift, machine, zca_on, dataForUpdateFillPlan) => {
    const zcaOnData = dataForUpdateFillPlan?.[receive_date]?.[receive_shift]?.[machine]?.[zca_on] || [];

    if (zcaOnData.length === 0) {
      return <Badge colorScheme='yellow'>In progress</Badge>;
    }
    return zcaOnData.some(item => item.mapid === null)
      ? <Badge fontSize='0.9em' colorScheme='yellow'>In progress</Badge>
      : <Badge colorScheme='green'>Success</Badge>;
  };


  const isCompleted = isMapIdCompleted(productSelected?.[0]?.machine,
    productSelected?.[0]?.zca_on,
    productSelected?.[0]?.receive_date,
    productSelected?.[0]?.receive_shift,
    dataforupdatefillplan,);



  



  const updateExistingMClickedZone = (
    dataforupdatefillplan,
    receive_date,
    receive_shift,
    machine,
    zca,
    zones_temp,
    setmultiClickedZone_Info 
  ) => {

    const machineData = dataforupdatefillplan?.[receive_date]?.[receive_shift]?.[machine]?.[zca];

    if (!machineData) {
      console.error(`The machine '${machine}' or ZCA '${zca}' does not exist in the provided data.`);
      return {};
    }

    const newMulticlickedZoneInfo = {};

    Object.values(machineData).forEach(data => {
      const { column, row, mapid, level, warehouse, zone, sub_column,fraction } = data;

      if (!newMulticlickedZoneInfo[mapid]) {
        newMulticlickedZoneInfo[mapid] = {};
      }

      if (!newMulticlickedZoneInfo[mapid][level]) {
        newMulticlickedZoneInfo[mapid][level] = {};
      }

      // กำหนดข้อมูลให้กับ sub_column
      newMulticlickedZoneInfo[mapid][level][sub_column] = {
        column,
        row,
        mapid,
        level,
        warehouse,
        zone,
        sub_column,
        is_used: true, // ตามที่คุณระบุไว้
        ...(fraction !== undefined && { fraction })
      };
    });
    
  
    return newMulticlickedZoneInfo;
  };


  const updateDataAndZonesTemp = (receive_date, receive_shift, machine, zca, dataforupdatefillplan, zones_temp) => {
    const updatedData = JSON.parse(JSON.stringify(dataforupdatefillplan));
    if (updatedData[receive_date] && 
      updatedData[receive_date][receive_shift] && 
      updatedData[receive_date][receive_shift][machine] && 
      updatedData[receive_date][receive_shift][machine][zca]) 
      {
      const shouldDelete = updatedData[receive_date][receive_shift][machine][zca]
      if (shouldDelete) {
        delete updatedData[receive_date][receive_shift][machine][zca];
      }
      if (Object.keys(updatedData[receive_date][receive_shift][machine]).length === 0) {
        delete updatedData[receive_date][receive_shift][machine];

        if (Object.keys(updatedData[receive_date][receive_shift]).length === 0) {
          delete updatedData[receive_date][receive_shift];

          if (Object.keys(updatedData[receive_date]).length === 0) {
            delete updatedData[receive_date];
          }
        }
      }
    }
  
    const newData = Object.values(updatedData)
      .flatMap(date => Object.values(date).flatMap(shift => Object.values(shift).flatMap(machine => Object.values(machine).flat())));
  
    const oldData = Object.values(dataforupdatefillplan)
      .flatMap(date => Object.values(date).flatMap(shift => Object.values(shift).flatMap(machine => Object.values(machine).flat())));
  
    const uniqueUpdatedData = oldData.filter(updated =>
      !newData.some(data =>
        data.id === updated.id && data.mapid === updated.mapid && data.receive_date === updated.receive_date && data.receive_shift === updated.receive_shift
      )
    );
  
    const updatedZonesTemp = zones_temp.filter(z => !uniqueUpdatedData.some(updated => z.id === updated.id));
    
  
    return { updatedData, updatedZonesTemp };
  };
  

  

  const handleEditAndClearLocation = (receive_date,receive_shift,machine, zca,action) => {

    if (
        dataforupdatefillplan &&
        dataforupdatefillplan[receive_date] &&
        dataforupdatefillplan[receive_date][receive_shift] &&
        dataforupdatefillplan[receive_date][receive_shift][machine] &&
        dataforupdatefillplan[receive_date][receive_shift][machine][zca]
    ) {
    
          if( action === 'clear' ){
            Swal.fire({
              title: 'ยืนยันการ Clear locations?',
              icon: 'warning',
              text: 'หาก clear loactions แมพที่เลือกไว้ของ product นี้จะถูกรีเซ็ต',
              showCancelButton: true,
              cancelButtonText: 'ยกเลิก',
              confirmButtonText: 'ตกลง',
              confirmButtonColor: '#E51212',
        
            }).then((result) => {
              if (result.isConfirmed) {


            const { updatedData, updatedZonesTemp } = updateDataAndZonesTemp(
                                                    receive_date,
                                                    receive_shift,
                                                    machine,
                                                    zca,
                                                    dataforupdatefillplan,
                                                    zones_temp
                                                    );


            const problemDetails = compareZoneLevels(zones_temp, updatedZonesTemp);

            if (problemDetails.length > 0) {

            const formatProblemDetailsToString = (problemDetails) => {
              return problemDetails.map(detail => 
                `Column: ${detail.column}, Row: ${detail.row}, Level: ${detail.level}`
              ).join('\n');
            };
            
            const problemDetailsStr = formatProblemDetailsToString(problemDetails);
            
           
              Swal.fire({
                title: 'ไม่สามารถแก้ไขหรือลบโซนนี้ได้',
                icon: 'error',
                html: `เนื่องจาก level ที่สูงกว่ายังคงมีข้อมูลอยู่ กรุณายกเลิกการวางของ level นั้นก่อน!<br><br>ข้อผิดพลาดที่พบ:<br>${problemDetailsStr.replace(/\n/g, '<br>')}`,
                confirmButtonText: 'ปิด'
              });
              return;
            }

        
                setdataforupdatefillplan(updatedData);
                setZones_temp(updatedZonesTemp);
                setReload(!reload); 
  

            return toast({
              title: 'locations ถูกรีเซ็ตเรียบร้อย',
              description: `กรุณาเลือกพื้นที่ของ product ชนิดนี้ใหม่`,
              status: 'success',
              duration: 5000,
              isClosable: true,
              position: 'bottom-right'
            });
          }
          })  
          } else if (action === 'edit'){


            const { updatedData, updatedZonesTemp } = updateDataAndZonesTemp(
              receive_date,
              receive_shift,
              machine,
              zca,
              dataforupdatefillplan,
              zones_temp
            );

            const problemDetails = compareZoneLevels(zones_temp, updatedZonesTemp);

            if (problemDetails.length > 0) {

            const formatProblemDetailsToString = (problemDetails) => {
              return problemDetails.map(detail => 
                `Column: ${detail.column}, Row: ${detail.row}, Level: ${detail.level}`
              ).join('\n');
            };
            
            const problemDetailsStr = formatProblemDetailsToString(problemDetails);
            
           
              Swal.fire({
                title: 'ไม่สามารถแก้ไขหรือลบโซนนี้ได้',
                icon: 'error',
                html: `เนื่องจาก level ที่สูงกว่ายังคงมีข้อมูลอยู่ กรุณายกเลิกการวางของ level นั้นก่อน!<br><br>ข้อผิดพลาดที่พบ:<br>${problemDetailsStr.replace(/\n/g, '<br>')}`,
                confirmButtonText: 'ปิด'
              });
              return;
            }
            
         
            let newMulticlickedZoneInfo = updateExistingMClickedZone(dataforupdatefillplan,receive_date,receive_shift, machine, zca, zones_temp, setmultiClickedZone_Info)
            setmultiClickedZone_Info(newMulticlickedZoneInfo);
            setdataforupdatefillplan(updatedData);
            setZones_temp(updatedZonesTemp);
            setReload(!reload);
      

            return

          } else {

          toast({
            title: 'ERROR',
            description: `action ไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง`,
            status: 'error',
            duration: 5000,
            isClosable: true,
            position: 'bottom-right'
          });

          }

  
    } else {
        console.warn(`Data not available for machine: ${machine} and zca: ${zca}`);
    }
};

  
  const handleUnProductSelect = (product) => {
    setProductSelected(null);
    setmultiClickedZone_Info({})
  };

  //success
  const handleProductSelect = (product) => {
    setProductSelected(product);
    setmultiClickedZone_Info({})

    onClose();  
  };
  

  const WARNING_TITLE = "Warning";
  const WARNING_DURATION = 5000;
  const WARNING_STATUS = "warning";
  const ERROR_STATUS = "error";

useEffect(() => {
console.log(multiclickedZone_Info,'multiclickedZone_Info')
}, [multiclickedZone_Info])



  const ClickFillPlan = useCallback((zone,productSelected,multiclickedZone_Info,tagClicked,setTagClicked) => {
    console.log('click2',zone)
    const poductCheckState = () => {
        let receive_date = productSelected?.[0]?.receive_date
        let receive_shift = productSelected?.[0]?.receive_shift
        let machine = productSelected?.[0]?.machine
        let zca = productSelected?.[0]?.zca_on
        if (
          dataforupdatefillplan &&
          dataforupdatefillplan[receive_date] &&
          dataforupdatefillplan[receive_date][receive_shift] &&
          dataforupdatefillplan[receive_date][receive_shift][machine] &&
          dataforupdatefillplan[receive_date][receive_shift][machine][zca]
        ) {
       
          return true; 
    
        }
        
        return false
    }
    
    let productCheck = poductCheckState()

    if (productCheck) {
      Swal.fire({ title: 'คุณเลือกครบแล้ว', text: 'ไม่สามารถดำเนินการต่อได้', icon: WARNING_STATUS });
      return;
    }
  
    if (!zone) {
      console.warn('Zone is null or undefined');
      return;
    }
  
    if (!multiclickedZone_Info) {
      console.warn('multiclickedZone_Info is null or undefined');
      return;
    }
  

    handleZoneOperations(zone,productSelected,multiclickedZone_Info,tagClicked,setTagClicked);
  
  }, [productSelected, multiclickedZone_Info]);


    function handleZoneOperations(zone,productSelected,multiclickedZone_Info,tagClicked,setTagClicked) {
        
        const zone_mapid = zone.mapid;
        const isAlreadyClicked = Object.keys(multiclickedZone_Info).includes(zone_mapid);
        if (isAlreadyClicked) {
            if(tagClicked?.mapid === zone_mapid) {
                setTagClicked(null)
            }
            setmultiClickedZone_Info(prevClickedZones => {
                if (!prevClickedZones) return {}; // add this line
                const newZones = { ...prevClickedZones };
                delete newZones[zone_mapid];

                return newZones;
            });
        } else {
            if (!zone.levels) {
                console.warn('zone.levels is null or undefined');
                return;
            }

            if (!productSelected || productSelected.length === 0 || productSelected === null) {
                toast({
                    title: "Warning",
                    description: "Pick Product first!!!",
                    status: "error",
                    duration: 5000,
                    isClosable: true,
                });
                return;
            }


            if (productSelected && zone.size * 100 != productSelected?.[0]?.product_length) {
                toast({
                    title: "Warning",
                    description: "Please select the correct product size!",
                    status: "warning",
                    duration: 5000,
                    isClosable: true,
                });
                return;

            }




            const transformData = (zone) => {
                const newRow = {};
                const countmclick = countAllMembers(multiclickedZone_Info);
                let entryCount = 0;
                for (const level of Object.keys(zone.levels)) {

                    for (let i = 1; i <= zone.sub_column; i++) {
                        if (entryCount + countmclick >= productSelected.length) break;

                        if (zone.levels[level].sub_column[i].data) continue;

                        newRow[zone.mapid] = newRow[zone.mapid] || {};
                        newRow[zone.mapid][level] = newRow[zone.mapid][level] || {};

                        newRow[zone.mapid][level][i] = {
                            ...zone.levels[level].sub_column[i].data,
                            level,
                            column: zone.column,
                            row: zone.row,
                            mapid: zone.mapid,
                            warehouse: zone.warehouse_id,
                            zone: zone.zone,
                            sub_column: i,
                            is_used: true,
                        };
                        entryCount++;
                    }
                }

                if (countmclick >= productSelected.length) {
                    toast({
                        title: "Warning",
                        description: "The area for the pallet is now full.",
                        status: "warning",
                        duration: 5000,
                        isClosable: true,
                    });
                }
                else if (Object.keys(newRow).length === 0) {
                    toast({
                        title: "Warning",
                        description: "This area is full.",
                        status: "warning",
                        duration: 5000,
                        isClosable: true,
                    });
                }



                return newRow;
            };



            setmultiClickedZone_Info(prevClickedZones => {
                if (!prevClickedZones) return {};

                return { ...prevClickedZones, ...transformData(zone) };
            });

        }
    }



  const [reload, setReload] = useRecoilState(reloadState);
  const [rerender, setReRender] = useRecoilState(rerenderState);
  const { isOpen: openSearch, onToggle: toggleSearch } = useDisclosure();
  const [countPallet , setCountPallet ] = useState(null);

  useEffect(() => {
    const count = countAllMembers(multiclickedZone_Info)
    setCountPallet(count);
  }, [multiclickedZone_Info]);
  
  
  //success
  const isAllSelectedProductsUpdated = (productSelected, dataforupdatefillplan) => {
    if (!productSelected || !dataforupdatefillplan) {
      return false;
    }
  
    const updatedProductIds = new Set();
    Object.values(dataforupdatefillplan).forEach(receiveDate => {
      Object.values(receiveDate).forEach(receiveShift => {
        Object.values(receiveShift).forEach(machine => {
          Object.values(machine).forEach(zcaOnList => {
            zcaOnList.forEach(zcaOn => {
              updatedProductIds.add(zcaOn.id);
            });
          });
        });
      });
    });
  
    return productSelected.every(product => updatedProductIds.has(product.id));
  };


  
  return (
    <Box  >
      <Tabs>
        <TabList>
          <Tab>Manual</Tab>
          <Tab>Suggestion</Tab>

        </TabList>

        <TabPanels>
          <TabPanel>
            <div>
              <Grid
                bg='gray.100'
                templateRows='repeat(2, 1fr)'
                templateColumns='repeat(8, 1fr)'
                gap={4}
           

              >
                <GridItem rowSpan={2} colSpan={6}   >
                  <Flex >
                    {isPending ? (
                      <Skeleton />
                    ) : (

                   <WarehouseDisplay
                   functionClick={ClickFillPlan}
                   reload={reload}
                   />

                    )}
                  </Flex>
                </GridItem>



                <GridItem rowSpan={2} colSpan={2} bg='white' overflow='auto'>
                  <Flex flexDirection='column' p='4' gap='4'  >
                    <Box  bg='white' width='100%' flex='1'       
                        borderRadius='1px'
                        rounded='md'
                        boxShadow='base' 
                        p='5' 


                        >

                   
                        <Heading fontSize='xl'>Select Product</Heading>
                        {productSelected && productSelected.length > 0 ? (
                          !isCompleted ? (
                            <Badge fontSize='0.7em' colorScheme='yellow'>
                              in progress
                            </Badge>
                          ) : (
                            <Badge fontSize='0.7em' colorScheme='green'>
                              Success
                            </Badge>
                          )
                        ) : null}

              

                      <Divider m='1' />

                      <Box maxH='40' overflowY='auto' overflowX='hidden'>
                        {productSelected ? (
                          <VStack
                            spacing={1}>
                            <div className="product-card">
                              <Text fontWeight="bold" >ZCA: </Text> <Text>{productSelected?.[0]?.zca_on}</Text>
                              <Divider m='1' />
                              <Text fontWeight="bold" >Name: </Text> <Text>{productSelected?.[0]?.name_th}</Text>
                              <Divider m='1' />
                              <Text fontWeight="bold">Pallet: </Text>
                              <Text>
                                {
                                  productSelected && typeof productSelected.length === 'number'
                                    ? (
                                      `${productSelected.length} (` +
                                      (isAllSelectedProductsUpdated(productSelected, dataforupdatefillplan)
                                        ? "ครบ"
                                        : productSelected.length - countPallet === 0
                                          ? "ครบ"
                                          : productSelected.length - countPallet < 0
                                            ? `เกินมา ${Math.abs(productSelected.length - countPallet)}`
                                            : `ขาดอีก ${productSelected.length - countPallet}`) +
                                      ` pallet)`
                                    )
                                    : "N/A"
                                }
                              </Text>

                              <Divider m='1' />
                              <Text fontWeight="bold" >Receive Date: </Text> <Text>{productSelected?.[0]?.receive_date}</Text>
                              <Divider m='1' />
                              <Text fontWeight="bold" >Receive Shift: </Text> <Text>{productSelected?.[0]?.receive_shift}</Text>
                              <Divider m='1' />
                              <Text fontWeight="bold" >Machine: </Text> <Text>{productSelected?.[0]?.machine}</Text>
                              <Divider m='1' />

                            </div>

                          </VStack>

                        ) : (
                          <>
                            <Box p='4' boxShadow={'xs'} justifyContent='center'>
                              {/* <Text fontSize='xs'>-- PLEASE SELECT YOUR PRODUCT --</Text> */}
                              <Spacer />
                            </Box>
                          </>)
                        }

                      </Box>


                      <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center">
                        <ButtonGroup mt='5'>
                          <VStack>
                            <Button
                              ref={btnRef}
                              colorScheme='teal'
                              onClick={onOpen}
                              leftIcon={<MdForklift size='1.5em' />}
                              w='100%'>
                              Job List
                            </Button>

                            <Button
                              ref={btnRef}
                              colorScheme='teal'
                              variant='outline'
                              onClick={() => handleEditAndClearLocation(productSelected[0].receive_date, productSelected[0].receive_shift, productSelected[0].machine, productSelected[0]?.zca_on, 'edit')}
                              leftIcon={<AiFillEdit />}
                              w='100%'
                              isDisabled={!isCompleted}>
                              Edit Locations
                            </Button>
                          </VStack>
                        </ButtonGroup>
                      </Box>




                    </Box>


                    <Box  rounded='md'
                        boxShadow='base' 
                        p='5' 
                         bg='white' width='100%' flex='2' >

                      <Box> <ZoneTags Warehouse_id={clickedZone} />  </Box>



                    </Box>
                  </Flex>
                </GridItem>




              </Grid>
            </div>



          </TabPanel>
          <TabPanel>


          </TabPanel>

        </TabPanels>
      </Tabs>

        
        <DrawerExample isOpen={isOpen} onClose={onClose} btnRef={btnRef} handleProductSelect={handleProductSelect}
          handleUnProductSelect={handleUnProductSelect}
          checkMapIdStatusInDataForUpdateFillPlan={checkMapIdStatusInDataForUpdateFillPlan}
          handleEditAndClearLocation={handleEditAndClearLocation}
          get_fillplanlist={get_fillplanlist}
          fillplan={fillplan}
          setFillPlan={setFillPlan}
          resetToDefaultState={resetToDefaultState}
        />
   
    </Box>
  );
};

export default MapComponent;